# Asan Share

Developed by JAVED IQBAL — WhatsApp 0303 2901193

Fast, simple file sharing between Android phones. No internet needed.

How it works: Bluetooth finds the other phone, then the files go over a direct
Wi-Fi link between the two phones (Google Nearby Connections).

## Build the APK (GitHub + Codemagic)
1. Upload this folder to a new GitHub repo.
2. In Codemagic, add the repo. It will pick up `codemagic.yaml` automatically.
3. Start the "Asan Share APK" workflow. Download the APK from Artifacts.

If the "Gradle wrapper" step fails, copy `gradlew`, `gradlew.bat` and the
`gradle/` folder from another working Android project into this folder and push again.

## Using it
- Both phones: Wi-Fi ON (no need to connect to a network), Bluetooth ON, Location ON.
- Phone A taps Receive. Phone B taps Send, chooses files, taps Phone A.
- Phone A taps Accept. Files are saved in Downloads/Asan Share.
- You can also share straight from Gallery / File manager: Share > Asan Share.
- Both phones need Google Play services (most phones except newer Huawei).
