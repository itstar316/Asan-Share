# Asan Share

Developed by JAVED IQBAL — WhatsApp 0303 2901193

Fast file sharing between Android phones. No internet needed.

## How it works
- Open Asan Share on both phones. Each phone is visible AND searching automatically.
- Tap the other phone, the other phone taps Accept. Both phones are now connected.
- Pick photos, videos, apps, music or files on either phone and tap Send.
- Friend doesn't have the app? Home > "Friend has no app?" > Bluetooth, Wi-Fi download (QR codes) or Quick Share.

Technology: Google Nearby Connections (Bluetooth to find, then a direct Wi-Fi link for the files).

## Build (GitHub + Codemagic)
Upload AsanShare.zip and codemagic.yaml to the repo, then start the build.
