package com.k2.share

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** App language. Every screen re-draws instantly when this changes. */
object Lang {
    var urdu by mutableStateOf(false)
}

/** Pick the English or Urdu text. */
fun tr(en: String, ur: String): String = if (Lang.urdu) ur else en
