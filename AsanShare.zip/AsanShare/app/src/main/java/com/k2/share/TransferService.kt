package com.k2.share

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

/**
 * Keeps Asan Share alive while files are moving, even if you switch apps or the screen turns off
 * (needed for big files). Shows a progress notification.
 */
class TransferService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = build(this, "Connected", -1)
        runCatching {
            if (Build.VERSION.SDK_INT >= 29) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
            else startForeground(ID, n)
        }.onFailure { stopSelf() }
        return START_NOT_STICKY
    }

    companion object {
        private const val ID = 7
        private const val CHANNEL = "transfers"
        @Volatile private var running = false

        fun start(ctx: Context) {
            if (running) return
            running = runCatching {
                ContextCompat.startForegroundService(ctx, Intent(ctx, TransferService::class.java)); true
            }.getOrDefault(false)
        }

        fun stop(ctx: Context) {
            if (!running) return
            running = false
            runCatching { ctx.stopService(Intent(ctx, TransferService::class.java)) }
        }

        fun update(ctx: Context, text: String, percent: Int) {
            if (!running) return
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) return
            try {
                NotificationManagerCompat.from(ctx).notify(ID, build(ctx, text, percent))
            } catch (_: SecurityException) {
            }
        }

        private fun build(ctx: Context, text: String, percent: Int): Notification {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CHANNEL) == null) {
                nm.createNotificationChannel(NotificationChannel(CHANNEL, "File transfers", NotificationManager.IMPORTANCE_LOW))
            }
            val open = PendingIntent.getActivity(
                ctx, 0,
                Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            return NotificationCompat.Builder(ctx, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Asan Share")
                .setContentText(text)
                .setOngoing(percent < 100)
                .setOnlyAlertOnce(true)
                .setProgress(100, percent.coerceIn(0, 100), percent < 0)
                .setContentIntent(open)
                .build()
        }
    }
}
