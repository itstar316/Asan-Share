package com.k2.share

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import com.k2.share.ui.AppRoot
import com.k2.share.ui.K2Theme
import com.k2.share.ui.PermissionAsk

/** One permission step shown to the person: why we need it, then Android's own Allow popup. */
data class PermStep(
    val key: String,
    val perms: Array<String>,
    val required: Boolean,
    val titleEn: String, val titleUr: String,
    val whyEn: String, val whyUr: String,
)

class MainActivity : ComponentActivity() {
    private val vm: ShareViewModel by viewModels()
    private var granted by mutableStateOf(false)

    /** The step being asked right now (null = nothing missing). */
    private var step by mutableStateOf<PermStep?>(null)
    /** Android won't show its popup any more (person chose "Don't ask again"): only Settings can fix it. */
    private var blocked by mutableStateOf(false)
    private val askedThisRun = HashSet<String>()
    private val skippedThisRun = HashSet<String>()
    private var current: PermStep? = null

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            current?.let { askedThisRun.add(it.key) }
            refreshPermissions()
        }

    private fun isGranted(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    /** Every permission the app uses, in a sensible order. Optional ones can be skipped. */
    private val steps: List<PermStep> by lazy {
        buildList {
            val nearby = buildList {
                if (Build.VERSION.SDK_INT >= 31) { add(Manifest.permission.BLUETOOTH_SCAN); add(Manifest.permission.BLUETOOTH_ADVERTISE); add(Manifest.permission.BLUETOOTH_CONNECT) }
                if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.NEARBY_WIFI_DEVICES)
            }
            if (nearby.isNotEmpty()) add(PermStep("nearby", nearby.toTypedArray(), true,
                "Find nearby phones", "قریبی فون ڈھونڈیں",
                "Asan Share needs \"Nearby devices\" to find phones around you and connect to them directly.",
                "آسان شیئر کو آپ کے اردگرد فون ڈھونڈنے اور اُن سے براہِ راست جُڑنے کے لیے «قریبی ڈیوائسز» کی اجازت چاہیے۔"))
            add(PermStep("location", arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), true,
                "Allow location", "لوکیشن کی اجازت دیں",
                "Android requires location to search for nearby phones and Wi-Fi groups. Asan Share never tracks or saves where you are. Please choose \"Precise\".",
                "قریبی فون اور وائی فائی گروپ ڈھونڈنے کے لیے اینڈرائیڈ لوکیشن کی اجازت مانگتا ہے۔ آسان شیئر آپ کی جگہ کبھی محفوظ یا ٹریک نہیں کرتا۔ «درست» (Precise) چنیں۔"))
            if (Build.VERSION.SDK_INT <= 29) add(PermStep("storage", arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), true,
                "Save received files", "موصول فائلیں محفوظ کریں",
                "Needed to save the files you receive on this phone.",
                "موصول ہونے والی فائلیں اس فون پر محفوظ کرنے کے لیے ضروری ہے۔"))
            add(PermStep("media", MEDIA_PERMS, false,
                "Show your photos, videos and music", "اپنی تصاویر، ویڈیوز اور گانے دکھائیں",
                "So you can pick what to send. Nothing is uploaded anywhere.",
                "تاکہ آپ بھیجنے کے لیے چیزیں چن سکیں۔ کچھ بھی کہیں اپ لوڈ نہیں ہوتا۔"))
            if (Build.VERSION.SDK_INT >= 33) add(PermStep("notify", arrayOf(Manifest.permission.POST_NOTIFICATIONS), false,
                "Show transfer progress", "منتقلی کی پیش رفت دکھائیں",
                "A notification shows progress and keeps big transfers running when the screen is off.",
                "نوٹیفکیشن میں پیش رفت نظر آتی ہے اور اسکرین بند ہونے پر بھی بڑی فائلیں جاتی رہتی ہیں۔"))
        }
    }

    /** Find the next missing permission and ask for it (called on open, on return to the app, and on errors). */
    private fun refreshPermissions() {
        granted = hasAll()
        val next = steps.firstOrNull { st -> st.key !in skippedThisRun && st.perms.any { !isGranted(it) } &&
            // optional media: any one of its permissions is enough (e.g. "selected photos only")
            !(st.key == "media" && st.perms.any { isGranted(it) }) }
        current = next
        step = next
        blocked = next != null && next.key in askedThisRun &&
            next.perms.filter { !isGranted(it) }.none { shouldShowRequestPermissionRationale(it) }
    }

    private fun askCurrent() {
        val st = current ?: return
        permLauncher.launch(st.perms)
    }

    private fun openAppSettings() {
        runCatching {
            startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // light status/navigation icons on our dark design, on every phone (even if the phone is in light mode)
        enableEdgeToEdge(
            statusBarStyle = androidx.activity.SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = androidx.activity.SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        granted = hasAll()
        if (savedInstanceState == null) handleShare(intent)
        setContent {
            K2Theme {
                AppRoot(vm, granted) { refreshPermissions(); askCurrent() }
                // If Nearby reports a missing permission while running: check again and ask
                androidx.compose.runtime.LaunchedEffect(vm.permissionProblem) {
                    if (vm.permissionProblem) { vm.permissionProblem = false; askedThisRun.clear(); refreshPermissions() }
                }
                step?.let { st ->
                    PermissionAsk(
                        title = tr(st.titleEn, st.titleUr),
                        why = tr(st.whyEn, st.whyUr),
                        required = st.required,
                        blocked = blocked,
                        onAllow = { if (blocked) openAppSettings() else askCurrent() },
                        onSkip = { skippedThisRun.add(st.key); refreshPermissions() },
                    )
                }
            }
        }
        refreshPermissions()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    override fun onStart() {
        super.onStart()
        vm.onAppForeground()
    }

    override fun onStop() {
        super.onStop()
        vm.onAppBackground()
    }

    override fun onResume() {
        super.onResume()
        refreshPermissions() // e.g. came back from Settings, or a permission was removed meanwhile
        vm.refreshFolderAccess()
    }

    private fun hasAll() = PERMS.all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    /** Files shared to Asan Share from Gallery / File manager / other apps. */
    private fun handleShare(intent: Intent?) {
        val i = intent ?: return
        val uris: List<Uri> = when (i.action) {
            Intent.ACTION_SEND -> listOfNotNull(IntentCompat.getParcelableExtra(i, Intent.EXTRA_STREAM, Uri::class.java))
            Intent.ACTION_SEND_MULTIPLE -> IntentCompat.getParcelableArrayListExtra(i, Intent.EXTRA_STREAM, Uri::class.java) ?: emptyList()
            else -> emptyList()
        }
        if (uris.isEmpty()) return
        if (vm.connected) {
            vm.addFiles(uris)
            vm.sendSelected()
        } else {
            if (vm.screen != Screen.HOME) vm.goHome()
            vm.addFiles(uris) // home shows "Tap a phone to send these"
        }
    }

    companion object {
        val PERMS: Array<String> = buildList {
            if (Build.VERSION.SDK_INT >= 31) {
                add(Manifest.permission.BLUETOOTH_SCAN)
                add(Manifest.permission.BLUETOOTH_ADVERTISE)
                add(Manifest.permission.BLUETOOTH_CONNECT)
            }
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.NEARBY_WIFI_DEVICES)
            // Nearby's Bluetooth scan needs Location on every Android version
            add(Manifest.permission.ACCESS_FINE_LOCATION)
            add(Manifest.permission.ACCESS_COARSE_LOCATION)
            if (Build.VERSION.SDK_INT <= 29) add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }.toTypedArray()

        /** Asked for, but the app still works if refused. */
        val OPTIONAL_PERMS: Array<String> =
            if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.POST_NOTIFICATIONS) else emptyArray()
    }
}
