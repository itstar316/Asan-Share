package com.k2.share

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import com.k2.share.ui.AppRoot
import com.k2.share.ui.K2Theme

class MainActivity : ComponentActivity() {
    private val vm: ShareViewModel by viewModels()
    private var granted by mutableStateOf(false)

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted = hasAll() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        granted = hasAll()
        if (savedInstanceState == null) handleShare(intent)
        setContent {
            K2Theme { AppRoot(vm, granted) { permLauncher.launch(PERMS + OPTIONAL_PERMS) } }
        }
        if (!granted) permLauncher.launch(PERMS + OPTIONAL_PERMS)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    override fun onStart() {
        super.onStart()
        vm.onAppForeground()
    }

    override fun onStop() {
        super.onStop()
        vm.onAppBackground()
    }

    override fun onResume() {
        super.onResume()
        granted = hasAll()
        vm.refreshFolderAccess()
    }

    private fun hasAll() = PERMS.all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    /** Files shared to Asan Share from Gallery / File manager / other apps. */
    private fun handleShare(intent: Intent?) {
        val i = intent ?: return
        val uris: List<Uri> = when (i.action) {
            Intent.ACTION_SEND -> listOfNotNull(IntentCompat.getParcelableExtra(i, Intent.EXTRA_STREAM, Uri::class.java))
            Intent.ACTION_SEND_MULTIPLE -> IntentCompat.getParcelableArrayListExtra(i, Intent.EXTRA_STREAM, Uri::class.java) ?: emptyList()
            else -> emptyList()
        }
        if (uris.isEmpty()) return
        if (vm.connected) {
            vm.addFiles(uris)
            vm.sendSelected()
        } else {
            if (vm.screen != Screen.HOME) vm.goHome()
            vm.addFiles(uris) // home shows "Tap a phone to send these"
        }
    }

    companion object {
        val PERMS: Array<String> = buildList {
            if (Build.VERSION.SDK_INT >= 31) {
                add(Manifest.permission.BLUETOOTH_SCAN)
                add(Manifest.permission.BLUETOOTH_ADVERTISE)
                add(Manifest.permission.BLUETOOTH_CONNECT)
            }
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.NEARBY_WIFI_DEVICES)
            // Nearby's Bluetooth scan needs Location on every Android version
            add(Manifest.permission.ACCESS_FINE_LOCATION)
            add(Manifest.permission.ACCESS_COARSE_LOCATION)
            if (Build.VERSION.SDK_INT <= 29) add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }.toTypedArray()

        /** Asked for, but the app still works if refused. */
        val OPTIONAL_PERMS: Array<String> =
            if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.POST_NOTIFICATIONS) else emptyArray()
    }
}
