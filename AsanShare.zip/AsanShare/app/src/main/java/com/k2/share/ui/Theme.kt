package com.k2.share.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.k2.share.Lang
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Ink navy for sending, saffron for receiving — same as the app icon
val Ink = Color(0xFF2B2F8F)        // deep indigo (brand)
val InkLight = Color(0xFF8F94FF)   // bright indigo for dark mode
val Violet = Color(0xFF7B5CFF)     // gradient partner
val Saffron = Color(0xFFFFC93C)
val OnSaffron = Color(0xFF2A1F00)
val Good = Color(0xFF1DB664)

private val Light = lightColorScheme(
    primary = Ink,
    onPrimary = Color.White,
    secondary = Saffron,
    onSecondary = OnSaffron,
    background = Color(0xFFF5F6FB),
    onBackground = Color(0xFF12142A),
    surface = Color.White,
    onSurface = Color(0xFF12142A),
    surfaceVariant = Color(0xFFECEEF7),
    onSurfaceVariant = Color(0xFF5B6080),
    outlineVariant = Color(0xFFE1E4F0),
)

private val Dark = darkColorScheme(
    primary = InkLight,
    onPrimary = Color(0xFF0D1240),
    secondary = Saffron,
    onSecondary = OnSaffron,
    background = Color(0xFF0B0D16),
    onBackground = Color(0xFFECEDF6),
    surface = Color(0xFF151827),
    onSurface = Color(0xFFECEDF6),
    surfaceVariant = Color(0xFF1A1E30),
    onSurfaceVariant = Color(0xFF9EA4C2),
    outlineVariant = Color(0xFF262B42),
)

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(26.dp),
    extraLarge = RoundedCornerShape(32.dp),
)

/** Clean type scale. Urdu gets extra line spacing so the script never looks cramped. */
private fun appTypography(urdu: Boolean): Typography {
    val b = Typography()
    // Urdu script looks smaller than Latin at the same size: make it ~10% bigger with extra line spacing
    fun TextStyle.u(line: Int) = if (urdu) copy(fontSize = fontSize * 1.1f, lineHeight = (line * 1.1f).sp) else this
    return b.copy(
        headlineSmall = b.headlineSmall.copy(fontWeight = FontWeight.Bold).u(40),
        titleLarge = b.titleLarge.copy(fontWeight = FontWeight.Bold).u(36),
        titleMedium = b.titleMedium.copy(fontWeight = FontWeight.SemiBold).u(30),
        titleSmall = b.titleSmall.u(26),
        bodyLarge = b.bodyLarge.u(30),
        bodyMedium = b.bodyMedium.u(26),
        bodySmall = b.bodySmall.u(22),
        labelLarge = b.labelLarge.u(24),
        labelMedium = b.labelMedium.u(20),
        labelSmall = b.labelSmall.u(18),
    )
}

@Composable
fun K2Theme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) Dark else Light,
        typography = appTypography(Lang.urdu),
        shapes = AppShapes,
        content = content,
    )
}
