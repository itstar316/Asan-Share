package com.k2.share.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Ink navy for sending, saffron for receiving — same as the app icon
val Ink = Color(0xFF1F2A6B)
val InkLight = Color(0xFF8E9BFF)
val Saffron = Color(0xFFFFC93C)
val OnSaffron = Color(0xFF2A1F00)
val Good = Color(0xFF12A150)

private val Light = lightColorScheme(
    primary = Ink,
    onPrimary = Color.White,
    secondary = Saffron,
    onSecondary = OnSaffron,
    background = Color(0xFFF4F6FA),
    onBackground = Color(0xFF151827),
    surface = Color.White,
    onSurface = Color(0xFF151827),
    surfaceVariant = Color(0xFFE9ECF4),
    onSurfaceVariant = Color(0xFF5A6078),
)

private val Dark = darkColorScheme(
    primary = InkLight,
    onPrimary = Color(0xFF0D1240),
    secondary = Saffron,
    onSecondary = OnSaffron,
    background = Color(0xFF10131F),
    onBackground = Color(0xFFE8EAF3),
    surface = Color(0xFF161A2A),
    onSurface = Color(0xFFE8EAF3),
    surfaceVariant = Color(0xFF1E2336),
    onSurfaceVariant = Color(0xFFA3A9C2),
)

@Composable
fun K2Theme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) Dark else Light, content = content)
}
