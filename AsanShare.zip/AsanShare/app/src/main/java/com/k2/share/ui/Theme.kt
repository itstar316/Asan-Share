package com.k2.share.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.k2.share.Lang
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Ink navy for sending, saffron for receiving — same as the app icon
val Ink = Color(0xFF1F2A6B)
val InkLight = Color(0xFF8E9BFF)
val Saffron = Color(0xFFFFC93C)
val OnSaffron = Color(0xFF2A1F00)
val Good = Color(0xFF12A150)

private val Light = lightColorScheme(
    primary = Ink,
    onPrimary = Color.White,
    secondary = Saffron,
    onSecondary = OnSaffron,
    background = Color(0xFFF4F6FA),
    onBackground = Color(0xFF151827),
    surface = Color.White,
    onSurface = Color(0xFF151827),
    surfaceVariant = Color(0xFFE9ECF4),
    onSurfaceVariant = Color(0xFF5A6078),
)

private val Dark = darkColorScheme(
    primary = InkLight,
    onPrimary = Color(0xFF0D1240),
    secondary = Saffron,
    onSecondary = OnSaffron,
    background = Color(0xFF10131F),
    onBackground = Color(0xFFE8EAF3),
    surface = Color(0xFF161A2A),
    onSurface = Color(0xFFE8EAF3),
    surfaceVariant = Color(0xFF1E2336),
    onSurfaceVariant = Color(0xFFA3A9C2),
)

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

/** Clean type scale. Urdu gets extra line spacing so the script never looks cramped. */
private fun appTypography(urdu: Boolean): Typography {
    val b = Typography()
    fun TextStyle.u(line: Int) = if (urdu) copy(lineHeight = line.sp) else this
    return b.copy(
        headlineSmall = b.headlineSmall.copy(fontWeight = FontWeight.Bold).u(40),
        titleLarge = b.titleLarge.copy(fontWeight = FontWeight.Bold).u(36),
        titleMedium = b.titleMedium.copy(fontWeight = FontWeight.SemiBold).u(30),
        titleSmall = b.titleSmall.u(26),
        bodyLarge = b.bodyLarge.u(30),
        bodyMedium = b.bodyMedium.u(26),
        bodySmall = b.bodySmall.u(22),
        labelLarge = b.labelLarge.u(24),
        labelMedium = b.labelMedium.u(20),
        labelSmall = b.labelSmall.u(18),
    )
}

@Composable
fun K2Theme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) Dark else Light,
        typography = appTypography(Lang.urdu),
        shapes = AppShapes,
        content = content,
    )
}
