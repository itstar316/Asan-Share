package com.k2.share.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.k2.share.Lang
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Ink navy for sending, saffron for receiving — same as the app icon
val Ink = Color(0xFF2B2F8F)        // deep indigo (brand)
val InkLight = Color(0xFF8F94FF)   // bright indigo for dark mode
val Violet = Color(0xFF7B5CFF)     // gradient partner
val Saffron = Color(0xFFFFC93C)
val OnSaffron = Color(0xFF2A1F00)
val Good = Color(0xFF1DB664)

private val Light = lightColorScheme(
    primary = Color(0xFF2F35C8),          // links, progress, focus
    onPrimary = Color.White,
    secondary = Saffron,
    onSecondary = OnSaffron,
    background = Color(0xFFF2F3F7),        // soft grey page
    onBackground = Color(0xFF111218),
    surface = Color.White,
    onSurface = Color(0xFF111218),
    surfaceVariant = Color.White,          // cards: white on grey (clean, professional)
    onSurfaceVariant = Color(0xFF6B6F80),
    outlineVariant = Color(0xFFE4E5EC),
)

private val Dark = darkColorScheme(
    primary = Saffron,                     // brand gold for progress, links and highlights
    onPrimary = OnSaffron,
    secondary = Saffron,
    onSecondary = OnSaffron,
    background = Color(0xFF0E0F13),        // near-black graphite
    onBackground = Color(0xFFF2F2F5),
    surface = Color(0xFF17181D),
    onSurface = Color(0xFFF2F2F5),
    surfaceVariant = Color(0xFF1B1C22),    // cards
    onSurfaceVariant = Color(0xFF8D90A0),
    outlineVariant = Color(0xFF2A2B33),
)

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(26.dp),
    extraLarge = RoundedCornerShape(32.dp),
)

/** Clean type scale. Urdu gets extra line spacing so the script never looks cramped. */
private fun appTypography(urdu: Boolean): Typography {
    val b = Typography()
    // Urdu script looks smaller than Latin at the same size: make it ~10% bigger with extra line spacing
    fun TextStyle.u(line: Int) = if (urdu) copy(fontSize = fontSize * 1.1f, lineHeight = (line * 1.1f).sp, letterSpacing = 0.sp) else this
    // Professional scale: SemiBold headings with slightly tight spacing, calm regular body text
    return b.copy(
        displaySmall = b.displaySmall.copy(fontWeight = FontWeight.SemiBold, fontSize = 40.sp, lineHeight = 46.sp, letterSpacing = (-0.8).sp).u(54),
        headlineMedium = b.headlineMedium.copy(fontWeight = FontWeight.SemiBold, letterSpacing = (-0.5).sp).u(44),
        headlineSmall = b.headlineSmall.copy(fontWeight = FontWeight.SemiBold, fontSize = 24.sp, lineHeight = 30.sp, letterSpacing = (-0.4).sp).u(40),
        titleLarge = b.titleLarge.copy(fontWeight = FontWeight.SemiBold, fontSize = 21.sp, lineHeight = 27.sp, letterSpacing = (-0.3).sp).u(36),
        titleMedium = b.titleMedium.copy(fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp, letterSpacing = (-0.1).sp).u(30),
        titleSmall = b.titleSmall.copy(fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 20.sp, letterSpacing = 0.sp).u(26),
        bodyLarge = b.bodyLarge.copy(fontSize = 16.sp, lineHeight = 24.sp, letterSpacing = 0.sp).u(30),
        bodyMedium = b.bodyMedium.copy(fontSize = 14.sp, lineHeight = 21.sp, letterSpacing = 0.sp).u(26),
        bodySmall = b.bodySmall.copy(fontSize = 12.5.sp, lineHeight = 18.sp, letterSpacing = 0.1.sp).u(22),
        labelLarge = b.labelLarge.copy(fontWeight = FontWeight.SemiBold, letterSpacing = 0.sp).u(24),
        labelMedium = b.labelMedium.copy(fontWeight = FontWeight.Medium, letterSpacing = 0.1.sp).u(20),
        labelSmall = b.labelSmall.copy(fontWeight = FontWeight.Medium, letterSpacing = 0.3.sp).u(18),
    )
}

@Composable
fun K2Theme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) Dark else Light,
        typography = appTypography(Lang.urdu),
        shapes = AppShapes,
        content = content,
    )
}
