package com.k2.share

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Permissions needed to show photos, videos, music and files. */
val MEDIA_PERMS: Array<String> = when {
    Build.VERSION.SDK_INT >= 34 -> arrayOf(
        Manifest.permission.READ_MEDIA_IMAGES,
        Manifest.permission.READ_MEDIA_VIDEO,
        Manifest.permission.READ_MEDIA_AUDIO,
        Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED,
    )
    Build.VERSION.SDK_INT >= 33 -> arrayOf(
        Manifest.permission.READ_MEDIA_IMAGES,
        Manifest.permission.READ_MEDIA_VIDEO,
        Manifest.permission.READ_MEDIA_AUDIO,
    )
    else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
}

fun hasMediaAccess(ctx: Context): Boolean =
    MEDIA_PERMS.any { ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED }

/** Small, fast, cached thumbnails for photos, videos and app icons. */
object Thumbs {
    // Limited by MEMORY (1/8 of what the app may use), not by count: budget phones crashed with big thumbnails
    private val cache = object : LruCache<String, ImageBitmap>((Runtime.getRuntime().maxMemory() / 1024 / 8).toInt()) {
        override fun sizeOf(key: String, value: ImageBitmap): Int = (value.width * value.height * 4 / 1024).coerceAtLeast(1)
    }
    // Decode at most 4 thumbnails at a time (fast scrolling used to start dozens at once)
    private val gate = kotlinx.coroutines.sync.Semaphore(4)

    fun cached(key: String): ImageBitmap? = cache.get(key)

    /** Keep thumbnails small (some phones return full-size frames). */
    private fun shrink(b: android.graphics.Bitmap): android.graphics.Bitmap {
        val max = 320
        val big = maxOf(b.width, b.height)
        if (big <= max) return b
        val k = max.toFloat() / big
        return runCatching { android.graphics.Bitmap.createScaledBitmap(b, (b.width * k).toInt().coerceAtLeast(1), (b.height * k).toInt().coerceAtLeast(1), true) }
            .getOrDefault(b).also { if (it !== b) b.recycle() }
    }

    @Suppress("DEPRECATION")
    suspend fun load(ctx: Context, item: MediaItem): ImageBitmap? = withContext(Dispatchers.IO) {
        cache.get(item.key)?.let { return@withContext it }
        gate.acquire()
        try { cache.get(item.key)?.let { return@withContext it }; loadNow(ctx, item) } finally { gate.release() }
    }

    @Suppress("DEPRECATION")
    private fun loadNow(ctx: Context, item: MediaItem): ImageBitmap? {
        val bmp = runCatching {
            val path = item.path
            // APK file: show the app's own icon
            if (path != null && path.endsWith(".apk", ignoreCase = true)) {
                val pm = ctx.packageManager
                val info = pm.getPackageArchiveInfo(path, 0)
                val ai = info?.applicationInfo
                return@runCatching ai?.let {
                    it.sourceDir = path; it.publicSourceDir = path
                    it.loadIcon(pm).toBitmap(128, 128)
                }
            }
            if (path != null && (item.kind == Kind.PHOTO || item.kind == Kind.VIDEO)) {
                val f = java.io.File(path)
                return@runCatching if (Build.VERSION.SDK_INT >= 29) {
                    if (item.kind == Kind.PHOTO) android.media.ThumbnailUtils.createImageThumbnail(f, Size(256, 256), null)
                    else android.media.ThumbnailUtils.createVideoThumbnail(f, Size(256, 256), null)
                } else {
                    if (item.kind == Kind.PHOTO) {
                        val o = android.graphics.BitmapFactory.Options().apply { inSampleSize = 8 }
                        android.graphics.BitmapFactory.decodeFile(path, o)
                    } else android.media.ThumbnailUtils.createVideoThumbnail(path, MediaStore.Video.Thumbnails.MINI_KIND)
                }
            }
            when (item.kind) {
                Kind.APP -> ctx.packageManager.getApplicationIcon(item.pkg!!).toBitmap(128, 128)
                Kind.PHOTO, Kind.VIDEO ->
                    if (Build.VERSION.SDK_INT >= 29) ctx.contentResolver.loadThumbnail(item.uri, Size(256, 256), null)
                    else {
                        val id = ContentUris.parseId(item.uri)
                        if (item.kind == Kind.PHOTO)
                            MediaStore.Images.Thumbnails.getThumbnail(ctx.contentResolver, id, MediaStore.Images.Thumbnails.MINI_KIND, null)
                        else
                            MediaStore.Video.Thumbnails.getThumbnail(ctx.contentResolver, id, MediaStore.Video.Thumbnails.MINI_KIND, null)
                    }
                else -> null
            }
        }.getOrNull() ?: return null
        val img = shrink(bmp).asImageBitmap()
        cache.put(item.key, img)
        return img
    }
}
