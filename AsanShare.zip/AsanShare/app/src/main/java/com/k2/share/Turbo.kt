package com.k2.share

import android.annotation.SuppressLint
import android.content.Context
import android.net.wifi.WifiManager
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume

/**
 * TURBO: Asan Share's own fast link (like Zapya / SHAREit).
 * One phone creates a private Wi-Fi Direct network (5 GHz when possible), the other joins it,
 * and files stream directly over one TCP connection, in both directions.
 */
object Turbo {
    const val PORT = 39871
    private const val GO_IP = "192.168.49.1" // standard Wi-Fi Direct group-owner address

    fun supported() = Build.VERSION.SDK_INT >= 29

    /** Last thing that went wrong (shown to the user, helps fixing phone-specific problems). */
    @Volatile var lastError: String? = null
        set(v) { field = v; if (v != null) log("Problem: $v") }

    /** Step-by-step log, shown in "Connection details". */
    var logger: ((String) -> Unit)? = null
    private val mainH = Handler(Looper.getMainLooper())
    fun log(msg: String) { mainH.post { logger?.invoke(msg) } }

    private var manager: WifiP2pManager? = null
    private var channel: WifiP2pManager.Channel? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var wifiLock2: WifiManager.WifiLock? = null
    private var wakeLock: PowerManager.WakeLock? = null

    private fun mgr(ctx: Context): Pair<WifiP2pManager, WifiP2pManager.Channel>? {
        val m = manager ?: (ctx.getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager) ?: return null
        val c = channel ?: m.initialize(ctx.applicationContext, Looper.getMainLooper()) { channel = null } ?: return null
        manager = m; channel = c
        return m to c
    }

    /** Open a brand-new Wi-Fi Direct channel (Android can silently close the old one after an error). */
    private fun freshChannel(ctx: Context) {
        val old = channel
        channel = null
        if (old != null && Build.VERSION.SDK_INT >= 27) runCatching { old.close() }
    }

    // ---------- Zapya-style groups ----------
    const val GROUP_PREFIX = "DIRECT-AS-AS_"

    /** Network name shown to the other phone, e.g. "DIRECT-AS-Javeds Tab A7". */
    fun groupName(deviceName: String): String {
        val clean = deviceName.filter { it.isLetterOrDigit() || it == ' ' }.trim().take(19).ifEmpty { "Phone" }
        return GROUP_PREFIX + clean
    }

    /** Both apps can work out the password from the name, so no typing is needed. */
    fun groupPass(ssid: String): String {
        val d = java.security.MessageDigest.getInstance("SHA-256").digest(("asan-share-k2:" + ssid).toByteArray())
        return d.joinToString("") { "%02x".format(it) }.take(12)
    }

    /** Asan Share groups around us (names starting with DIRECT-AS-). */
    @Suppress("DEPRECATION")
    @SuppressLint("MissingPermission")
    fun scanGroups(ctx: Context, newScan: Boolean): List<Pair<String, Int>> {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager ?: return emptyList()
        // Android allows only ~4 fresh scans per 2 minutes, so we ask for one every 30 s and read results often
        if (newScan) runCatching { wm.startScan() }
        return runCatching {
            wm.scanResults.filter { it.SSID?.startsWith(GROUP_PREFIX) == true }
                .groupBy { it.SSID }.map { (ssid, list) -> ssid to list.maxOf { it.level } }
                .sortedByDescending { it.second }
        }.getOrDefault(emptyList())
    }

    fun newCredentials(): Pair<String, String> {
        val abc = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        fun rnd(n: Int) = (1..n).map { abc.random() }.joinToString("")
        return "DIRECT-AS-" + rnd(4) to rnd(12)
    }

    @SuppressLint("MissingPermission")
    private suspend fun removeGroup(m: WifiP2pManager, c: WifiP2pManager.Channel) =
        withTimeoutOrNull(3000) {
            suspendCancellableCoroutine { k ->
                m.removeGroup(c, object : WifiP2pManager.ActionListener {
                    override fun onSuccess() { if (k.isActive) k.resume(Unit) }
                    override fun onFailure(reason: Int) { if (k.isActive) k.resume(Unit) }
                })
            }
        }

    private fun reasonText(r: Int) = when (r) {
        WifiP2pManager.P2P_UNSUPPORTED -> "Wi-Fi Direct not supported"
        WifiP2pManager.BUSY -> "Wi-Fi busy"
        else -> "error $r"
    }

    @SuppressLint("MissingPermission")
    private suspend fun call(what: String, block: (WifiP2pManager.ActionListener) -> Unit): Boolean =
        withTimeoutOrNull(8000) {
            suspendCancellableCoroutine { k ->
                block(object : WifiP2pManager.ActionListener {
                    override fun onSuccess() { if (k.isActive) k.resume(true) }
                    override fun onFailure(reason: Int) { lastError = "$what: ${reasonText(reason)}"; if (k.isActive) k.resume(false) }
                })
            }
        } ?: run { lastError = "$what: no answer"; false }

    @SuppressLint("MissingPermission")
    private suspend fun groupOwnerIp(m: WifiP2pManager, c: WifiP2pManager.Channel): String? =
        withTimeoutOrNull(3000) {
            suspendCancellableCoroutine { k ->
                m.requestConnectionInfo(c) { info ->
                    val ip = if (info != null && info.groupFormed) info.groupOwnerAddress?.hostAddress else null
                    if (k.isActive) k.resume(ip)
                }
            }
        }

    /** Host: make the private network and wait for the other phone. */
    @SuppressLint("MissingPermission")
    @Volatile private var activeServer: ServerSocket? = null
    /** Stop waiting for the other phone (it told us it can't join). */
    fun cancelAccept() { runCatching { activeServer?.close() } }

    suspend fun host(
        ctx: Context, ssid: String, pass: String,
        createMs: Long = 25_000, acceptMs: Int = 50_000, onReady: (() -> Unit)? = null,
    ): Socket? {
        if (!supported()) return null
        freshChannel(ctx)
        val (m, c) = mgr(ctx) ?: run { lastError = "Wi-Fi Direct not available"; return null }
        lastError = null
        var ok = false
        // The pairing link may still be holding Wi-Fi for a few seconds: keep trying for up to 25 s.
        val until = System.currentTimeMillis() + createMs
        while (!ok && System.currentTimeMillis() < until) {
            removeGroup(m, c)
            // Try 5 GHz first (fastest), then let the phone choose
            for (band in intArrayOf(WifiP2pConfig.GROUP_OWNER_BAND_5GHZ, WifiP2pConfig.GROUP_OWNER_BAND_AUTO)) {
                val cfg = runCatching {
                    WifiP2pConfig.Builder().setNetworkName(ssid).setPassphrase(pass).setGroupOperatingBand(band).build()
                }.getOrNull() ?: continue
                log("Creating private Wi-Fi (" + (if (band == WifiP2pConfig.GROUP_OWNER_BAND_5GHZ) "5 GHz" else "auto band") + ")")
                ok = call("Create network") { l -> m.createGroup(c, cfg, l) }
                if (ok) break
            }
            if (!ok) delay(1500)
        }
        if (!ok) return null
        log("Private Wi-Fi ready, waiting for the other phone")
        return withContext(Dispatchers.IO) {
            runCatching {
                ServerSocket().use { ss ->
                    ss.reuseAddress = true
                    ss.bind(InetSocketAddress(PORT))
                    ss.soTimeout = acceptMs
                    activeServer = ss
                    onReady?.let { mainH.post(it) } // now tell the other phone to join
                    ss.accept()
                }
            }.onFailure { lastError = "Other phone didn't join" }.getOrNull().also { activeServer = null }
        }?.also { tune(it) }
    }

    /** Client: join the other phone's private network and connect. */
    @SuppressLint("MissingPermission")
    suspend fun join(
        ctx: Context, ssid: String, pass: String,
        firstDelay: Long = 2500, joinMs: Long = 35_000, formedMs: Long = 30_000, connectMs: Long = 25_000,
    ): Socket? {
        if (!supported()) return null
        val (m, c) = mgr(ctx) ?: run { lastError = "Wi-Fi Direct not available"; return null }
        lastError = null
        val cfg = runCatching {
            WifiP2pConfig.Builder().setNetworkName(ssid).setPassphrase(pass)
                .setGroupOperatingBand(WifiP2pConfig.GROUP_OWNER_BAND_AUTO).build()
        }.getOrNull() ?: run { lastError = "Bad network details"; return null }
        // The host needs a few seconds to free Wi-Fi and create its network: keep asking for up to 35 s
        delay(firstDelay)
        var joined = false
        val joinUntil = System.currentTimeMillis() + joinMs
        while (!joined && System.currentTimeMillis() < joinUntil) {
            removeGroup(m, c)
            log("Joining private Wi-Fi")
            joined = call("Join network") { l -> m.connect(c, cfg, l) }
            if (!joined) delay(2000)
        }
        if (!joined) return null
        // "Join" only means the request was accepted: wait until we are really in the network
        var ip: String? = null
        val formedUntil = System.currentTimeMillis() + formedMs
        while (ip == null && System.currentTimeMillis() < formedUntil) {
            ip = groupOwnerIp(m, c)
            if (ip == null) delay(700)
        }
        if (ip == null) { lastError = "Couldn't join the private Wi-Fi"; return null }
        log("Joined private Wi-Fi (host $ip)")
        val hostIp: String = ip ?: GO_IP
        // Now reach the host's Turbo port
        val deadline = System.currentTimeMillis() + connectMs
        while (System.currentTimeMillis() < deadline) {
            val s = withContext(Dispatchers.IO) {
                runCatching {
                    Socket().apply {
                        connect(InetSocketAddress(hostIp, PORT), 2500)
                    }
                }.getOrNull()
            }
            if (s != null) { log("Connected to $hostIp"); return s.also { tune(it) } }
            delay(1000)
        }
        lastError = "Couldn't reach the other phone"
        return null
    }

    fun tune(s: Socket) {
        runCatching {
            s.tcpNoDelay = false
            s.keepAlive = true
        }
    }

    /** Keep Wi-Fi at full speed and the CPU awake while Turbo is running. */
    @Suppress("DEPRECATION")
    fun holdLocks(ctx: Context) {
        runCatching {
            val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            if (wifiLock == null) wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "asan:turbo").apply { acquire() }
            if (Build.VERSION.SDK_INT >= 29 && wifiLock2 == null)
                wifiLock2 = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "asan:turbo2").apply { acquire() }
        }
        runCatching {
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            if (wakeLock == null) wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "asan:turbo").apply { acquire(6 * 60 * 60 * 1000L) }
        }
    }

    /** Leave/remove the private network and release locks. */
    // ---------- Asan Share's OWN hotspot (the reliable fast path, like Zapya) ----------
    private var lohReservation: WifiManager.LocalOnlyHotspotReservation? = null
    @Volatile private var lohStopped = false
    private var netCallback: android.net.ConnectivityManager.NetworkCallback? = null
    @Volatile var joinedNetwork: android.net.Network? = null

    class HotspotInfo(val ssid: String, val pass: String, val sec: Int)

    /** Host: start a private hotspot that belongs to this app. Returns its name/password, or null. */
    @Suppress("DEPRECATION")
    @SuppressLint("MissingPermission")
    suspend fun startHotspot(ctx: Context): HotspotInfo? {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager ?: return null
        stopHotspot()
        lohStopped = false
        lastError = null
        log("Starting Asan Share's own hotspot")
        return withTimeoutOrNull(15_000) {
            suspendCancellableCoroutine { k ->
                try {
                    wm.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                        override fun onStarted(r: WifiManager.LocalOnlyHotspotReservation) {
                            if (lohStopped || !k.isActive) { runCatching { r.close() }; return }
                            lohReservation = r
                            var info: HotspotInfo? = null
                            if (Build.VERSION.SDK_INT >= 30) {
                                val c = r.softApConfiguration
                                val ssid = c.ssid; val pass = c.passphrase
                                if (ssid != null && pass != null) info = HotspotInfo(ssid, pass, c.securityType)
                            } else {
                                r.wifiConfiguration?.let { w ->
                                    if (w.SSID != null && w.preSharedKey != null) info = HotspotInfo(w.SSID.trim('"'), w.preSharedKey.trim('"'), 1)
                                }
                            }
                            if (info == null) lastError = "hotspot started but details unreadable"
                            else log("Hotspot ON: ${info!!.ssid}")
                            k.resume(info)
                        }
                        override fun onFailed(reason: Int) {
                            lastError = when (reason) {
                                WifiManager.LocalOnlyHotspotCallback.ERROR_INCOMPATIBLE_MODE -> "hotspot busy (another hotspot/Wi-Fi mode is on)"
                                WifiManager.LocalOnlyHotspotCallback.ERROR_TETHERING_DISALLOWED -> "this device doesn't allow hotspots"
                                WifiManager.LocalOnlyHotspotCallback.ERROR_NO_CHANNEL -> "no free Wi-Fi channel for a hotspot"
                                else -> "hotspot error $reason"
                            }
                            if (k.isActive) k.resume(null)
                        }
                    }, Handler(Looper.getMainLooper()))
                } catch (e: Exception) {
                    lastError = "hotspot not allowed: ${e.message}"
                    if (k.isActive) k.resume(null)
                }
            }
        } ?: run { if (lastError == null) lastError = "this device didn't start a hotspot (it may not support one)"; null }
    }

    fun stopHotspot() {
        lohStopped = true
        runCatching { lohReservation?.close() }
        lohReservation = null
    }

    /**
     * Client: join the other phone's Asan Share hotspot as OUR OWN network (Android 10+).
     * Android shows a one-time "Connect to device?" popup here.
     */
    @SuppressLint("MissingPermission")
    suspend fun joinHotspot(ctx: Context, ssid: String, pass: String, sec: Int, timeoutMs: Long = 70_000): android.net.Network? {
        if (Build.VERSION.SDK_INT < 29) { lastError = "Android 10+ needed to join"; return null }
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        leaveHotspot(ctx)
        lastError = null
        val spec = runCatching {
            val b = android.net.wifi.WifiNetworkSpecifier.Builder().setSsid(ssid)
            if (sec == 3) b.setWpa3Passphrase(pass) else b.setWpa2Passphrase(pass) // 3 = WPA3-only
            b.build()
        }.getOrNull() ?: run { lastError = "bad hotspot details"; return null }
        val req = android.net.NetworkRequest.Builder()
            .addTransportType(android.net.NetworkCapabilities.TRANSPORT_WIFI)
            .removeCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .setNetworkSpecifier(spec)
            .build()
        log("Joining the other phone's Wi-Fi (tap Connect if Android asks)")
        // Android searches for a short while and then says "not found". If the other phone's network wasn't
        // up yet (or the scan missed it), simply ask again until our overall time is up.
        val deadline = System.currentTimeMillis() + timeoutMs
        var attempt = 0
        while (System.currentTimeMillis() < deadline) {
            attempt++
            val left = deadline - System.currentTimeMillis()
            val net = withTimeoutOrNull(left) {
                suspendCancellableCoroutine<android.net.Network?> { k ->
                    val cb = object : android.net.ConnectivityManager.NetworkCallback() {
                        override fun onAvailable(network: android.net.Network) { joinedNetwork = network; log("Joined the Wi-Fi"); if (k.isActive) k.resume(network) }
                        override fun onUnavailable() { lastError = "Wi-Fi not found (attempt $attempt)"; if (k.isActive) k.resume(null) }
                    }
                    netCallback = cb
                    runCatching { cm.requestNetwork(req, cb) }.onFailure { lastError = "join failed: ${it.message}"; if (k.isActive) k.resume(null) }
                }
            }
            if (net != null) return net
            if (lastError?.startsWith("join failed") == true) return null // a real error (permission etc.): don't loop
            leaveHotspot(ctx)
            if (System.currentTimeMillis() + 3000 >= deadline) break
            log("Not found yet, searching again")
            delay(2500)
        }
        if (lastError == null) lastError = "joining the Wi-Fi timed out"
        return null
    }

    fun leaveHotspot(ctx: Context) {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        netCallback?.let { runCatching { cm.unregisterNetworkCallback(it) } }
        netCallback = null
        joinedNetwork = null
    }

    /** Is this device ALSO connected to a normal Wi-Fi (home/office router)? That halves (or worse) Turbo speed. */
    @Suppress("DEPRECATION")
    fun alsoOnRouterWifi(ctx: Context): Boolean = runCatching {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        cm.allNetworks.any { n ->
            val c = cm.getNetworkCapabilities(n) ?: return@any false
            c.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) &&
                c.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
        }
    }.getOrDefault(false)

    /** Band of the Wi-Fi Direct network this device created, e.g. "5 GHz". */
    @SuppressLint("MissingPermission")
    suspend fun groupBand(ctx: Context): String? {
        if (Build.VERSION.SDK_INT < 29) return null
        val (m, c) = mgr(ctx) ?: return null
        return withTimeoutOrNull(3000) {
            suspendCancellableCoroutine { k ->
                m.requestGroupInfo(c) { g ->
                    val f = g?.frequency ?: 0
                    if (k.isActive) k.resume(if (f == 0) null else if (f >= 4900) "5 GHz" else "2.4 GHz")
                }
            }
        }
    }

    /** e.g. "5 GHz, 433 Mbps" for the network we joined (Android 12+). */
    fun linkInfo(ctx: Context, network: android.net.Network?): String? {
        if (network == null || Build.VERSION.SDK_INT < 31) return null
        return runCatching {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            val wi = cm.getNetworkCapabilities(network)?.transportInfo as? android.net.wifi.WifiInfo ?: return@runCatching null
            val band = if (wi.frequency >= 4900) "5 GHz" else "2.4 GHz"
            "$band, ${wi.linkSpeed} Mbps"
        }.getOrNull()
    }

    /** Addresses of the hotspot owner as seen from the joined network (its gateway / DHCP server). */
    fun gatewayOf(ctx: Context, network: android.net.Network): List<String> {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        val lp = cm.getLinkProperties(network) ?: return emptyList()
        val out = ArrayList<String>()
        lp.routes.forEach { r -> if (r.hasGateway()) r.gateway?.hostAddress?.let { if (!it.contains(":")) out += it } }
        if (Build.VERSION.SDK_INT >= 30) lp.dhcpServerAddress?.hostAddress?.let { out += it }
        return out.distinct()
    }

    /** Connect over a specific network (the joined hotspot), never over mobile data. */
    suspend fun connectOn(network: android.net.Network, ips: List<String>, port: Int, totalMs: Long = 20_000): Socket? = withContext(Dispatchers.IO) {
        val deadline = System.currentTimeMillis() + totalMs
        while (System.currentTimeMillis() < deadline) {
            for (ip in ips) {
                val s = runCatching {
                    network.socketFactory.createSocket().apply {
                        connect(InetSocketAddress(ip, port), 2000)
                    }
                }.getOrNull()
                if (s != null) { log("Connected to $ip over the hotspot"); tune(s); return@withContext s }
            }
            delay(700)
        }
        lastError = "joined the hotspot but couldn't reach the other phone"
        null
    }

    suspend fun shutdown(ctx: Context, removeOwnGroup: Boolean = false) {
        stopHotspot()
        leaveHotspot(ctx)
        runCatching { wifiLock?.release() }; wifiLock = null
        runCatching { wifiLock2?.release() }; wifiLock2 = null
        runCatching { if (wakeLock?.isHeld == true) wakeLock?.release() }; wakeLock = null
        if (!removeOwnGroup) return // never tear down a Wi-Fi link we didn't build
        val mc = mgr(ctx) ?: return
        removeGroup(mc.first, mc.second)
    }

    /** True if this phone has a direct phone-to-phone Wi-Fi link (Wi-Fi Direct or hotspot), not just a router. */
    fun hasDirectLink(): Boolean = runCatching {
        java.net.NetworkInterface.getNetworkInterfaces().toList().any { ni ->
            val n = ni.name.lowercase()
            runCatching { ni.isUp }.getOrDefault(false) &&
                (n.contains("p2p") || n.startsWith("ap") || n.contains("swlan") || n.contains("softap") || n == "wlan1") &&
                runCatching { ni.inetAddresses.toList().any { it is java.net.Inet4Address } }.getOrDefault(false)
        }
    }.getOrDefault(false)

    /** Name of the network interface a connected socket uses (e.g. wlan0 = router, p2p-wlan0-0 = direct). */
    fun ifaceOf(s: Socket): String? = runCatching { java.net.NetworkInterface.getByInetAddress(s.localAddress)?.name }.getOrNull()

    /** Every local IPv4 address that another phone could reach (Wi-Fi Direct, hotspot, home Wi-Fi). Not mobile data. */
    fun localAddresses(): List<String> = runCatching {
        java.net.NetworkInterface.getNetworkInterfaces().toList()
            .filter { ni ->
                val n = ni.name.lowercase()
                runCatching { ni.isUp && !ni.isLoopback }.getOrDefault(false) &&
                    listOf("rmnet", "ccmni", "dummy", "tun", "ipsec", "clat", "v4-", "lo").none { n.startsWith(it) || n.contains("rmnet") }
            }
            .sortedBy { ni ->
                val n = ni.name.lowercase()
                when { n.contains("p2p") -> 0; n.startsWith("ap") || n.contains("swlan") || n.contains("softap") -> 1; n.startsWith("wlan") -> 2; else -> 3 }
            }
            .flatMap { ni -> runCatching { ni.inetAddresses.toList().filterIsInstance<java.net.Inet4Address>() }.getOrDefault(emptyList()) }
            .filter { it.isSiteLocalAddress }
            .mapNotNull { it.hostAddress }
            .distinct()
    }.onFailure { log("Couldn't list network addresses: ${it.message}") }.getOrDefault(emptyList())

    /**
     * Connect to the other phone trying every address it gave us.
     * Each try is made normally AND pinned to each Wi-Fi network, because with mobile data on,
     * Android may otherwise send the connection out over 4G and never reach the other phone.
     */
    @Suppress("DEPRECATION")
    suspend fun connectAny(ctx: Context, ips: List<String>, port: Int, totalMs: Long = 14_000): Socket? = withContext(Dispatchers.IO) {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        val deadline = System.currentTimeMillis() + totalMs
        while (System.currentTimeMillis() < deadline) {
            val wifiNets = runCatching {
                cm.allNetworks.filter { cm.getNetworkCapabilities(it)?.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) == true }
            }.getOrDefault(emptyList())
            for (ip in ips) {
                val makers = listOf<() -> Socket>({ Socket() }) + wifiNets.map { net -> { net.socketFactory.createSocket() } }
                for (make in makers) {
                    val s = runCatching {
                        make().apply {
                            connect(InetSocketAddress(ip, port), 1500)
                        }
                    }.getOrNull()
                    if (s != null) { log("Connected to $ip"); tune(s); return@withContext s }
                }
            }
            delay(800)
        }
        null
    }
}

/** Where an incoming file is written: straight to its final place, any part at any position. */
interface Sink {
    val channel: java.nio.channels.FileChannel
    fun finish(): android.net.Uri?
    fun abort()
}

/** A file being sent: read any part at any position (so several lanes can read it at once). */
interface Source {
    val channel: java.nio.channels.FileChannel
    fun close()
}

/**
 * TURBO link: one main connection (messages + data) plus extra data LANES.
 * Each file is cut into 512 KB pieces; the lanes send different pieces at the same time and the
 * receiver writes every piece straight into its place in the file. If one connection is throttled
 * (Samsung tablets!), the others keep the total speed high.
 */
class TurboLink(
    private val main: Socket,
    private val openSource: (PickedFile) -> Source?,
    private val openSink: (String, Long) -> Sink?,
    private val cb: Callbacks,
) {
    interface Callbacks {
        fun onBatch(count: Int, bytes: Long)
        fun onIncomingStart(remoteId: Long, name: String, size: Long)
        fun onIncomingProgress(remoteId: Long, done: Long)
        fun onIncomingDone(remoteId: Long, saved: android.net.Uri?)
        fun onOutgoingProgress(id: Long, done: Long)
        fun onOutgoingDone(id: Long, ok: Boolean)
        fun onBye()
        fun onClosed()
        fun onHello(name: String) {}
        fun onDelay(ms: Long) {}
        fun onLanesOffer(port: Int, count: Int) {}
        fun onIncomingCancelled(remoteId: Long) {}
        fun onOutgoingCancelled(id: Long) {}
    }

    private class Lane(val s: Socket) {
        val out = DataOutputStream(BufferedOutputStream(s.getOutputStream(), 256 * 1024))
        val inp = DataInputStream(BufferedInputStream(s.getInputStream(), 256 * 1024))
    }

    private class Piece(val id: Long, val src: java.nio.channels.FileChannel, val off: Long, val len: Int,
                        val sent: java.util.concurrent.atomic.AtomicLong, val left: java.util.concurrent.atomic.AtomicInteger)

    private class InFile(val sink: Sink?, val size: Long) {
        val got = java.util.concurrent.atomic.AtomicLong(0)
        val done = java.util.concurrent.atomic.AtomicBoolean(false)
        @Volatile var lastUi = 0L
    }

    private val mainH = Handler(Looper.getMainLooper())
    private fun ui(block: () -> Unit) = mainH.post(block)

    private val lanes = java.util.concurrent.CopyOnWriteArrayList<Lane>()
    private val control = ConcurrentLinkedQueue<(DataOutputStream) -> Unit>()
    private val files = LinkedBlockingQueue<Pair<Long, PickedFile>>()
    private val pieces = LinkedBlockingQueue<Piece>()
    private val incoming = java.util.concurrent.ConcurrentHashMap<Long, InFile>()
    @Volatile private var closed = false
    val laneCount: Int get() = lanes.size
    private val cancelledOut = java.util.concurrent.ConcurrentHashMap.newKeySet<Long>()
    private val cancelledIn = java.util.concurrent.ConcurrentHashMap.newKeySet<Long>()

    /** Stop sending one of our files (queued or half-way). The other side deletes its partial copy. */
    fun cancelOutgoing(id: Long) {
        cancelledOut.add(id)
        files.removeIf { it.first == id }
        pieces.removeIf { p -> if (p.id == id) { p.left.decrementAndGet(); true } else false }
        control.add { o -> o.writeByte(T_CANCEL); o.writeLong(id); o.writeBoolean(true) }
    }

    /** Stop receiving a file the other side is sending (remoteId = its id). Our partial copy is deleted. */
    fun cancelIncoming(remoteId: Long) {
        cancelledIn.add(remoteId)
        dropIncoming(remoteId)
        control.add { o -> o.writeByte(T_CANCEL); o.writeLong(remoteId); o.writeBoolean(false) }
    }

    private fun dropIncoming(remoteId: Long) {
        incoming.remove(remoteId)?.let { f ->
            if (f.done.compareAndSet(false, true)) f.sink?.let { sk -> runCatching { synchronized(sk) { sk.abort() } } }
        }
    }

    fun start() {
        val l = Lane(main)
        lanes.add(l)
        runCatching { main.soTimeout = 20_000 } // the other side pings every 3 s; silence = dead link
        startLane(l, isMain = true)
        Thread({ fileLoop() }, "turbo-files").start()
    }

    /** Extra data lane (after the main link is up). */
    fun addLane(s: Socket) {
        if (closed) { runCatching { s.close() }; return }
        val l = Lane(s)
        lanes.add(l)
        startLane(l, isMain = false)
    }

    fun sendBatch(count: Int, bytes: Long) = control.add { it.writeByte(T_BATCH); it.writeInt(count); it.writeLong(bytes) }
    fun sendFile(id: Long, f: PickedFile) { files.add(id to f) }
    fun sendBye() = control.add { it.writeByte(T_BYE) }
    fun sendHello(name: String) = control.add { it.writeByte(T_HELLO); it.writeUTF(name) }
    fun probeDelay() = control.add { it.writeByte(T_ECHO_Q); it.writeLong(System.nanoTime()) }
    fun offerLanes(port: Int, count: Int) = control.add { it.writeByte(T_LANES); it.writeInt(port); it.writeInt(count) }

    fun close() {
        if (closed) return
        closed = true
        for (l in lanes) runCatching { l.s.close() }
        ui { cb.onClosed() }
    }

    private fun startLane(l: Lane, isMain: Boolean) {
        Thread({ writerLoop(l, isMain) }, "turbo-w").apply { priority = Thread.MAX_PRIORITY }.start()
        Thread({ readerLoop(l) }, "turbo-r").apply { priority = Thread.MAX_PRIORITY }.start()
    }

    /** One file at a time: announce it, cut it into pieces, let all lanes send them. */
    private fun fileLoop() {
        try {
            while (!closed) {
                val (id, f) = files.poll(200, TimeUnit.MILLISECONDS) ?: continue
                if (id in cancelledOut) continue
                val src = openSource(f)
                if (src == null) { ui { cb.onOutgoingDone(id, false) }; continue }
                try {
                    val size = runCatching { src.channel.size() }.getOrDefault(f.size)
                    val announced = java.util.concurrent.CountDownLatch(1)
                    control.add { o -> o.writeByte(T_START); o.writeLong(id); o.writeUTF(f.name); o.writeLong(size); o.flush(); announced.countDown() }
                    announced.await(20, TimeUnit.SECONDS)
                    val sent = java.util.concurrent.atomic.AtomicLong(0)
                    val n = ((size + PIECE - 1) / PIECE).toInt()
                    val left = java.util.concurrent.atomic.AtomicInteger(n)
                    var off = 0L
                    while (off < size) {
                        val len = minOf(PIECE.toLong(), size - off).toInt()
                        pieces.put(Piece(id, src.channel, off, len, sent, left))
                        off += len
                    }
                    var lastUi = 0L
                    while (left.get() > 0 && !closed && id !in cancelledOut) {
                        Thread.sleep(50)
                        val now = System.currentTimeMillis()
                        if (now - lastUi > 400) { lastUi = now; val d = sent.get(); ui { cb.onOutgoingProgress(id, d) } }
                    }
                    val d = sent.get()
                    if (id !in cancelledOut) ui { cb.onOutgoingProgress(id, d) }
                } finally {
                    src.close()
                }
            }
        } catch (_: Exception) {
            close()
        }
    }

    private fun writerLoop(l: Lane, isMain: Boolean) {
        val buf = java.nio.ByteBuffer.allocate(PIECE)
        var lastPing = System.currentTimeMillis()
        try {
            while (!closed) {
                if (isMain) {
                    while (true) { val m = control.poll() ?: break; m(l.out) }
                }
                val p = pieces.poll(if (isMain) 100 else 300, TimeUnit.MILLISECONDS)
                if (p == null) {
                    if (isMain && System.currentTimeMillis() - lastPing > 3000) { l.out.writeByte(T_PING); lastPing = System.currentTimeMillis() }
                    l.out.flush()
                    continue
                }
                if (p.id in cancelledOut) { p.left.decrementAndGet(); continue }
                buf.clear(); buf.limit(p.len)
                var pos = p.off
                while (buf.hasRemaining()) { val r = p.src.read(buf, pos); if (r < 0) break; pos += r }
                val n = buf.position()
                l.out.writeByte(T_PIECE); l.out.writeLong(p.id); l.out.writeLong(p.off); l.out.writeInt(n)
                l.out.write(buf.array(), 0, n)
                l.out.flush()
                p.sent.addAndGet(n.toLong())
                p.left.decrementAndGet()
                if (isMain) lastPing = System.currentTimeMillis()
            }
        } catch (_: Exception) {
            close()
        }
    }

    private fun readerLoop(l: Lane) {
        val buf = ByteArray(PIECE)
        try {
            while (!closed) {
                when (l.inp.readByte().toInt()) {
                    T_PING -> {}
                    T_BATCH -> { val c = l.inp.readInt(); val b = l.inp.readLong(); ui { cb.onBatch(c, b) } }
                    T_START -> {
                        val id = l.inp.readLong(); val name = l.inp.readUTF(); val size = l.inp.readLong()
                        val f = InFile(openSink(name, size), size)
                        incoming[id] = f
                        ui { cb.onIncomingStart(id, name, size) }
                        if (size == 0L) finishIncoming(id, f)
                    }
                    T_PIECE -> {
                        val id = l.inp.readLong(); val off = l.inp.readLong(); val n = l.inp.readInt()
                        l.inp.readFully(buf, 0, n)
                        // a piece can overtake its file's announcement on another lane: wait a moment for it
                        var f = incoming[id]
                        var waited = 0
                        while (f == null && waited < 15_000 && !closed && id !in cancelledIn) { Thread.sleep(5); waited += 5; f = incoming[id] }
                        if (f != null) {
                            f.sink?.let { sk ->
                                val bb = java.nio.ByteBuffer.wrap(buf, 0, n)
                                var pos = off
                                synchronized(sk) { while (bb.hasRemaining()) pos += sk.channel.write(bb, pos) }
                            }
                            val got = f.got.addAndGet(n.toLong())
                            val now = System.currentTimeMillis()
                            if (now - f.lastUi > 400) { f.lastUi = now; ui { cb.onIncomingProgress(id, got) } }
                            if (got >= f.size) finishIncoming(id, f)
                        }
                    }
                    T_ACK -> { val id = l.inp.readLong(); val ok = l.inp.readBoolean(); ui { cb.onOutgoingDone(id, ok) } }
                    T_BYE -> ui { cb.onBye() }
                    T_HELLO -> { val n = l.inp.readUTF(); ui { cb.onHello(n) } }
                    T_ECHO_Q -> { val t = l.inp.readLong(); control.add { o -> o.writeByte(T_ECHO_A); o.writeLong(t) } }
                    T_ECHO_A -> { val t = l.inp.readLong(); val ms = (System.nanoTime() - t) / 1_000_000; ui { cb.onDelay(ms) } }
                    T_LANES -> { val port = l.inp.readInt(); val c = l.inp.readInt(); ui { cb.onLanesOffer(port, c) } }
                    T_CANCEL -> {
                        val id = l.inp.readLong(); val fromSender = l.inp.readBoolean()
                        if (fromSender) { cancelledIn.add(id); dropIncoming(id); ui { cb.onIncomingCancelled(id) } }
                        else {
                            cancelledOut.add(id)
                            files.removeIf { it.first == id }
                            pieces.removeIf { p -> if (p.id == id) { p.left.decrementAndGet(); true } else false }
                            ui { cb.onOutgoingCancelled(id) }
                        }
                    }
                    else -> throw java.io.IOException("bad message")
                }
            }
        } catch (_: Exception) {
            close()
        }
    }

    private fun finishIncoming(id: Long, f: InFile) {
        if (!f.done.compareAndSet(false, true)) return
        incoming.remove(id)
        val uri = f.sink?.let { sk -> runCatching { synchronized(sk) { sk.channel.force(false) }; sk.finish() }.getOrNull() }
        val ok = uri != null
        control.add { o -> o.writeByte(T_ACK); o.writeLong(id); o.writeBoolean(ok) }
        ui { cb.onIncomingProgress(id, f.size); cb.onIncomingDone(id, uri) }
    }

    private companion object {
        const val PIECE = 512 * 1024
        const val T_PING = 0
        const val T_BATCH = 1
        const val T_START = 2
        const val T_PIECE = 3
        const val T_ACK = 5
        const val T_BYE = 6
        const val T_HELLO = 7
        const val T_ECHO_Q = 8
        const val T_ECHO_A = 9
        const val T_LANES = 10
        const val T_CANCEL = 11
    }
}
