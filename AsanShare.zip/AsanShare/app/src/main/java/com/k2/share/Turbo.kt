package com.k2.share

import android.annotation.SuppressLint
import android.content.Context
import android.net.wifi.WifiManager
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume

/**
 * TURBO: Asan Share's own fast link (like Zapya / SHAREit).
 * One phone creates a private Wi-Fi Direct network (5 GHz when possible), the other joins it,
 * and files stream directly over one TCP connection, in both directions.
 */
object Turbo {
    const val PORT = 39871
    private const val GO_IP = "192.168.49.1" // standard Wi-Fi Direct group-owner address

    fun supported() = Build.VERSION.SDK_INT >= 29

    /** Last thing that went wrong (shown to the user, helps fixing phone-specific problems). */
    @Volatile var lastError: String? = null

    private var manager: WifiP2pManager? = null
    private var channel: WifiP2pManager.Channel? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var wakeLock: PowerManager.WakeLock? = null

    private fun mgr(ctx: Context): Pair<WifiP2pManager, WifiP2pManager.Channel>? {
        val m = manager ?: (ctx.getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager) ?: return null
        val c = channel ?: m.initialize(ctx, Looper.getMainLooper(), null) ?: return null
        manager = m; channel = c
        return m to c
    }

    fun newCredentials(): Pair<String, String> {
        val abc = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        fun rnd(n: Int) = (1..n).map { abc.random() }.joinToString("")
        return "DIRECT-AS-" + rnd(4) to rnd(12)
    }

    @SuppressLint("MissingPermission")
    private suspend fun removeGroup(m: WifiP2pManager, c: WifiP2pManager.Channel) =
        withTimeoutOrNull(3000) {
            suspendCancellableCoroutine { k ->
                m.removeGroup(c, object : WifiP2pManager.ActionListener {
                    override fun onSuccess() { if (k.isActive) k.resume(Unit) }
                    override fun onFailure(reason: Int) { if (k.isActive) k.resume(Unit) }
                })
            }
        }

    private fun reasonText(r: Int) = when (r) {
        WifiP2pManager.P2P_UNSUPPORTED -> "Wi-Fi Direct not supported"
        WifiP2pManager.BUSY -> "Wi-Fi busy"
        else -> "error $r"
    }

    @SuppressLint("MissingPermission")
    private suspend fun call(what: String, block: (WifiP2pManager.ActionListener) -> Unit): Boolean =
        withTimeoutOrNull(8000) {
            suspendCancellableCoroutine { k ->
                block(object : WifiP2pManager.ActionListener {
                    override fun onSuccess() { if (k.isActive) k.resume(true) }
                    override fun onFailure(reason: Int) { lastError = "$what: ${reasonText(reason)}"; if (k.isActive) k.resume(false) }
                })
            }
        } ?: run { lastError = "$what: no answer"; false }

    @SuppressLint("MissingPermission")
    private suspend fun groupOwnerIp(m: WifiP2pManager, c: WifiP2pManager.Channel): String? =
        withTimeoutOrNull(3000) {
            suspendCancellableCoroutine { k ->
                m.requestConnectionInfo(c) { info ->
                    val ip = if (info != null && info.groupFormed) info.groupOwnerAddress?.hostAddress else null
                    if (k.isActive) k.resume(ip)
                }
            }
        }

    /** Host: make the private network and wait for the other phone. */
    @SuppressLint("MissingPermission")
    suspend fun host(ctx: Context, ssid: String, pass: String): Socket? {
        if (!supported()) return null
        val (m, c) = mgr(ctx) ?: run { lastError = "Wi-Fi Direct not available"; return null }
        lastError = null
        var ok = false
        // The pairing link may still be holding Wi-Fi for a few seconds: keep trying for up to 25 s.
        val until = System.currentTimeMillis() + 25_000
        while (!ok && System.currentTimeMillis() < until) {
            removeGroup(m, c)
            // Try 5 GHz first (fastest), then let the phone choose
            for (band in intArrayOf(WifiP2pConfig.GROUP_OWNER_BAND_5GHZ, WifiP2pConfig.GROUP_OWNER_BAND_AUTO)) {
                val cfg = runCatching {
                    WifiP2pConfig.Builder().setNetworkName(ssid).setPassphrase(pass).setGroupOperatingBand(band).build()
                }.getOrNull() ?: continue
                ok = call("Create network") { l -> m.createGroup(c, cfg, l) }
                if (ok) break
            }
            if (!ok) delay(1500)
        }
        if (!ok) return null
        return withContext(Dispatchers.IO) {
            runCatching {
                ServerSocket().use { ss ->
                    ss.reuseAddress = true
                    ss.receiveBufferSize = 4 shl 20
                    ss.bind(InetSocketAddress(PORT))
                    ss.soTimeout = 50_000
                    ss.accept()
                }
            }.onFailure { lastError = "Other phone didn't join" }.getOrNull()
        }?.also { tune(it) }
    }

    /** Client: join the other phone's private network and connect. */
    @SuppressLint("MissingPermission")
    suspend fun join(ctx: Context, ssid: String, pass: String): Socket? {
        if (!supported()) return null
        val (m, c) = mgr(ctx) ?: run { lastError = "Wi-Fi Direct not available"; return null }
        lastError = null
        val cfg = runCatching {
            WifiP2pConfig.Builder().setNetworkName(ssid).setPassphrase(pass)
                .setGroupOperatingBand(WifiP2pConfig.GROUP_OWNER_BAND_AUTO).build()
        }.getOrNull() ?: run { lastError = "Bad network details"; return null }
        // The host needs a few seconds to free Wi-Fi and create its network: keep asking for up to 35 s
        delay(2500)
        var joined = false
        val joinUntil = System.currentTimeMillis() + 35_000
        while (!joined && System.currentTimeMillis() < joinUntil) {
            removeGroup(m, c)
            joined = call("Join network") { l -> m.connect(c, cfg, l) }
            if (!joined) delay(2000)
        }
        if (!joined) return null
        // Keep trying to reach the host until the link is really up
        val deadline = System.currentTimeMillis() + 35_000
        while (System.currentTimeMillis() < deadline) {
            val ip = groupOwnerIp(m, c) ?: GO_IP
            val s = withContext(Dispatchers.IO) {
                runCatching {
                    Socket().apply {
                        receiveBufferSize = 4 shl 20
                        sendBufferSize = 4 shl 20
                        connect(InetSocketAddress(ip, PORT), 2500)
                    }
                }.getOrNull()
            }
            if (s != null) return s.also { tune(it) }
            delay(1000)
        }
        lastError = "Couldn't reach the other phone"
        return null
    }

    private fun tune(s: Socket) {
        runCatching {
            s.tcpNoDelay = false
            s.sendBufferSize = 4 shl 20
            s.receiveBufferSize = 4 shl 20
            s.keepAlive = true
        }
    }

    /** Keep Wi-Fi at full speed and the CPU awake while Turbo is running. */
    @Suppress("DEPRECATION")
    fun holdLocks(ctx: Context) {
        runCatching {
            val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY else WifiManager.WIFI_MODE_FULL_HIGH_PERF
            if (wifiLock == null) wifiLock = wm.createWifiLock(mode, "asan:turbo").apply { acquire() }
        }
        runCatching {
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            if (wakeLock == null) wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "asan:turbo").apply { acquire(6 * 60 * 60 * 1000L) }
        }
    }

    /** Leave/remove the private network and release locks. */
    suspend fun shutdown(ctx: Context) {
        runCatching { wifiLock?.release() }; wifiLock = null
        runCatching { if (wakeLock?.isHeld == true) wakeLock?.release() }; wakeLock = null
        val mc = mgr(ctx) ?: return
        removeGroup(mc.first, mc.second)
    }
}

/** Where an incoming file is written (straight to its final place: no copying afterwards). */
interface Sink {
    val out: OutputStream
    fun finish(): android.net.Uri?
    fun abort()
}

/**
 * One TCP connection carrying everything, both ways.
 * Files are cut into chunks so small messages (acknowledgements, "bye") never wait behind a big movie.
 */
class TurboLink(
    private val socket: Socket,
    private val openInput: (PickedFile) -> InputStream?,
    private val openSink: (String, Long) -> Sink?,
    private val cb: Callbacks,
) {
    interface Callbacks {
        fun onBatch(count: Int, bytes: Long)
        fun onIncomingStart(remoteId: Long, name: String, size: Long)
        fun onIncomingProgress(remoteId: Long, done: Long)
        fun onIncomingDone(remoteId: Long, saved: android.net.Uri?)
        fun onOutgoingProgress(id: Long, done: Long)
        fun onOutgoingDone(id: Long, ok: Boolean)
        fun onBye()
        fun onClosed()
    }

    private val main = Handler(Looper.getMainLooper())
    private fun ui(block: () -> Unit) = main.post(block)

    private val out = DataOutputStream(BufferedOutputStream(socket.getOutputStream(), 1 shl 20))
    private val inp = DataInputStream(BufferedInputStream(socket.getInputStream(), 1 shl 20))
    private val control = ConcurrentLinkedQueue<(DataOutputStream) -> Unit>()
    private val files = LinkedBlockingQueue<Pair<Long, PickedFile>>()
    @Volatile private var closed = false

    fun start() {
        Thread({ writerLoop() }, "turbo-write").apply { priority = Thread.MAX_PRIORITY }.start()
        Thread({ readerLoop() }, "turbo-read").apply { priority = Thread.MAX_PRIORITY }.start()
    }

    fun sendBatch(count: Int, bytes: Long) = control.add { it.writeByte(T_BATCH); it.writeInt(count); it.writeLong(bytes) }
    fun sendFile(id: Long, f: PickedFile) { files.add(id to f) }
    fun sendBye() = control.add { it.writeByte(T_BYE) }

    fun close() {
        if (closed) return
        closed = true
        runCatching { socket.close() }
        ui { cb.onClosed() }
    }

    private fun drainControl() {
        while (true) {
            val m = control.poll() ?: break
            m(out)
        }
    }

    private fun writerLoop() {
        val buf = ByteArray(512 * 1024)
        var lastPing = System.currentTimeMillis()
        try {
            while (!closed) {
                drainControl()
                val job = files.poll(150, TimeUnit.MILLISECONDS)
                if (job == null) {
                    if (System.currentTimeMillis() - lastPing > 3000) { out.writeByte(T_PING); lastPing = System.currentTimeMillis() }
                    out.flush()
                    continue
                }
                val (id, f) = job
                val input = openInput(f)
                if (input == null) { ui { cb.onOutgoingDone(id, false) }; continue }
                input.use { ins ->
                    out.writeByte(T_START); out.writeLong(id); out.writeUTF(f.name); out.writeLong(f.size)
                    var sent = 0L
                    var lastUi = 0L
                    while (!closed) {
                        drainControl()
                        val n = ins.read(buf)
                        if (n < 0) break
                        out.writeByte(T_CHUNK); out.writeLong(id); out.writeInt(n); out.write(buf, 0, n)
                        sent += n
                        val now = System.currentTimeMillis()
                        if (now - lastUi > 150) { lastUi = now; val s = sent; ui { cb.onOutgoingProgress(id, s) } }
                    }
                    out.writeByte(T_END); out.writeLong(id)
                    out.flush()
                    val s = sent
                    ui { cb.onOutgoingProgress(id, s) }
                    lastPing = System.currentTimeMillis()
                }
            }
        } catch (_: Exception) {
            close()
        }
    }

    private fun readerLoop() {
        val sinks = HashMap<Long, Sink>()
        val got = HashMap<Long, Long>()
        val lastUi = HashMap<Long, Long>()
        val buf = ByteArray(512 * 1024)
        try {
            socket.soTimeout = 20_000 // the other side pings every 3 s; silence means the link died
            while (!closed) {
                when (inp.readByte().toInt()) {
                    T_PING -> {}
                    T_BATCH -> { val c = inp.readInt(); val b = inp.readLong(); ui { cb.onBatch(c, b) } }
                    T_START -> {
                        val id = inp.readLong(); val name = inp.readUTF(); val size = inp.readLong()
                        openSink(name, size)?.let { sinks[id] = it }
                        got[id] = 0
                        ui { cb.onIncomingStart(id, name, size) }
                    }
                    T_CHUNK -> {
                        val id = inp.readLong(); var left = inp.readInt()
                        val sink = sinks[id]
                        while (left > 0) {
                            val n = inp.read(buf, 0, minOf(left, buf.size))
                            if (n < 0) throw java.io.EOFException()
                            sink?.out?.write(buf, 0, n)
                            left -= n
                            got[id] = (got[id] ?: 0) + n
                        }
                        val now = System.currentTimeMillis()
                        if (now - (lastUi[id] ?: 0) > 150) { lastUi[id] = now; val d = got[id] ?: 0; ui { cb.onIncomingProgress(id, d) } }
                    }
                    T_END -> {
                        val id = inp.readLong()
                        val sink = sinks.remove(id)
                        val uri = sink?.let { runCatching { it.out.close(); it.finish() }.getOrNull() }
                        val ok = uri != null
                        control.add { o -> o.writeByte(T_ACK); o.writeLong(id); o.writeBoolean(ok) }
                        ui { cb.onIncomingDone(id, uri) }
                    }
                    T_ACK -> { val id = inp.readLong(); val ok = inp.readBoolean(); ui { cb.onOutgoingDone(id, ok) } }
                    T_BYE -> ui { cb.onBye() }
                    else -> throw java.io.IOException("bad message")
                }
            }
        } catch (_: Exception) {
            for (s in sinks.values) runCatching { s.out.close(); s.abort() }
            close()
        }
    }

    private companion object {
        const val T_PING = 0
        const val T_BATCH = 1
        const val T_START = 2
        const val T_CHUNK = 3
        const val T_END = 4
        const val T_ACK = 5
        const val T_BYE = 6
    }
}
