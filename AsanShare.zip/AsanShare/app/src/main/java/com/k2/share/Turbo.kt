package com.k2.share

import android.annotation.SuppressLint
import android.content.Context
import android.net.wifi.WifiManager
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume

/**
 * TURBO: Asan Share's own fast link (like Zapya / SHAREit).
 * One phone creates a private Wi-Fi Direct network (5 GHz when possible), the other joins it,
 * and files stream directly over one TCP connection, in both directions.
 */
object Turbo {
    const val PORT = 39871
    private const val GO_IP = "192.168.49.1" // standard Wi-Fi Direct group-owner address

    fun supported() = Build.VERSION.SDK_INT >= 29

    /** Last thing that went wrong (shown to the user, helps fixing phone-specific problems). */
    @Volatile var lastError: String? = null
        set(v) { field = v; if (v != null) log("Problem: $v") }

    /** Step-by-step log, shown in "Connection details". */
    var logger: ((String) -> Unit)? = null
    private val mainH = Handler(Looper.getMainLooper())
    fun log(msg: String) { mainH.post { logger?.invoke(msg) } }

    private var manager: WifiP2pManager? = null
    private var channel: WifiP2pManager.Channel? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var wakeLock: PowerManager.WakeLock? = null

    private fun mgr(ctx: Context): Pair<WifiP2pManager, WifiP2pManager.Channel>? {
        val m = manager ?: (ctx.getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager) ?: return null
        val c = channel ?: m.initialize(ctx, Looper.getMainLooper(), null) ?: return null
        manager = m; channel = c
        return m to c
    }

    // ---------- Zapya-style groups ----------
    const val GROUP_PREFIX = "DIRECT-AS-AS_"

    /** Network name shown to the other phone, e.g. "DIRECT-AS-Javeds Tab A7". */
    fun groupName(deviceName: String): String {
        val clean = deviceName.filter { it.isLetterOrDigit() || it == ' ' }.trim().take(19).ifEmpty { "Phone" }
        return GROUP_PREFIX + clean
    }

    /** Both apps can work out the password from the name, so no typing is needed. */
    fun groupPass(ssid: String): String {
        val d = java.security.MessageDigest.getInstance("SHA-256").digest(("asan-share-k2:" + ssid).toByteArray())
        return d.joinToString("") { "%02x".format(it) }.take(12)
    }

    /** Asan Share groups around us (names starting with DIRECT-AS-). */
    @Suppress("DEPRECATION")
    @SuppressLint("MissingPermission")
    fun scanGroups(ctx: Context, newScan: Boolean): List<Pair<String, Int>> {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager ?: return emptyList()
        // Android allows only ~4 fresh scans per 2 minutes, so we ask for one every 30 s and read results often
        if (newScan) runCatching { wm.startScan() }
        return runCatching {
            wm.scanResults.filter { it.SSID?.startsWith(GROUP_PREFIX) == true }
                .groupBy { it.SSID }.map { (ssid, list) -> ssid to list.maxOf { it.level } }
                .sortedByDescending { it.second }
        }.getOrDefault(emptyList())
    }

    fun newCredentials(): Pair<String, String> {
        val abc = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        fun rnd(n: Int) = (1..n).map { abc.random() }.joinToString("")
        return "DIRECT-AS-" + rnd(4) to rnd(12)
    }

    @SuppressLint("MissingPermission")
    private suspend fun removeGroup(m: WifiP2pManager, c: WifiP2pManager.Channel) =
        withTimeoutOrNull(3000) {
            suspendCancellableCoroutine { k ->
                m.removeGroup(c, object : WifiP2pManager.ActionListener {
                    override fun onSuccess() { if (k.isActive) k.resume(Unit) }
                    override fun onFailure(reason: Int) { if (k.isActive) k.resume(Unit) }
                })
            }
        }

    private fun reasonText(r: Int) = when (r) {
        WifiP2pManager.P2P_UNSUPPORTED -> "Wi-Fi Direct not supported"
        WifiP2pManager.BUSY -> "Wi-Fi busy"
        else -> "error $r"
    }

    @SuppressLint("MissingPermission")
    private suspend fun call(what: String, block: (WifiP2pManager.ActionListener) -> Unit): Boolean =
        withTimeoutOrNull(8000) {
            suspendCancellableCoroutine { k ->
                block(object : WifiP2pManager.ActionListener {
                    override fun onSuccess() { if (k.isActive) k.resume(true) }
                    override fun onFailure(reason: Int) { lastError = "$what: ${reasonText(reason)}"; if (k.isActive) k.resume(false) }
                })
            }
        } ?: run { lastError = "$what: no answer"; false }

    @SuppressLint("MissingPermission")
    private suspend fun groupOwnerIp(m: WifiP2pManager, c: WifiP2pManager.Channel): String? =
        withTimeoutOrNull(3000) {
            suspendCancellableCoroutine { k ->
                m.requestConnectionInfo(c) { info ->
                    val ip = if (info != null && info.groupFormed) info.groupOwnerAddress?.hostAddress else null
                    if (k.isActive) k.resume(ip)
                }
            }
        }

    /** Host: make the private network and wait for the other phone. */
    @SuppressLint("MissingPermission")
    @Volatile private var activeServer: ServerSocket? = null
    /** Stop waiting for the other phone (it told us it can't join). */
    fun cancelAccept() { runCatching { activeServer?.close() } }

    suspend fun host(
        ctx: Context, ssid: String, pass: String,
        createMs: Long = 25_000, acceptMs: Int = 50_000, onReady: (() -> Unit)? = null,
    ): Socket? {
        if (!supported()) return null
        val (m, c) = mgr(ctx) ?: run { lastError = "Wi-Fi Direct not available"; return null }
        lastError = null
        var ok = false
        // The pairing link may still be holding Wi-Fi for a few seconds: keep trying for up to 25 s.
        val until = System.currentTimeMillis() + createMs
        while (!ok && System.currentTimeMillis() < until) {
            removeGroup(m, c)
            // Try 5 GHz first (fastest), then let the phone choose
            for (band in intArrayOf(WifiP2pConfig.GROUP_OWNER_BAND_5GHZ, WifiP2pConfig.GROUP_OWNER_BAND_AUTO)) {
                val cfg = runCatching {
                    WifiP2pConfig.Builder().setNetworkName(ssid).setPassphrase(pass).setGroupOperatingBand(band).build()
                }.getOrNull() ?: continue
                log("Creating private Wi-Fi (" + (if (band == WifiP2pConfig.GROUP_OWNER_BAND_5GHZ) "5 GHz" else "auto band") + ")")
                ok = call("Create network") { l -> m.createGroup(c, cfg, l) }
                if (ok) break
            }
            if (!ok) delay(1500)
        }
        if (!ok) return null
        log("Private Wi-Fi ready, waiting for the other phone")
        return withContext(Dispatchers.IO) {
            runCatching {
                ServerSocket().use { ss ->
                    ss.reuseAddress = true
                    ss.receiveBufferSize = 4 shl 20
                    ss.bind(InetSocketAddress(PORT))
                    ss.soTimeout = acceptMs
                    activeServer = ss
                    onReady?.let { mainH.post(it) } // now tell the other phone to join
                    ss.accept()
                }
            }.onFailure { lastError = "Other phone didn't join" }.getOrNull().also { activeServer = null }
        }?.also { tune(it) }
    }

    /** Client: join the other phone's private network and connect. */
    @SuppressLint("MissingPermission")
    suspend fun join(
        ctx: Context, ssid: String, pass: String,
        firstDelay: Long = 2500, joinMs: Long = 35_000, formedMs: Long = 30_000, connectMs: Long = 25_000,
    ): Socket? {
        if (!supported()) return null
        val (m, c) = mgr(ctx) ?: run { lastError = "Wi-Fi Direct not available"; return null }
        lastError = null
        val cfg = runCatching {
            WifiP2pConfig.Builder().setNetworkName(ssid).setPassphrase(pass)
                .setGroupOperatingBand(WifiP2pConfig.GROUP_OWNER_BAND_AUTO).build()
        }.getOrNull() ?: run { lastError = "Bad network details"; return null }
        // The host needs a few seconds to free Wi-Fi and create its network: keep asking for up to 35 s
        delay(firstDelay)
        var joined = false
        val joinUntil = System.currentTimeMillis() + joinMs
        while (!joined && System.currentTimeMillis() < joinUntil) {
            removeGroup(m, c)
            log("Joining private Wi-Fi")
            joined = call("Join network") { l -> m.connect(c, cfg, l) }
            if (!joined) delay(2000)
        }
        if (!joined) return null
        // "Join" only means the request was accepted: wait until we are really in the network
        var ip: String? = null
        val formedUntil = System.currentTimeMillis() + formedMs
        while (ip == null && System.currentTimeMillis() < formedUntil) {
            ip = groupOwnerIp(m, c)
            if (ip == null) delay(700)
        }
        if (ip == null) { lastError = "Couldn't join the private Wi-Fi"; return null }
        log("Joined private Wi-Fi (host $ip)")
        val hostIp: String = ip ?: GO_IP
        // Now reach the host's Turbo port
        val deadline = System.currentTimeMillis() + connectMs
        while (System.currentTimeMillis() < deadline) {
            val s = withContext(Dispatchers.IO) {
                runCatching {
                    Socket().apply {
                        receiveBufferSize = 4 shl 20
                        sendBufferSize = 4 shl 20
                        connect(InetSocketAddress(hostIp, PORT), 2500)
                    }
                }.getOrNull()
            }
            if (s != null) { log("Connected to $hostIp"); return s.also { tune(it) } }
            delay(1000)
        }
        lastError = "Couldn't reach the other phone"
        return null
    }

    fun tune(s: Socket) {
        runCatching {
            s.tcpNoDelay = false
            s.sendBufferSize = 4 shl 20
            s.receiveBufferSize = 4 shl 20
            s.keepAlive = true
        }
    }

    /** Keep Wi-Fi at full speed and the CPU awake while Turbo is running. */
    @Suppress("DEPRECATION")
    fun holdLocks(ctx: Context) {
        runCatching {
            val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY else WifiManager.WIFI_MODE_FULL_HIGH_PERF
            if (wifiLock == null) wifiLock = wm.createWifiLock(mode, "asan:turbo").apply { acquire() }
        }
        runCatching {
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            if (wakeLock == null) wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "asan:turbo").apply { acquire(6 * 60 * 60 * 1000L) }
        }
    }

    /** Leave/remove the private network and release locks. */
    // ---------- Asan Share's OWN hotspot (the reliable fast path, like Zapya) ----------
    private var lohReservation: WifiManager.LocalOnlyHotspotReservation? = null
    @Volatile private var lohStopped = false
    private var netCallback: android.net.ConnectivityManager.NetworkCallback? = null

    class HotspotInfo(val ssid: String, val pass: String, val sec: Int)

    /** Host: start a private hotspot that belongs to this app. Returns its name/password, or null. */
    @Suppress("DEPRECATION")
    @SuppressLint("MissingPermission")
    suspend fun startHotspot(ctx: Context): HotspotInfo? {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager ?: return null
        stopHotspot()
        lohStopped = false
        lastError = null
        log("Starting Asan Share's own hotspot")
        return withTimeoutOrNull(15_000) {
            suspendCancellableCoroutine { k ->
                try {
                    wm.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                        override fun onStarted(r: WifiManager.LocalOnlyHotspotReservation) {
                            if (lohStopped || !k.isActive) { runCatching { r.close() }; return }
                            lohReservation = r
                            var info: HotspotInfo? = null
                            if (Build.VERSION.SDK_INT >= 30) {
                                val c = r.softApConfiguration
                                val ssid = c.ssid; val pass = c.passphrase
                                if (ssid != null && pass != null) info = HotspotInfo(ssid, pass, c.securityType)
                            } else {
                                r.wifiConfiguration?.let { w ->
                                    if (w.SSID != null && w.preSharedKey != null) info = HotspotInfo(w.SSID.trim('"'), w.preSharedKey.trim('"'), 1)
                                }
                            }
                            if (info == null) lastError = "hotspot started but details unreadable"
                            else log("Hotspot ON: ${info!!.ssid}")
                            k.resume(info)
                        }
                        override fun onFailed(reason: Int) {
                            lastError = when (reason) {
                                WifiManager.LocalOnlyHotspotCallback.ERROR_INCOMPATIBLE_MODE -> "hotspot busy (another hotspot/Wi-Fi mode is on)"
                                WifiManager.LocalOnlyHotspotCallback.ERROR_TETHERING_DISALLOWED -> "this device doesn't allow hotspots"
                                WifiManager.LocalOnlyHotspotCallback.ERROR_NO_CHANNEL -> "no free Wi-Fi channel for a hotspot"
                                else -> "hotspot error $reason"
                            }
                            if (k.isActive) k.resume(null)
                        }
                    }, Handler(Looper.getMainLooper()))
                } catch (e: Exception) {
                    lastError = "hotspot not allowed: ${e.message}"
                    if (k.isActive) k.resume(null)
                }
            }
        } ?: run { if (lastError == null) lastError = "this device didn't start a hotspot (it may not support one)"; null }
    }

    fun stopHotspot() {
        lohStopped = true
        runCatching { lohReservation?.close() }
        lohReservation = null
    }

    /**
     * Client: join the other phone's Asan Share hotspot as OUR OWN network (Android 10+).
     * Android shows a one-time "Connect to device?" popup here.
     */
    @SuppressLint("MissingPermission")
    suspend fun joinHotspot(ctx: Context, ssid: String, pass: String, sec: Int, timeoutMs: Long = 70_000): android.net.Network? {
        if (Build.VERSION.SDK_INT < 29) { lastError = "Android 10+ needed to join"; return null }
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        leaveHotspot(ctx)
        lastError = null
        val spec = runCatching {
            val b = android.net.wifi.WifiNetworkSpecifier.Builder().setSsid(ssid)
            if (sec == 3) b.setWpa3Passphrase(pass) else b.setWpa2Passphrase(pass) // 3 = WPA3-only
            b.build()
        }.getOrNull() ?: run { lastError = "bad hotspot details"; return null }
        val req = android.net.NetworkRequest.Builder()
            .addTransportType(android.net.NetworkCapabilities.TRANSPORT_WIFI)
            .removeCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .setNetworkSpecifier(spec)
            .build()
        log("Joining the other phone's hotspot (tap Connect if Android asks)")
        return withTimeoutOrNull(timeoutMs) {
            suspendCancellableCoroutine { k ->
                val cb = object : android.net.ConnectivityManager.NetworkCallback() {
                    override fun onAvailable(network: android.net.Network) { log("Joined the hotspot"); if (k.isActive) k.resume(network) }
                    override fun onUnavailable() { lastError = "couldn't join the hotspot (cancelled or not found)"; if (k.isActive) k.resume(null) }
                }
                netCallback = cb
                runCatching { cm.requestNetwork(req, cb) }.onFailure { lastError = "join failed: ${it.message}"; if (k.isActive) k.resume(null) }
            }
        } ?: run { if (lastError == null) lastError = "joining the hotspot timed out"; null }
    }

    fun leaveHotspot(ctx: Context) {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        netCallback?.let { runCatching { cm.unregisterNetworkCallback(it) } }
        netCallback = null
    }

    /** Addresses of the hotspot owner as seen from the joined network (its gateway / DHCP server). */
    fun gatewayOf(ctx: Context, network: android.net.Network): List<String> {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        val lp = cm.getLinkProperties(network) ?: return emptyList()
        val out = ArrayList<String>()
        lp.routes.forEach { r -> if (r.hasGateway()) r.gateway?.hostAddress?.let { if (!it.contains(":")) out += it } }
        if (Build.VERSION.SDK_INT >= 30) lp.dhcpServerAddress?.hostAddress?.let { out += it }
        return out.distinct()
    }

    /** Connect over a specific network (the joined hotspot), never over mobile data. */
    suspend fun connectOn(network: android.net.Network, ips: List<String>, port: Int, totalMs: Long = 20_000): Socket? = withContext(Dispatchers.IO) {
        val deadline = System.currentTimeMillis() + totalMs
        while (System.currentTimeMillis() < deadline) {
            for (ip in ips) {
                val s = runCatching {
                    network.socketFactory.createSocket().apply {
                        receiveBufferSize = 4 shl 20; sendBufferSize = 4 shl 20
                        connect(InetSocketAddress(ip, port), 2000)
                    }
                }.getOrNull()
                if (s != null) { log("Connected to $ip over the hotspot"); tune(s); return@withContext s }
            }
            delay(700)
        }
        lastError = "joined the hotspot but couldn't reach the other phone"
        null
    }

    suspend fun shutdown(ctx: Context, removeOwnGroup: Boolean = false) {
        stopHotspot()
        leaveHotspot(ctx)
        runCatching { wifiLock?.release() }; wifiLock = null
        runCatching { if (wakeLock?.isHeld == true) wakeLock?.release() }; wakeLock = null
        if (!removeOwnGroup) return // never tear down a Wi-Fi link we didn't build
        val mc = mgr(ctx) ?: return
        removeGroup(mc.first, mc.second)
    }

    /** True if this phone has a direct phone-to-phone Wi-Fi link (Wi-Fi Direct or hotspot), not just a router. */
    fun hasDirectLink(): Boolean = runCatching {
        java.net.NetworkInterface.getNetworkInterfaces().toList().any { ni ->
            val n = ni.name.lowercase()
            runCatching { ni.isUp }.getOrDefault(false) &&
                (n.contains("p2p") || n.startsWith("ap") || n.contains("swlan") || n.contains("softap") || n == "wlan1") &&
                runCatching { ni.inetAddresses.toList().any { it is java.net.Inet4Address } }.getOrDefault(false)
        }
    }.getOrDefault(false)

    /** Name of the network interface a connected socket uses (e.g. wlan0 = router, p2p-wlan0-0 = direct). */
    fun ifaceOf(s: Socket): String? = runCatching { java.net.NetworkInterface.getByInetAddress(s.localAddress)?.name }.getOrNull()

    /** Every local IPv4 address that another phone could reach (Wi-Fi Direct, hotspot, home Wi-Fi). Not mobile data. */
    fun localAddresses(): List<String> = runCatching {
        java.net.NetworkInterface.getNetworkInterfaces().toList()
            .filter { ni ->
                val n = ni.name.lowercase()
                runCatching { ni.isUp && !ni.isLoopback }.getOrDefault(false) &&
                    listOf("rmnet", "ccmni", "dummy", "tun", "ipsec", "clat", "v4-", "lo").none { n.startsWith(it) || n.contains("rmnet") }
            }
            .sortedBy { ni ->
                val n = ni.name.lowercase()
                when { n.contains("p2p") -> 0; n.startsWith("ap") || n.contains("swlan") || n.contains("softap") -> 1; n.startsWith("wlan") -> 2; else -> 3 }
            }
            .flatMap { ni -> runCatching { ni.inetAddresses.toList().filterIsInstance<java.net.Inet4Address>() }.getOrDefault(emptyList()) }
            .filter { it.isSiteLocalAddress }
            .mapNotNull { it.hostAddress }
            .distinct()
    }.onFailure { log("Couldn't list network addresses: ${it.message}") }.getOrDefault(emptyList())

    /**
     * Connect to the other phone trying every address it gave us.
     * Each try is made normally AND pinned to each Wi-Fi network, because with mobile data on,
     * Android may otherwise send the connection out over 4G and never reach the other phone.
     */
    @Suppress("DEPRECATION")
    suspend fun connectAny(ctx: Context, ips: List<String>, port: Int, totalMs: Long = 14_000): Socket? = withContext(Dispatchers.IO) {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        val deadline = System.currentTimeMillis() + totalMs
        while (System.currentTimeMillis() < deadline) {
            val wifiNets = runCatching {
                cm.allNetworks.filter { cm.getNetworkCapabilities(it)?.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) == true }
            }.getOrDefault(emptyList())
            for (ip in ips) {
                val makers = listOf<() -> Socket>({ Socket() }) + wifiNets.map { net -> { net.socketFactory.createSocket() } }
                for (make in makers) {
                    val s = runCatching {
                        make().apply {
                            receiveBufferSize = 4 shl 20; sendBufferSize = 4 shl 20
                            connect(InetSocketAddress(ip, port), 1500)
                        }
                    }.getOrNull()
                    if (s != null) { log("Connected to $ip"); tune(s); return@withContext s }
                }
            }
            delay(800)
        }
        null
    }
}

/** Where an incoming file is written (straight to its final place: no copying afterwards). */
interface Sink {
    val out: OutputStream
    fun finish(): android.net.Uri?
    fun abort()
}

/**
 * One TCP connection carrying everything, both ways.
 * Files are cut into chunks so small messages (acknowledgements, "bye") never wait behind a big movie.
 */
class TurboLink(
    private val socket: Socket,
    private val openInput: (PickedFile) -> InputStream?,
    private val openSink: (String, Long) -> Sink?,
    private val cb: Callbacks,
) {
    interface Callbacks {
        fun onBatch(count: Int, bytes: Long)
        fun onIncomingStart(remoteId: Long, name: String, size: Long)
        fun onIncomingProgress(remoteId: Long, done: Long)
        fun onIncomingDone(remoteId: Long, saved: android.net.Uri?)
        fun onOutgoingProgress(id: Long, done: Long)
        fun onOutgoingDone(id: Long, ok: Boolean)
        fun onBye()
        fun onClosed()
        fun onHello(name: String) {}
    }

    private val main = Handler(Looper.getMainLooper())
    private fun ui(block: () -> Unit) = main.post(block)

    private val out = DataOutputStream(BufferedOutputStream(socket.getOutputStream(), 1 shl 20))
    private val inp = DataInputStream(BufferedInputStream(socket.getInputStream(), 1 shl 20))
    private val control = ConcurrentLinkedQueue<(DataOutputStream) -> Unit>()
    private val files = LinkedBlockingQueue<Pair<Long, PickedFile>>()
    @Volatile private var closed = false

    fun start() {
        Thread({ writerLoop() }, "turbo-write").apply { priority = Thread.MAX_PRIORITY }.start()
        Thread({ readerLoop() }, "turbo-read").apply { priority = Thread.MAX_PRIORITY }.start()
    }

    fun sendBatch(count: Int, bytes: Long) = control.add { it.writeByte(T_BATCH); it.writeInt(count); it.writeLong(bytes) }
    fun sendFile(id: Long, f: PickedFile) { files.add(id to f) }
    fun sendBye() = control.add { it.writeByte(T_BYE) }
    fun sendHello(name: String) = control.add { it.writeByte(T_HELLO); it.writeUTF(name) }

    fun close() {
        if (closed) return
        closed = true
        runCatching { socket.close() }
        ui { cb.onClosed() }
    }

    private fun drainControl() {
        while (true) {
            val m = control.poll() ?: break
            m(out)
        }
    }

    private fun writerLoop() {
        val buf = ByteArray(512 * 1024)
        var lastPing = System.currentTimeMillis()
        try {
            while (!closed) {
                drainControl()
                val job = files.poll(150, TimeUnit.MILLISECONDS)
                if (job == null) {
                    if (System.currentTimeMillis() - lastPing > 3000) { out.writeByte(T_PING); lastPing = System.currentTimeMillis() }
                    out.flush()
                    continue
                }
                val (id, f) = job
                val input = openInput(f)
                if (input == null) { ui { cb.onOutgoingDone(id, false) }; continue }
                input.use { ins ->
                    out.writeByte(T_START); out.writeLong(id); out.writeUTF(f.name); out.writeLong(f.size)
                    var sent = 0L
                    var lastUi = 0L
                    while (!closed) {
                        drainControl()
                        val n = ins.read(buf)
                        if (n < 0) break
                        out.writeByte(T_CHUNK); out.writeLong(id); out.writeInt(n); out.write(buf, 0, n)
                        sent += n
                        val now = System.currentTimeMillis()
                        if (now - lastUi > 150) { lastUi = now; val s = sent; ui { cb.onOutgoingProgress(id, s) } }
                    }
                    out.writeByte(T_END); out.writeLong(id)
                    out.flush()
                    val s = sent
                    ui { cb.onOutgoingProgress(id, s) }
                    lastPing = System.currentTimeMillis()
                }
            }
        } catch (_: Exception) {
            close()
        }
    }

    private fun readerLoop() {
        val sinks = HashMap<Long, Sink>()
        val got = HashMap<Long, Long>()
        val lastUi = HashMap<Long, Long>()
        val buf = ByteArray(512 * 1024)
        try {
            socket.soTimeout = 20_000 // the other side pings every 3 s; silence means the link died
            while (!closed) {
                when (inp.readByte().toInt()) {
                    T_PING -> {}
                    T_BATCH -> { val c = inp.readInt(); val b = inp.readLong(); ui { cb.onBatch(c, b) } }
                    T_START -> {
                        val id = inp.readLong(); val name = inp.readUTF(); val size = inp.readLong()
                        openSink(name, size)?.let { sinks[id] = it }
                        got[id] = 0
                        ui { cb.onIncomingStart(id, name, size) }
                    }
                    T_CHUNK -> {
                        val id = inp.readLong(); var left = inp.readInt()
                        val sink = sinks[id]
                        while (left > 0) {
                            val n = inp.read(buf, 0, minOf(left, buf.size))
                            if (n < 0) throw java.io.EOFException()
                            sink?.out?.write(buf, 0, n)
                            left -= n
                            got[id] = (got[id] ?: 0) + n
                        }
                        val now = System.currentTimeMillis()
                        if (now - (lastUi[id] ?: 0) > 150) { lastUi[id] = now; val d = got[id] ?: 0; ui { cb.onIncomingProgress(id, d) } }
                    }
                    T_END -> {
                        val id = inp.readLong()
                        val sink = sinks.remove(id)
                        val uri = sink?.let { runCatching { it.out.close(); it.finish() }.getOrNull() }
                        val ok = uri != null
                        control.add { o -> o.writeByte(T_ACK); o.writeLong(id); o.writeBoolean(ok) }
                        ui { cb.onIncomingDone(id, uri) }
                    }
                    T_ACK -> { val id = inp.readLong(); val ok = inp.readBoolean(); ui { cb.onOutgoingDone(id, ok) } }
                    T_BYE -> ui { cb.onBye() }
                    T_HELLO -> { val n = inp.readUTF(); ui { cb.onHello(n) } }
                    else -> throw java.io.IOException("bad message")
                }
            }
        } catch (_: Exception) {
            for (s in sinks.values) runCatching { s.out.close(); s.abort() }
            close()
        }
    }

    private companion object {
        const val T_PING = 0
        const val T_BATCH = 1
        const val T_START = 2
        const val T_CHUNK = 3
        const val T_END = 4
        const val T_ACK = 5
        const val T_BYE = 6
        const val T_HELLO = 7
    }
}
