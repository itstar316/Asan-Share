package com.k2.share

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.FileProvider
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket

/** Helpers to give Asan Share to a phone that doesn't have it yet. */
object AppInvite {

    /** Copies our own APK to a shareable place (cache) and returns its content Uri. */
    fun apkUri(ctx: Context): Uri {
        val dir = File(ctx.cacheDir, "invite").apply { mkdirs() }
        val out = File(dir, "AsanShare.apk")
        val src = File(ctx.applicationInfo.sourceDir)
        if (!out.exists() || out.length() != src.length()) src.copyTo(out, overwrite = true)
        return FileProvider.getUriForFile(ctx, ctx.packageName + ".files", out)
    }

    fun apkFile(ctx: Context): File {
        apkUri(ctx)
        return File(File(ctx.cacheDir, "invite"), "AsanShare.apk")
    }

    private fun shareIntent(ctx: Context): Intent =
        Intent(Intent.ACTION_SEND)
            .setType("application/vnd.android.package-archive")
            .putExtra(Intent.EXTRA_STREAM, apkUri(ctx))
            .putExtra(Intent.EXTRA_TEXT, "Asan Share: fast file sharing app")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)

    /** Opens the phone's own Bluetooth sender directly (falls back to the share menu). */
    fun sendByBluetooth(ctx: Context) {
        val i = shareIntent(ctx).setPackage("com.android.bluetooth").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(i)
        } catch (_: ActivityNotFoundException) {
            shareAnyWay(ctx)
        } catch (_: SecurityException) {
            shareAnyWay(ctx)
        }
    }

    /** Quick Share, Bluetooth, WhatsApp… whatever the phone offers. */
    fun shareAnyWay(ctx: Context) {
        runCatching {
            ctx.startActivity(
                Intent.createChooser(shareIntent(ctx), "Send Asan Share with").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    fun qr(text: String, size: Int = 640): ImageBitmap? = runCatching {
        val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size, mapOf(EncodeHintType.MARGIN to 1))
        val px = IntArray(size * size)
        for (y in 0 until size) for (x in 0 until size) px[y * size + x] = if (m[x, y]) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
        Bitmap.createBitmap(px, size, size, Bitmap.Config.ARGB_8888).asImageBitmap()
    }.getOrNull()

    fun wifiQrText(ssid: String, pass: String): String {
        fun esc(s: String) = s.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace(":", "\\:").replace("\"", "\\\"")
        return "WIFI:T:WPA;S:${esc(ssid)};P:${esc(pass)};;"
    }

    /** Best guess of this phone's address on the hotspot / local Wi-Fi. */
    fun localIp(): String? {
        val all = runCatching { NetworkInterface.getNetworkInterfaces().toList() }.getOrDefault(emptyList())
            .filter { runCatching { it.isUp && !it.isLoopback }.getOrDefault(false) }
            .flatMap { ni -> ni.inetAddresses.toList().filterIsInstance<Inet4Address>().map { ni.name to it.hostAddress } }
            .filter { it.second != null && (it.second!!.startsWith("192.168.") || it.second!!.startsWith("10.") || it.second!!.startsWith("172.")) }
        val hotspot = all.firstOrNull { (n, _) -> n.contains("ap") || n.contains("swlan") || n == "wlan1" || n.startsWith("softap") }
        return (hotspot ?: all.firstOrNull { it.first.startsWith("wlan") } ?: all.firstOrNull())?.second
    }
}

/**
 * "Download over Wi-Fi": this phone makes its own Wi-Fi network and a tiny web page.
 * The friend scans 2 QR codes with the camera: join Wi-Fi, then download the app.
 */
class InviteServer(private val ctx: Context) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var server: ServerSocket? = null
    private var reservation: WifiManager.LocalOnlyHotspotReservation? = null
    @Volatile private var stopped = false
    var port = 8080
        private set

    fun startWeb(): Boolean {
        if (server != null) return true
        val apk = runCatching { AppInvite.apkFile(ctx) }.getOrNull() ?: return false
        for (p in listOf(8080, 8090, 8888, 0)) {
            val s = runCatching { ServerSocket(p) }.getOrNull() ?: continue
            server = s; port = s.localPort; break
        }
        val s = server ?: return false
        scope.launch {
            while (isActive) {
                val c = runCatching { s.accept() }.getOrNull() ?: break
                launch { handle(c, apk) }
            }
        }
        return true
    }

    private fun handle(c: Socket, apk: File) {
        runCatching {
            c.use { sock ->
                sock.soTimeout = 15000
                val req = BufferedReader(InputStreamReader(sock.getInputStream())).readLine() ?: return
                val path = req.split(" ").getOrNull(1) ?: "/"
                val out = sock.getOutputStream().buffered(256 * 1024)
                if (path.startsWith("/AsanShare.apk")) {
                    out.write(
                        ("HTTP/1.1 200 OK\r\nContent-Type: application/vnd.android.package-archive\r\n" +
                            "Content-Length: ${apk.length()}\r\n" +
                            "Content-Disposition: attachment; filename=\"AsanShare.apk\"\r\nConnection: close\r\n\r\n").toByteArray()
                    )
                    apk.inputStream().use { it.copyTo(out, 256 * 1024) }
                } else {
                    val body = PAGE.toByteArray(Charsets.UTF_8)
                    out.write(
                        ("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n" +
                            "Content-Length: ${body.size}\r\nConnection: close\r\n\r\n").toByteArray()
                    )
                    out.write(body)
                }
                out.flush()
            }
        }
    }

    /** Starts a private hotspot. onReady(ssid, password) or onError(message). */
    @Suppress("DEPRECATION", "MissingPermission")
    fun startHotspot(onReady: (String, String) -> Unit, onError: (String) -> Unit) {
        val wm = ctx.getSystemService(Context.WIFI_SERVICE) as? WifiManager ?: return onError("Wi-Fi not available")
        try {
            wm.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                override fun onStarted(r: WifiManager.LocalOnlyHotspotReservation) {
                    // The user already left this screen: switch the Wi-Fi straight back off,
                    // otherwise it would block Asan Share's own fast link.
                    if (stopped) { runCatching { r.close() }; return }
                    reservation = r
                    var ssid: String? = null
                    var pass: String? = null
                    if (Build.VERSION.SDK_INT >= 30) {
                        val c = r.softApConfiguration
                        ssid = c.ssid
                        pass = c.passphrase
                    } else {
                        r.wifiConfiguration?.let { ssid = it.SSID; pass = it.preSharedKey }
                    }
                    if (ssid != null && pass != null) onReady(ssid!!.trim('"'), pass!!.trim('"'))
                    else onError("Couldn't read the Wi-Fi name")
                }

                override fun onFailed(reason: Int) {
                    onError(
                        if (reason == WifiManager.LocalOnlyHotspotCallback.ERROR_INCOMPATIBLE_MODE) "Turn off your phone's normal hotspot first, then try again."
                        else "Couldn't start Wi-Fi (code $reason). Turn Wi-Fi and Location on, then try again."
                    )
                }
            }, Handler(Looper.getMainLooper()))
        } catch (e: Exception) {
            onError("Couldn't start Wi-Fi: ${e.message}")
        }
    }

    fun stop() {
        stopped = true
        runCatching { reservation?.close() }
        reservation = null
        runCatching { server?.close() }
        server = null
        scope.cancel()
    }

    companion object {
        private val PAGE = """
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Asan Share</title>
<style>
body{margin:0;font-family:system-ui,-apple-system,Roboto,sans-serif;background:#F4F6FA;color:#151827;display:flex;min-height:100vh;align-items:center;justify-content:center}
.c{max-width:420px;padding:32px 24px;text-align:center}
.logo{width:88px;height:88px;border-radius:26px;background:#1F2A6B;margin:0 auto 20px;display:flex;align-items:center;justify-content:center}
h1{font-size:30px;margin:0 0 8px}
p{color:#5A6078;line-height:1.5;margin:0 0 24px}
a.b{display:block;background:#1F2A6B;color:#fff;text-decoration:none;font-size:20px;font-weight:700;padding:18px;border-radius:18px}
ol{text-align:left;color:#5A6078;line-height:1.7;padding-left:20px;margin:24px 0 0}
small{display:block;margin-top:28px;color:#8A90A8}
</style></head><body><div class="c">
<div class="logo"><svg width="48" height="48" viewBox="0 0 24 24"><path fill="#FFC93C" d="M6.8 7.2h5.6V4.8l5.2 3.8-5.2 3.8V10H6.8z"/><path fill="#9AA8FF" d="M17.2 14.2h-5.6v-2.4l-5.2 3.8 5.2 3.8V17h5.6z"/></svg></div>
<h1>Asan Share</h1>
<p>Fast file sharing between phones. No internet needed.</p>
<a class="b" href="/AsanShare.apk">Download the app</a>
<ol><li>Tap <b>Download the app</b>.</li><li>Open the downloaded file.</li><li>If asked, allow installing from this source, then tap <b>Install</b>.</li></ol>
<small>Developed by JAVED IQBAL, WhatsApp 0303 2901193</small>
</div></body></html>
""".trimIndent()
    }
}
