package com.k2.share

import android.app.Application
import android.bluetooth.BluetoothManager
import android.location.LocationManager
import android.net.wifi.WifiManager
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.media.ThumbnailUtils
import androidx.core.content.ContextCompat
import android.os.ParcelFileDescriptor
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import androidx.core.location.LocationManagerCompat
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.common.api.ApiException
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.BandwidthInfo
import com.google.android.gms.nearby.connection.ConnectionOptions
import com.google.android.gms.nearby.connection.ConnectionType
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsStatusCodes
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.Locale

enum class Screen { HOME, CONNECTED, RECEIVED, INVITE, GROUP_HOST, GROUP_JOIN, SCAN_QR }
enum class Kind { APP, PHOTO, VIDEO, MUSIC, FILE }

/** Something on the phone that can be picked for sending. */
data class MediaItem(
    val key: String,
    val uri: Uri,
    val name: String,
    val size: Long,
    val kind: Kind,
    val extra: String = "",
    val pkg: String? = null,
    val path: String? = null,
)
enum class TState { WAITING, RUNNING, SAVING, DONE, FAILED, PAUSED, CANCELLED }

data class PickedFile(val uri: Uri, val name: String, val size: Long)
data class Device(val id: String, val name: String)
data class Transfer(
    val id: Long,
    val name: String,
    val size: Long,
    val incoming: Boolean,
    val done: Long = 0,
    val state: TState = TState.WAITING,
    val speed: Double = 0.0,
    val saved: Uri? = null,
    /** Source file, for outgoing transfers (used to resume after a dropped connection). */
    val source: PickedFile? = null,
    /** Handed to the connection (not just waiting in line). */
    val started: Boolean = false,
    /** Never changes for a row (the network id can change when a file is re-sent). */
    val uid: Long = nextUid(),
) {
    val active: Boolean get() = state == TState.WAITING || state == TState.RUNNING || state == TState.SAVING
    companion object {
        private val seq = java.util.concurrent.atomic.AtomicLong(0)
        fun nextUid() = seq.incrementAndGet()
    }
}

private const val SERVICE_ID = "com.javed.asanshare.TRANSFER"
// Point-to-point = one sender, one receiver, highest bandwidth (direct Wi-Fi link)
private val STRATEGY = Strategy.P2P_POINT_TO_POINT
const val SAVE_FOLDER = "Asan Share"

val APK_EXTS = setOf("apk", "xapk", "apks", "apkm")
val DOC_EXTS = setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "rtf", "odt", "ods", "odp", "csv", "epub", "vcf")
val ARCHIVE_EXTS = setOf("zip", "rar", "7z", "tar", "gz")
val DESIGN_EXTS = setOf("dst", "emb", "pes", "jef", "exp", "dsb", "vp3", "hus", "xxx", "cdr", "ai", "psd", "eps", "svg", "dxf", "plt")
val FILE_EXTS = APK_EXTS + DOC_EXTS + ARCHIVE_EXTS + DESIGN_EXTS

fun fmt(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var v = bytes / 1024.0
    var i = 0
    while (v >= 1024 && i < units.size - 1) { v /= 1024; i++ }
    return String.format(Locale.US, if (v < 10) "%.1f %s" else "%.0f %s", v, units[i])
}

class ShareViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Context = app.applicationContext
    private val client = Nearby.getConnectionsClient(ctx)
    private val prefs = ctx.getSharedPreferences("k2share", Context.MODE_PRIVATE)

    var myName by mutableStateOf(prefs.getString("name", null) ?: defaultName())
        private set

    init {
        prefs.edit().remove("goBand").apply()
        Turbo.bandPref = 0
        Turbo.silentJoinOk = prefs.getBoolean("silentJoinOk", true)
        Lang.urdu = prefs.getBoolean("urdu", false)
        // Older versions could wrongly remember "this device can't create the network" (join permission bug)
        if (!prefs.getBoolean("capsReset2", false)) prefs.edit().remove("cannotHostAt").putBoolean("capsReset2", true).apply()
    }

    fun setUrdu(on: Boolean) { Lang.urdu = on; prefs.edit().putBoolean("urdu", on).apply() }

    /** True when received files can go to their own "Asan Share" folder at the top of phone storage. */
    var ownFolder by mutableStateOf(canUseOwnFolder())
        private set

    fun refreshFolderAccess() {
        val before = ownFolder
        ownFolder = canUseOwnFolder()
        // just got "All files access": load the full Files list again
        if (!before && ownFolder) loadedWithMedia?.let { loadLibrary(it, force = true) }
    }

    private fun canUseOwnFolder(): Boolean = when {
        Build.VERSION.SDK_INT >= 30 -> Environment.isExternalStorageManager()
        Build.VERSION.SDK_INT == 29 -> runCatching { Environment.isExternalStorageLegacy() }.getOrDefault(false) &&
            ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        else -> ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    }

    @Suppress("DEPRECATION")
    private fun rootFolder() = File(Environment.getExternalStorageDirectory(), SAVE_FOLDER)

    private fun subFolder(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return when (ext) {
            "jpg", "jpeg", "png", "gif", "webp", "heic", "bmp" -> "Photos"
            "mp4", "mkv", "mov", "avi", "3gp", "webm" -> "Videos"
            "mp3", "m4a", "wav", "aac", "ogg", "opus", "flac", "amr" -> "Music"
            "apk", "xapk", "apks" -> "Apps"
            else -> "Files"
        }
    }
    var screen by mutableStateOf(Screen.HOME)
    var status by mutableStateOf("")
    var peerName by mutableStateOf<String?>(null)
    var connected by mutableStateOf(false)
    var request by mutableStateOf<Device?>(null)
    /** 0 = unknown, 1 = Bluetooth (slow), 2 = Wi-Fi, 3 = fast direct Wi-Fi */
    var link by mutableStateOf(0)

    /** Things the user must switch on: "Bluetooth", "Wi-Fi", "Location" */
    var problems by mutableStateOf(listOf<String>())
    var failed by mutableStateOf(false)
    /** Nearby said a permission is missing: the activity re-checks and asks with a popup. */
    var permissionProblem by mutableStateOf(false)
    /** Phone we asked to connect to and are waiting for. */
    var connecting by mutableStateOf<Device?>(null)
    private var paused = false

    // ---- Auto-reconnect & resume after an accidental disconnect ----
    /** Name of the phone we lost by accident, and until when we try to get it back. */
    var reconnectName by mutableStateOf<String?>(null)
    private var reconnectUntil = 0L
    private var byeReceived = false
    /** Unfinished files that will be sent again after reconnecting. */
    var resumeCount by mutableStateOf(0)
    /** Smooth overall speed in bytes/second (all files together). */
    var liveSpeed by mutableStateOf(0.0)
    private var speedTicker: Job? = null
    /** The phone the transfer list belongs to (kept after a disconnect, so you can resume). */
    private var historyPeer: String? = null
    private var autoResume = false
    private val lastUi = HashMap<Long, Long>()
    private val myToken = (Math.random() * Long.MAX_VALUE).toLong()

    /** Hidden ID of this install (stays the same), sent along with our name so we never "find" ourselves. */
    private val installId: String = prefs.getString("installId", null)
        ?: java.lang.Long.toString((Math.random() * Long.MAX_VALUE).toLong(), 36).take(8).also { prefs.edit().putString("installId", it).apply() }
    private val SEP = '\u001F'
    /** What we broadcast: "Javed's Tab A7<SEP>k3x9…" (other phones show only the name part). */
    private fun wireName() = myName + SEP + installId
    /** Split a received name into (display name, hidden ID). */
    private fun parseName(raw: String): Pair<String, String?> {
        val i = raw.indexOf(SEP)
        return if (i < 0) raw to null else raw.substring(0, i) to raw.substring(i + 1)
    }
    private var peerToken: Long? = null
    private var lostPeerToken: Long? = null
    private var iRequested = false
    private var started = false

    // Files waiting to be sent. Sent a couple at a time so even thousands of files work.
    private val queue = ArrayDeque<Pair<Long, PickedFile>>()
    /** Files handed to Nearby right now: payloadId -> time sent. (Max 2 at once.) */
    private val onWire = HashMap<Long, Long>()
    private val retries = HashMap<String, Int>()
    private var nextPlaceholder = -1L
    /** Whole batch size, so both phones can show "12 of 120 files". */
    var expectedCount by mutableStateOf(0)
    var expectedBytes by mutableStateOf(0L)
    private var lastNotified = -1

    private var waitingForFast = false
    private var fastTimer: Job? = null

    val picked = mutableStateListOf<PickedFile>()
    private val selectedKeys = mutableStateMapOf<String, Boolean>()

    // Phone library (like Zapya's tabs)
    var apps by mutableStateOf(listOf<MediaItem>())
    var photos by mutableStateOf(listOf<MediaItem>())
    var videos by mutableStateOf(listOf<MediaItem>())
    var music by mutableStateOf(listOf<MediaItem>())
    var docs by mutableStateOf(listOf<MediaItem>())
    var loading by mutableStateOf(false)
    var received by mutableStateOf(listOf<MediaItem>())
    private var loadedWithMedia: Boolean? = null
    val devices = mutableStateListOf<Device>()
    val transfers = mutableStateListOf<Transfer>()

    private var peerId: String? = null
    private val names = HashMap<String, String>()          // endpointId -> name
    private val meta = HashMap<Long, Pair<String, Long>>()  // payloadId -> (file name, size)
    private val incomingFiles = HashMap<Long, Payload>()
    private val completed = HashSet<Long>()
    private val startedAt = HashMap<Long, Long>()

    private fun defaultName(): String {
        val n = runCatching { Settings.Global.getString(ctx.contentResolver, "device_name") }.getOrNull()
        return if (!n.isNullOrBlank()) n
        else "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}"
    }

    fun rename(n: String) {
        val t = n.trim()
        if (t.isNotEmpty()) { myName = t; prefs.edit().putString("name", t).apply() }
    }

    // ---------- Files ----------
    fun addFiles(uris: List<Uri>) {
        for (u in uris) {
            if (selectedKeys.containsKey(u.toString())) continue
            var name = "file"
            var size = 0L
            runCatching {
                ctx.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        c.getString(0)?.let { name = it }
                        if (!c.isNull(1)) size = c.getLong(1)
                    }
                }
            }
            picked.add(PickedFile(u, name, size))
            selectedKeys[u.toString()] = true
        }
    }

    fun removeFile(f: PickedFile) { picked.remove(f); selectedKeys.remove(f.uri.toString()) }

    fun isSelected(item: MediaItem) = selectedKeys.containsKey(item.uri.toString())

    fun toggle(item: MediaItem) {
        val k = item.uri.toString()
        if (selectedKeys.containsKey(k)) {
            selectedKeys.remove(k)
            picked.removeAll { it.uri.toString() == k }
        } else {
            selectedKeys[k] = true
            picked.add(PickedFile(item.uri, item.name, item.size))
        }
    }

    fun selectAll(items: List<MediaItem>, select: Boolean) {
        for (i in items) if (isSelected(i) != select) toggle(i)
    }

    fun clearSelection() { picked.clear(); selectedKeys.clear() }

    fun openInvite() { stopRadar(); screen = Screen.INVITE }

    /** Send whatever is ticked to the connected phone. */
    fun sendSelected() {
        if (!connected || picked.isEmpty()) return
        sendAll()
    }

    // ---------- Phone library ----------
    fun loadLibrary(hasMedia: Boolean, force: Boolean = false) {
        if (loading || (!force && loadedWithMedia == hasMedia)) return
        loading = true
        viewModelScope.launch {
            apps = withContext(Dispatchers.IO) { runCatching { queryApps() }.getOrDefault(emptyList()) }
            if (hasMedia) {
                photos = withContext(Dispatchers.IO) { runCatching { queryMedia(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, Kind.PHOTO) }.getOrDefault(emptyList()) }
                videos = withContext(Dispatchers.IO) { runCatching { queryMedia(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, Kind.VIDEO) }.getOrDefault(emptyList()) }
                music = withContext(Dispatchers.IO) { runCatching { queryMedia(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, Kind.MUSIC) }.getOrDefault(emptyList()) }
            }
            // Files (APK, PDF…) can be visible even without photo access, e.g. with "All files access"
            docs = withContext(Dispatchers.IO) { runCatching { queryDocs() }.getOrDefault(emptyList()) }
            loadedWithMedia = hasMedia
            loading = false
        }
    }

    @Suppress("DEPRECATION")
    private fun queryApps(): List<MediaItem> {
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(launcher, 0)
            .map { it.activityInfo.applicationInfo }
            .distinctBy { it.packageName }
            .filter {
                it.packageName == ctx.packageName ||
                    (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 ||
                    (it.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
            }
            .mapNotNull { ai ->
                val f = File(ai.sourceDir ?: return@mapNotNull null)
                if (!f.canRead()) return@mapNotNull null
                val label = pm.getApplicationLabel(ai).toString()
                val uri = Uri.fromFile(f)
                MediaItem(uri.toString(), uri, "$label.apk", f.length(), Kind.APP, pkg = ai.packageName)
            }
            .sortedBy { it.name.lowercase() }
        // Asan Share itself first, so it's easy to give the app to friends
        return list.sortedByDescending { it.pkg == ctx.packageName }
    }

    private fun dur(ms: Long): String {
        if (ms <= 0) return ""
        val s = ms / 1000
        return if (s >= 3600) String.format(Locale.US, "%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60)
        else String.format(Locale.US, "%d:%02d", s / 60, s % 60)
    }

    private fun queryMedia(base: Uri, kind: Kind): List<MediaItem> {
        val out = ArrayList<MediaItem>()
        val proj = mutableListOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE)
        if (kind != Kind.PHOTO) proj += "duration"
        if (kind == Kind.MUSIC) proj += "artist"
        val sel = if (kind == Kind.MUSIC) "${MediaStore.Audio.AudioColumns.IS_MUSIC} != 0" else null
        ctx.contentResolver.query(base, proj.toTypedArray(), sel, null, "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val iName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val iSize = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            val iDur = c.getColumnIndex("duration")
            val iArtist = c.getColumnIndex("artist")
            while (c.moveToNext()) {
                val uri = ContentUris.withAppendedId(base, c.getLong(iId))
                val name = c.getString(iName) ?: "file"
                val d = if (iDur >= 0) dur(c.getLong(iDur)) else ""
                val extra = when (kind) {
                    Kind.VIDEO -> d
                    Kind.MUSIC -> listOfNotNull(
                        (if (iArtist >= 0) c.getString(iArtist) else null)?.takeIf { it.isNotBlank() && it != "<unknown>" }, d.ifEmpty { null },
                    ).joinToString("   ")
                    else -> ""
                }
                out += MediaItem(uri.toString(), uri, name, c.getLong(iSize), kind, extra)
            }
        }
        return out
    }

    /** Every useful non-media file on the phone: APKs, PDFs, Office files, ZIPs, embroidery/design files… */
    @Suppress("DEPRECATION")
    private fun queryDocs(): List<MediaItem> {
        val base = MediaStore.Files.getContentUri("external")
        val sel = FILE_EXTS.joinToString(" OR ") { "${MediaStore.MediaColumns.DISPLAY_NAME} LIKE ?" }
        val args = FILE_EXTS.map { "%.$it" }.toTypedArray()
        val out = ArrayList<MediaItem>()
        ctx.contentResolver.query(
            base,
            arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.DATA),
            "(${sel}) AND ${MediaStore.MediaColumns.SIZE} > 0", args, "${MediaStore.MediaColumns.DATE_MODIFIED} DESC",
        )?.use { c ->
            while (c.moveToNext() && out.size < 8000) {
                val name = c.getString(1) ?: continue
                val path = c.getString(3)
                // skip hidden files and app-private folders
                if (name.startsWith(".") || (path != null && (path.contains("/Android/data/") || path.contains("/Android/obb/") || path.contains("/."))))
                    continue
                val uri = ContentUris.withAppendedId(base, c.getLong(0))
                out += MediaItem(uri.toString(), uri, name, c.getLong(2), Kind.FILE, path = path)
            }
        }
        return out
    }

    fun openReceived() { stopRadar(); screen = Screen.RECEIVED; loadReceived() }

    fun loadReceived() {
        viewModelScope.launch {
            received = withContext(Dispatchers.IO) { runCatching { queryReceived() }.getOrDefault(emptyList()) }
        }
    }

    /**
     * Delete received files from the phone's storage.
     * Files this app saved are deleted directly; if Android says some belong to "another app"
     * (e.g. saved before a reinstall), it shows its own one-tap confirmation via [askAndroid].
     */
    fun deleteReceived(items: List<MediaItem>, askAndroid: (android.content.IntentSender) -> Unit) {
        viewModelScope.launch {
            val needAsk = ArrayList<Uri>()
            withContext(Dispatchers.IO) {
                for (m in items) {
                    val p = m.path
                    if (p != null) {
                        val f = File(p)
                        if (runCatching { f.delete() }.getOrDefault(false)) {
                            runCatching { android.media.MediaScannerConnection.scanFile(ctx, arrayOf(p), null, null) }
                            continue
                        }
                    }
                    val ok = runCatching { ctx.contentResolver.delete(m.uri, null, null) > 0 }.getOrDefault(false)
                    if (!ok && m.uri.scheme == "content" && m.uri.authority == MediaStore.AUTHORITY) needAsk += m.uri
                }
            }
            if (needAsk.isNotEmpty() && Build.VERSION.SDK_INT >= 30) {
                runCatching { askAndroid(MediaStore.createDeleteRequest(ctx.contentResolver, needAsk).intentSender) }
            }
            dlog("Deleted ${items.size - needAsk.size} received files")
            loadReceived()
        }
    }

    /** Folder (relative to phone storage) where received files are saved, e.g. "Asan Share" or "Download/Asan Share". */
    fun saveFolderRelative(): String = if (ownFolder) SAVE_FOLDER else Environment.DIRECTORY_DOWNLOADS + "/" + SAVE_FOLDER

    private fun kindOf(name: String, mime: String?): Kind {
        val m = mime ?: ""
        val ext = name.substringAfterLast('.', "").lowercase()
        return when {
            m.startsWith("image/") || ext in setOf("jpg", "jpeg", "png", "gif", "webp", "heic") -> Kind.PHOTO
            m.startsWith("video/") || ext in setOf("mp4", "mkv", "mov", "3gp", "webm", "avi") -> Kind.VIDEO
            else -> Kind.FILE
        }
    }

    private fun queryReceived(): List<MediaItem> {
        val out = ArrayList<MediaItem>()
        if (ownFolder) {
            rootFolder().walkTopDown().filter { it.isFile && !it.name.startsWith(".") }.forEach { f ->
                val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
                out += MediaItem("f:${f.path}", uri, f.name, f.length(), kindOf(f.name, null), path = f.path)
            }
        }
        if (Build.VERSION.SDK_INT >= 29) {
            val base = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            ctx.contentResolver.query(
                base,
                arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.MIME_TYPE),
                "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?",
                arrayOf(Environment.DIRECTORY_DOWNLOADS + "/" + SAVE_FOLDER + "%"),
                "${MediaStore.MediaColumns.DATE_ADDED} DESC",
            )?.use { c ->
                while (c.moveToNext()) {
                    val uri = ContentUris.withAppendedId(base, c.getLong(0))
                    val name = c.getString(1) ?: "file"
                    out += MediaItem("r:$uri", uri, name, c.getLong(2), kindOf(name, c.getString(3)))
                }
            }
        } else if (!ownFolder) {
            @Suppress("DEPRECATION")
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), SAVE_FOLDER)
            dir.listFiles()?.filter { it.isFile }?.sortedByDescending { it.lastModified() }?.forEach { f ->
                val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
                out += MediaItem("r:${f.path}", uri, f.name, f.length(), kindOf(f.name, null), path = f.path)
            }
        }
        return out.distinctBy { it.name + it.size }.sortedByDescending { it.path?.let { p -> File(p).lastModified() } ?: 0L }
    }

    // ---------- Finding & connecting ----------
    /**
     * Zapya-style: while the app is open on the home screen, this phone is visible to others
     * AND looking for others at the same time. No "Receive" button needed.
     */
    fun startRadar() {
        if (!playServicesOk()) return
        status = ""; failed = false; started = true
        radarStartedAt = System.currentTimeMillis()
        client.stopAdvertising()
        client.stopDiscovery()
        if (!connected && connecting == null && request == null) client.stopAllEndpoints() // clear leftovers of the last session
        devices.clear()
        client.startAdvertising(wireName(), SERVICE_ID, connCb, AdvertisingOptions.Builder().setStrategy(STRATEGY).setConnectionType(pairingType()).build())
            .addOnSuccessListener { if (connected) client.stopAdvertising() }
            .addOnFailureListener { onStartFailed(it, "become visible") }
        startDiscoveryOnly()
    }

    private fun startDiscoveryOnly() {
        client.startDiscovery(SERVICE_ID, discoveryCb, DiscoveryOptions.Builder().setStrategy(STRATEGY).build())
            .addOnSuccessListener { if (connected || connecting != null || accepting) client.stopDiscovery() }
            .addOnFailureListener { onStartFailed(it, "search for phones") }
    }

    fun stopRadar() {
        client.stopDiscovery()
        client.stopAdvertising()
        started = false
        connecting = null
    }

    /** App went to the background: stop the radar to save battery (but never drop a live connection). */
    fun onAppBackground() { paused = true; if (!connected && connecting == null) stopRadar() }
    fun onAppForeground() { paused = false }

    /** Called every second or so by the home screen. Starts (or restarts) once everything is switched on. */
    fun keepAlive() {
        if (connected || screen != Screen.HOME || paused || connecting != null || request != null || accepting) return
        val wasBlocked = problems.isNotEmpty()
        refreshRadios()
        if (problems.isNotEmpty()) return
        val now = System.currentTimeMillis()
        when {
            !started || (failed && wasBlocked) -> startRadar()
            // Searching runs continuously. Only if nothing at all shows up for a long time, restart it once a minute
            // (restarting more often stops slower phones, e.g. Android 16, from ever finishing a scan).
            !failed && devices.isEmpty() && now - radarStartedAt > 60_000 -> startRadar()
        }
    }

    private var radarStartedAt = 0L

    fun retry() = startRadar()

    private fun refreshRadios() {
        val p = mutableListOf<String>()
        val bt = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
        if (bt != null && !runCatching { bt.isEnabled }.getOrDefault(true)) p += "Bluetooth"
        val wifi = ctx.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        if (wifi != null && !wifi.isWifiEnabled) p += "Wi-Fi"
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        if (lm != null && !LocationManagerCompat.isLocationEnabled(lm)) p += "Location"
        if (p != problems) problems = p
    }

    private fun playServicesOk(): Boolean {
        val ok = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(ctx) == ConnectionResult.SUCCESS
        if (!ok) {
            failed = true; started = true
            status = tr("This phone needs Google Play services (or an update of it) to use Asan Share.", "آسان شیئر کے لیے اس فون میں Google Play services (یا اس کی اپڈیٹ) ضروری ہے۔")
        }
        return ok
    }

    private fun onStartFailed(e: Exception, what: String) {
        val code = (e as? ApiException)?.statusCode ?: -1
        // Already running is fine
        if (code == ConnectionsStatusCodes.STATUS_ALREADY_DISCOVERING || code == ConnectionsStatusCodes.STATUS_ALREADY_ADVERTISING) return
        failed = true
        status = when (code) {
            in 8030..8040 -> {
                permissionProblem = true // the app asks for it again with a popup
                val which = when (code) {
                    8034, 8036 -> tr("Location (choose Precise)", "لوکیشن (درست چنیں)")
                    8037, 8038, 8039, 8040 -> tr("Nearby devices", "قریبی ڈیوائسز")
                    else -> tr("Bluetooth", "بلوٹوتھ")
                }
                tr("Couldn't $what: \"$which\" permission is missing (code $code). Tap Try again and allow it.",
                    "«$which» کی اجازت نہیں ملی (کوڈ $code)۔ «دوبارہ کوشش کریں» دبا کر اجازت دیں۔")
            }
            ConnectionsStatusCodes.STATUS_BLUETOOTH_ERROR -> tr("Couldn't $what: Bluetooth error. Turn Bluetooth off and on, then tap Try again.", "بلوٹوتھ میں مسئلہ۔ بلوٹوتھ بند کر کے دوبارہ آن کریں، پھر دوبارہ کوشش کریں۔")
            else -> tr("Couldn't $what (error $code). Turn Wi-Fi and Bluetooth off and on, then tap Try again.", "شروع نہیں ہو سکا (خرابی $code)۔ وائی فائی اور بلوٹوتھ بند کر کے دوبارہ آن کریں، پھر دوبارہ کوشش کریں۔")
        }
    }

    /** Stop any half-finished fast-link setup completely, so the next attempt starts clean. */
    private fun abortTurboSetup() {
        turboJob?.cancel(); turboJob = null
        Turbo.cancelAccept()
        runCatching { lanServer?.close() }; lanServer = null
        runCatching { laneServer?.close() }; laneServer = null
        Turbo.leaveHotspot(ctx)
    }

    /** Forget what went wrong before: every connection you start yourself gets a full, fresh try. */
    private fun freshStart() {
        standardOnly = false
        p2pFailedFor.clear(); turboFailedFor.clear(); hotspotFailedFor.clear(); boostFailedFor.clear()
        swappedWith.clear(); p2pAttempts.clear()
        lastTurboError = null; engineNote = null; peerOutdated = false
        Turbo.lastError = null
    }

    fun connect(d: Device, auto: Boolean = false) {
        if (connecting != null || connected) return
        if (!auto) freshStart()
        abortTurboSetup()
        connecting = d
        iRequested = true
        names[d.id] = d.name
        client.stopDiscovery() // searching and broadcasting slow down the Bluetooth handshake: pause both
        client.stopAdvertising()
        dlog("Connecting to ${d.name}")
        client.requestConnection(wireName(), d.id, connCb, ConnectionOptions.Builder().setConnectionType(pairingType()).build())
            .addOnFailureListener {
                if (connecting?.id != d.id) return@addOnFailureListener
                connecting = null
                iRequested = false
                devices.removeAll { it.id == d.id }
                startRadar()
                status = tr("Couldn't reach ${d.name}. Make sure Asan Share is open on it, then try again.", "${d.name} تک رسائی نہیں ہوئی۔ اس پر آسان شیئر کھلا رکھیں اور دوبارہ کوشش کریں۔")
            }
        // If the other phone never answers, don't stay on "Connecting…" forever
        viewModelScope.launch {
            delay(40_000)
            if (connecting?.id == d.id && !connected) {
                cancelConnect()
                status = tr("${d.name} didn't answer. Try again.", "${d.name} نے جواب نہیں دیا۔ دوبارہ کوشش کریں۔")
            }
        }
    }

    fun cancelConnect() {
        val d = connecting ?: return
        client.disconnectFromEndpoint(d.id)
        connecting = null
        iRequested = false
        startRadar()
    }

    // ---------- TURBO (own Wi-Fi Direct link) ----------
    private var turbo: TurboLink? = null
    /** Switching from the pairing link to the Turbo link. */
    var switching by mutableStateOf(false)
    private var amHost = false
    private var peerSdk = 0
    private var closingOnPurpose = false
    private val turboFailedFor = HashSet<String>()

    /** Timeline of what happened on this connection (for "Connection details"). */
    val log = mutableStateListOf<String>()
    private val t0 = System.currentTimeMillis()
    fun dlog(msg: String) {
        val sec = (System.currentTimeMillis() - t0) / 1000
        log.add(String.format(Locale.US, "%02d:%02d  %s", sec / 60 % 60, sec % 60, msg))
        if (log.size > 300) log.removeAt(0)
    }
    init { Turbo.logger = { dlog(it) } }
    /** After a Turbo failure, pair the normal way (full-speed Nearby) until the user taps "Try Turbo". */
    private var standardOnly = false
    /** Reconnects in a short time: if it keeps flapping, stop and tell the user. */
    private val reconnectTimes = ArrayDeque<Long>()
    /** Why this connection is NOT using Turbo (null = Turbo is on, or still deciding). Shown to the user. */
    var engineNote by mutableStateOf<String?>(null)
    /** True when the other phone has an older Asan Share (it can be updated with one tap). */
    var peerOutdated by mutableStateOf(false)
    private var peerVersion = 0L
    /** e.g. "1.57": shown on the home screen and in Connection details. */
    val appVersion: String = runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "" }.getOrDefault("")
    private val myVersion: Long = runCatching {
        androidx.core.content.pm.PackageInfoCompat.getLongVersionCode(ctx.packageManager.getPackageInfo(ctx.packageName, 0))
    }.getOrDefault(0L)

    private fun explainNoTurbo() {
        val wifi = ctx.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        engineNote = when {
            peerSdk == 0 -> tr("The other phone has an older Asan Share. Update it for full speed.",
                "دوسرے فون پر پرانا آسان شیئر ہے۔ پوری رفتار کے لیے اسے اپڈیٹ کریں۔")
            !Turbo.supported() -> tr("This phone's Android is too old for Turbo. Using standard speed.",
                "اس فون کا اینڈرائیڈ ٹربو کے لیے پرانا ہے۔ عام رفتار استعمال ہو رہی ہے۔")
            peerSdk < 29 -> tr("The other phone's Android is too old for Turbo. Using standard speed.",
                "دوسرے فون کا اینڈرائیڈ ٹربو کے لیے پرانا ہے۔ عام رفتار استعمال ہو رہی ہے۔")
            wifi?.isWifiEnabled != true -> tr("Turn on Wi-Fi for Turbo speed.", "ٹربو رفتار کے لیے وائی فائی آن کریں۔")
            turboFailedFor.contains(peerName ?: "") -> tr("Turbo couldn't start on these phones. Using standard speed.",
                "ان فونز پر ٹربو شروع نہیں ہو سکا۔ عام رفتار استعمال ہو رہی ہے۔") +
                (lastTurboError?.let { "  ($it)" } ?: "")
            else -> null
        }
    }

    /** Send our own (newer) app to the other phone, so it can update in one tap. */
    fun sendAppUpdate() {
        if (!connected) return
        val f = File(ctx.applicationInfo.sourceDir)
        val pf = PickedFile(Uri.fromFile(f), "AsanShare-update.apk", f.length())
        if (!selectedKeys.containsKey(pf.uri.toString())) { picked.add(pf); selectedKeys[pf.uri.toString()] = true }
        sendAll()
    }
    private val incomingIds = HashMap<Long, Long>() // other phone's file id -> our row id
    private var nextIncoming = 1_000_000_000L

    /**
     * When Turbo will be used, the pairing link must leave Wi-Fi alone (NON_DISRUPTIVE),
     * otherwise Google's link and our Turbo network fight over Wi-Fi and the connection keeps dropping.
     */
    /** Phones where our own Wi-Fi Direct link failed this session: use the pairing link's Wi-Fi instead. */
    private val p2pFailedFor = HashSet<String>()

    // ---------- Who creates the fast network? ----------
    // Some devices can't create it (seen: TECNO Spark 20C, Galaxy Tab A7). We remember that on the device
    // itself, tell the other side, and the device that CAN create it does so, whoever tapped whom.
    private fun cannotHost(): Boolean =
        System.currentTimeMillis() - prefs.getLong("cannotHostAt", 0L) < 15L * 60 * 1000
    private fun markCannotHost() { prefs.edit().putLong("cannotHostAt", System.currentTimeMillis()).apply() }
    private fun markCanHost() { prefs.edit().remove("cannotHostAt").apply() }
    private var peerCanHost: Boolean? = null
    private var peerHostScore = -1

    /** Tablet = no SIM/phone part, or a big screen. Tablets join; phones create. */
    private fun isTablet(): Boolean =
        !ctx.packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_TELEPHONY) ||
            ctx.resources.configuration.smallestScreenWidthDp >= 600

    /**
     * Who should create the fast network (higher wins):
     * phone with free Wi-Fi 5, phone on a home router 4, tablet free 3, tablet on router 2, can't 0.
     * A device on a home router is forced onto the router's channel (often 2.4 GHz = slow).
     */
    private fun myHostScore(): Int {
        if (!Turbo.supported() || cannotHost()) return 0
        val base = if (isTablet()) 1 else 2
        return base * 2 + if (Turbo.alsoOnRouterWifi(ctx)) 0 else 1
    }
    private val p2pAttempts = HashMap<String, Int>()

    /** Called when we know both the other device's Android version and whether it can create the network. */
    private fun maybeStartTurbo() {
        if (peerSdk == 0 || peerCanHost == null || turbo != null || switching) return
        if (!canTurbo()) return
        val myScore = myHostScore()
        val meCan = myScore > 0
        val peerCan = peerHostScore > 0
        // A phone creates the network, a tablet joins it (like Zapya). Equal devices: the one that accepted creates it.
        // Both sides compute the same answer, so exactly one of them creates the network.
        val iCreate = if (myScore != peerHostScore) myScore > peerHostScore else amHost
        dlog("Can create network: this device " + (if (meCan) "yes" else "no") + ", other " + (if (peerCan) "yes" else "no") +
            ". " + (if (iCreate) "This device creates it" else "Other device creates it"))
        if (iCreate) startTurboAsHost()
    }

    // ======================= ZAPYA-STYLE GROUPS (no Google pairing at all) =======================
    data class GroupInfo(val ssid: String, val pass: String, val sec: Int, val viaHotspot: Boolean) {
        /** What the QR code holds. */
        val qr: String get() = "ASANSHARE|$ssid|$sec|$pass"
    }
    var groupInfo by mutableStateOf<GroupInfo?>(null)
    /** e.g. "5 GHz" once the group is up. */
    var groupBandText by mutableStateOf<String?>(null)
    /** This phone is on a home Wi-Fi while creating a group (the group will follow the router's band). */
    var groupOnRouter by mutableStateOf(false)
    var groupStatus by mutableStateOf("")
    var groupError by mutableStateOf<String?>(null)
    var foundGroups by mutableStateOf(listOf<Pair<String, Int>>())
    var joining by mutableStateOf(false)
    private var groupJob: Job? = null
    private var scanJob: Job? = null
    private var groupMode = false
    private var groupResume = false

    /** "Create group": this device makes a Wi-Fi network and waits for the other phone. */
    fun createGroup(hotspotMode: Boolean = false, compatible: Boolean = false) {
        groupBandText = null
        groupOnRouter = Turbo.alsoOnRouterWifi(ctx)
        freshStart()
        abortTurboSetup()
        stopRadar()
        screen = Screen.GROUP_HOST
        groupInfo = null; groupError = null
        groupStatus = tr("Creating your Wi-Fi group…", "آپ کا وائی فائی گروپ بن رہا ہے…")
        groupJob?.cancel()
        groupJob = viewModelScope.launch {
            val ssid = Turbo.groupName(myName)
            val pass = Turbo.groupPass(ssid)
            if (!hotspotMode) {
                // name and password are known in advance: show them right away (the other phone keeps trying until it's up)
                groupInfo = GroupInfo(ssid, pass, 1, false)
                groupStatus = tr("Starting your group…", "آپ کا گروپ شروع ہو رہا ہے…")
            }
            dlog(if (hotspotMode) "Create group: hotspot mode" else "Create group: Wi-Fi Direct network $ssid")
            // 1) Wi-Fi Direct group (works on tablets too: no hotspot feature needed)
            if (compatible) dlog("Compatible mode: group on 2.4 GHz")
            val ready: () -> Unit = {
                groupInfo = GroupInfo(ssid, pass, 1, false)
                groupStatus = tr("Group ready. Waiting for the other phone to join…", "گروپ تیار ہے۔ دوسرے فون کے جوائن کرنے کا انتظار…")
                dlog("Group $ssid is ON")
                viewModelScope.launch { groupBandText = Turbo.groupBand(ctx); groupBandText?.let { dlog("Group band: $it") } }
            }
            var sock = if (hotspotMode) null else Turbo.host(
                ctx, ssid, pass, createMs = 15_000, acceptMs = if (compatible) 600_000 else 40_000, compatible = compatible, onReady = ready,
            )
            if (sock == null && !hotspotMode && !compatible && screen == Screen.GROUP_HOST &&
                groupStatus.startsWith(tr("Group ready", "گروپ تیار"))) {
                // Nobody joined on 5 GHz: the other phone probably can't see that channel. Same group on 2.4 GHz
                // (same name, password and QR), which every phone can see. The joining phone keeps looking meanwhile.
                dlog("Nobody joined on 5 GHz in 40 s: switching the group to 2.4 GHz")
                groupStatus = tr("Switching to a more compatible channel…", "زیادہ مطابقت والے چینل پر جا رہے ہیں…")
                groupBandText = null
                Turbo.shutdown(ctx, removeOwnGroup = true)
                sock = Turbo.host(ctx, ssid, pass, createMs = 15_000, acceptMs = 600_000, compatible = true, onReady = ready)
            }
            if (sock != null) { ownGroup = true; startGroupSession(sock, host = true); return@launch }
            if (!hotspotMode && groupStatus.startsWith(tr("Group ready", "گروپ تیار"))) {
                if (screen == Screen.GROUP_HOST) groupError = tr("Nobody joined. Tap Try again.", "کسی نے جوائن نہیں کیا۔ دوبارہ کوشش کریں۔")
                Turbo.shutdown(ctx, removeOwnGroup = true)
                return@launch
            }
            // 2) Hotspot (phones)
            dlog("Wi-Fi Direct group failed (${Turbo.lastError}). Trying a hotspot")
            val info = Turbo.startHotspot(ctx)
            if (info == null) {
                groupError = tr("This device couldn't create a group (${Turbo.lastError ?: "unknown"}). Create the group on the OTHER phone and tap Join group here.",
                    "یہ ڈیوائس گروپ نہیں بنا سکی (${Turbo.lastError ?: "نامعلوم"})۔ دوسرے فون پر گروپ بنائیں اور یہاں «گروپ جوائن کریں» دبائیں۔")
                return@launch
            }
            groupInfo = GroupInfo(info.ssid, info.pass, info.sec, true)
            groupStatus = tr("Hotspot ready. On the other phone tap Join group, then Scan QR.", "ہاٹ اسپاٹ تیار ہے۔ دوسرے فون پر «گروپ جوائن کریں» پھر «QR اسکین» دبائیں۔")
            val ss = withContext(Dispatchers.IO) { Turbo.listen(Turbo.PORT, 600_000) }
            if (ss == null) { groupError = tr("Couldn't open the connection port.", "کنکشن پورٹ نہیں کھل سکا۔"); Turbo.stopHotspot(); return@launch }
            lanServer = ss
            val s2 = withContext(Dispatchers.IO) { runCatching { ss.accept() }.getOrNull() }
            runCatching { ss.close() }; lanServer = null
            if (s2 != null) { Turbo.tune(s2); startGroupSession(s2, host = true) }
            else { Turbo.stopHotspot(); if (screen == Screen.GROUP_HOST) groupError = tr("Nobody joined. Tap Try again.", "کسی نے جوائن نہیں کیا۔ دوبارہ کوشش کریں۔") }
        }
    }

    /** "Join group": look for Asan Share groups around. */
    fun openJoin() {
        freshStart()
        abortTurboSetup()
        stopRadar()
        screen = Screen.GROUP_JOIN
        foundGroups = emptyList(); groupError = null; groupStatus = ""; joining = false
        scanJob?.cancel()
        scanJob = viewModelScope.launch {
            var lastScan = 0L
            while (screen == Screen.GROUP_JOIN || screen == Screen.SCAN_QR) {
                if (!joining && screen == Screen.GROUP_JOIN) {
                    val fresh = System.currentTimeMillis() - lastScan > 30_000
                    if (fresh) lastScan = System.currentTimeMillis()
                    foundGroups = withContext(Dispatchers.IO) { Turbo.scanGroups(ctx, fresh) }
                }
                delay(2500)
            }
        }
    }

    fun openQrScanner() { screen = Screen.SCAN_QR }
    fun closeQrScanner() { screen = Screen.GROUP_JOIN }

    fun joinFound(ssid: String) = joinGroup(ssid, Turbo.groupPass(ssid), 1)

    fun onQrScanned(text: String) {
        val p = text.split("|")
        if (p.size >= 4 && p[0] == "ASANSHARE") {
            screen = Screen.GROUP_JOIN
            joinGroup(p[1], p.subList(3, p.size).joinToString("|"), p[2].toIntOrNull() ?: 1)
        }
    }

    /** Join a group like a normal Wi-Fi (Android asks "Connect?" once), then connect. */
    fun joinGroup(ssid: String, pass: String, sec: Int) {
        if (joining) return
        joining = true; groupError = null
        val name = ssid.removePrefix(Turbo.GROUP_PREFIX)
        groupStatus = tr("Joining $name… this can take up to a minute.\nIf Android shows a Wi-Fi list, tap “$ssid”. If it asks, tap Connect.",
            "$name جوائن ہو رہا ہے…\nاگر اینڈرائیڈ وائی فائی کی فہرست دکھائے تو «$ssid» پر ٹیپ کریں۔ اگر پوچھے تو «کنیکٹ» دبائیں۔")
        groupJob?.cancel()
        groupJob = viewModelScope.launch {
            dlog("Join group $ssid")
            var sock = Turbo.joinAny(ctx, ssid, pass, sec, 60_000, requireSeen = false, lookMs = 90_000)
            if (sock == null && joining) {
                // the other phone may have just moved its group to 2.4 GHz: try once more
                dlog("First join didn't work (${Turbo.lastError}). Trying once more")
                Turbo.leaveHotspot(ctx)
                delay(4000)
                sock = Turbo.joinAny(ctx, ssid, pass, sec, 60_000, requireSeen = false, lookMs = 60_000)
            }
            if (Turbo.silentJoinFailedNow) prefs.edit().putBoolean("silentJoinOk", false).apply()
            if (sock == null) {
                dlog("Group join failed: ${Turbo.lastError ?: "unknown"}")
                groupError = tr("Couldn't find or join the group. On the other phone, tap \"Compatible mode\" and try again.",
                    "گروپ نہیں ملا یا جوائن نہیں ہو سکا۔ دوسرے فون پر «مطابقت موڈ» دبائیں اور دوبارہ کوشش کریں۔")
                joining = false; Turbo.leaveHotspot(ctx); Turbo.leaveP2p(ctx); return@launch
            }
            joining = false
            startGroupSession(sock, host = false)
        }
    }

    fun cancelGroup() {
        groupJob?.cancel(); scanJob?.cancel()
        abortTurboSetup()
        Turbo.cancelAccept()
        runCatching { lanServer?.close() }; lanServer = null
        joining = false
        viewModelScope.launch { Turbo.shutdown(ctx, removeOwnGroup = true) }
        screen = Screen.HOME
    }

    /** Both sides: the direct link is up. Same connected screen and transfers as before. */
    private fun startGroupSession(sock: java.net.Socket, host: Boolean) {
        scanJob?.cancel()
        groupMode = true
        connected = true
        peerId = null
        amHost = host
        peerName = tr("Connected phone", "جُڑا ہوا فون")
        reconnectName = null; resumeCount = 0
        TransferService.start(ctx)
        startWatchdog()
        startSpeedTicker()
        screen = Screen.CONNECTED
        startTurbo(sock)
        turbo?.sendHello(myName)
    }
    private val hotspotFailedFor = HashSet<String>()
    private var lohIps: List<String>? = null
    private var lohPort = 0

    /** Host: send the network details, wait for "ready", free Wi-Fi, create the network, wait for the other device. */
    private suspend fun startNetworkRouteHost(pid: String) {
        val (ssid, pass) = Turbo.newCredentials()
        turboAnswer = 0
        dlog("Sending Wi-Fi details for $ssid")
        client.sendPayload(pid, Payload.fromBytes("P2PL|$ssid|$pass".toByteArray(Charsets.UTF_8)))
        val until = System.currentTimeMillis() + 12_000
        while (turboAnswer == 0 && System.currentTimeMillis() < until && !pairingClosed) delay(100)
        if (turboAnswer != 1) {
            lastTurboError = "other device didn't answer"
            if (!pairingClosed) client.sendPayload(pid, Payload.fromBytes("TURBOCANCEL|0|0".toByteArray(Charsets.UTF_8)))
            turboFailed(); return
        }
        dlog("Other device is ready. Closing the pairing link so Wi-Fi is free")
        delay(500)
        client.disconnectFromEndpoint(pid)
        peerId = null
        client.stopAdvertising(); client.stopDiscovery(); client.stopAllEndpoints()
        delay(3000) // Google's pairing may still hold Wi-Fi for a moment: creating too early is what failed on TECNO
        // Phase 1: this phone creates the network and waits for the other phone
        dlog("Phase 1: creating $ssid")
        val sock = Turbo.host(ctx, ssid, pass, createMs = 20_000, acceptMs = PHASE1_ACCEPT_MS)
        if (sock != null) { markCanHost(); ownGroup = true; startTurbo(sock); return }
        val err = Turbo.lastError ?: ""
        if (err.startsWith("Create network") || err.startsWith("Wi-Fi Direct not available")) {
            dlog("This device couldn't create the network ($err)")
            markCannotHost()
        } else dlog("Nobody joined $ssid")
        // Phase 2 (agreed in advance, no talking needed): the OTHER phone creates plan-B network, we join it
        Turbo.shutdown(ctx, removeOwnGroup = true)
        val (ssid2, pass2) = planB(ssid)
        dlog("Phase 2: joining the other phone's network $ssid2")
        joinTarget = ssid2
        val sock2 = Turbo.joinAny(ctx, ssid2, pass2, 1, 70_000)
        joinTarget = null
        if (sock2 != null) startTurbo(sock2) else { lastTurboError = Turbo.lastError; turboFailed() }
    }

    /** Plan-B network both phones work out from the first one (so they never need to talk again). */
    private fun planB(ssid: String): Pair<String, String> {
        val s2 = (ssid + "B").take(32)
        return s2 to Turbo.groupPass(s2)
    }

    private companion object {
        /** Creator waits this long for the joiner in phase 1 (covers scan + Android's join screen). */
        const val PHASE1_ACCEPT_MS = 75_000
    }

    /** Client: say "ready", then join the host's network like a normal Wi-Fi (as this app's own network). */
    private fun joinNetworkRoute(ssid: String, pass: String) {
        val pid = peerId ?: return
        if (turbo != null) return
        switching = true
        pairingClosed = false
        switchStartedAt = System.currentTimeMillis()
        dlog("Got Wi-Fi details for $ssid")
        turboJob?.cancel()
        turboJob = viewModelScope.launch {
            launch {
                repeat(6) {
                    if (pairingClosed || turbo != null) return@launch
                    client.sendPayload(pid, Payload.fromBytes("TURBOOK|0|0".toByteArray(Charsets.UTF_8)))
                    delay(700)
                }
            }
            delay(5000) // the host closes the pairing link and creates its network: don't look for it too early
            // Phase 1: join the other phone's network
            joinTarget = ssid
            val sock = Turbo.joinAny(ctx, ssid, pass, 1, 55_000)
            joinTarget = null
            if (Turbo.silentJoinFailedNow) prefs.edit().putBoolean("silentJoinOk", false).apply()
            peerId = null
            if (sock != null) { startTurbo(sock); return@launch }
            // Phase 2 (agreed in advance): the other phone couldn't host, so THIS phone creates plan-B and waits
            dlog("Phase 1 didn't work (${Turbo.lastError ?: "unknown"}). Phase 2: creating the network here")
            Turbo.leaveHotspot(ctx)
            val (ssid2, pass2) = planB(ssid)
            val sock2 = Turbo.host(ctx, ssid2, pass2, createMs = 20_000, acceptMs = 90_000)
            if (sock2 != null) { ownGroup = true; startTurbo(sock2) }
            else { lastTurboError = Turbo.lastError; turboFailed() }
        }
    }

    /** Host side of Route 1. True if Turbo started. */
    private suspend fun startHotspotRoute(pid: String): Boolean {
        val info = Turbo.startHotspot(ctx) ?: return false
        val port = Turbo.PORT + 2
        val ss = withContext(Dispatchers.IO) {
            runCatching {
                java.net.ServerSocket().apply {
                    reuseAddress = true
                    bind(java.net.InetSocketAddress(port)); soTimeout = 80_000
                }
            }.getOrNull()
        } ?: run { Turbo.stopHotspot(); return false }
        lanServer = ss
        client.sendPayload(pid, Payload.fromBytes("LOH|${info.ssid}|${info.sec}:${info.pass}".toByteArray(Charsets.UTF_8)))
        // our hotspot address appears a moment after it starts
        var ips = emptyList<String>()
        repeat(10) { if (ips.isEmpty()) { delay(400); ips = Turbo.localAddresses() } }
        client.sendPayload(pid, Payload.fromBytes("LOHIP|${ips.joinToString(",")}|$port".toByteArray(Charsets.UTF_8)))
        dlog("Waiting for the other phone to join (it may need to tap Connect)")
        val sock = withContext(Dispatchers.IO) { runCatching { ss.accept() }.getOrNull() }
        runCatching { ss.close() }; lanServer = null
        if (sock == null) {
            if (Turbo.lastError == null) Turbo.lastError = "the other phone didn't join the hotspot"
            Turbo.stopHotspot()
            return false
        }
        Turbo.tune(sock)
        startTurbo(sock)
        return true
    }

    /** Client side of Route 1: join the host's Asan Share hotspot and connect. */
    private fun joinHostHotspot(ssid: String, secPass: String) {
        val pid = peerId ?: return
        if (turbo != null) return
        val sec = secPass.substringBefore(':').toIntOrNull() ?: 1
        val pass = secPass.substringAfter(':')
        switching = true
        switchStartedAt = System.currentTimeMillis()
        turboJob?.cancel()
        turboJob = viewModelScope.launch {
            val net = Turbo.joinHotspot(ctx, ssid, pass, sec)
            if (net == null) {
                dlog("Couldn't join: ${Turbo.lastError ?: "unknown"}")
                client.sendPayload(pid, Payload.fromBytes("LOHFAIL|0|0".toByteArray(Charsets.UTF_8)))
                Turbo.leaveHotspot(ctx)
                switching = false
                return@launch
            }
            // wait for the host's address list (usually already here)
            var waited = 0
            while (lohIps == null && waited < 6000) { delay(200); waited += 200 }
            val ips = ((lohIps ?: emptyList()) + Turbo.gatewayOf(ctx, net)).distinct()
            val sock = Turbo.connectOn(net, ips, if (lohPort > 0) lohPort else Turbo.PORT + 2)
            if (sock != null) {
                startTurbo(sock)
            } else {
                dlog("Joined but couldn't connect: ${Turbo.lastError ?: "unknown"}")
                client.sendPayload(pid, Payload.fromBytes("LOHFAIL|0|0".toByteArray(Charsets.UTF_8)))
                Turbo.leaveHotspot(ctx)
                switching = false
            }
        }
    }

    // ---------- Role swap ----------
    // The phone that RECEIVES the connection request is the one that has to create the fast Wi-Fi link.
    // Some devices can't (no hotspot, e.g. Wi-Fi-only tablets). Then we swap: the other phone asks instead.
    private val swappedWith = HashSet<String>()
    /** We asked the other phone to reconnect to us: don't start a connection ourselves meanwhile. */
    private var waitForPeer: String? = null
    /** The other phone asked us to start the connection to it. */
    private var connectTo: String? = null

    private fun checkNeedSwap(wasRequester: Boolean) {
        val who = peerName ?: return
        if (true) return // replaced: we swap only when this phone can't create a hotspot
        if (!wasRequester || swappedWith.contains(who)) return
        viewModelScope.launch {
            delay(9000)
            // still only Bluetooth between us, no Turbo: the other side couldn't build the Wi-Fi link
            if (connected && turbo == null && link < 2 && peerName == who && !swappedWith.contains(who)) {
                val pid = peerId ?: return@launch
                swappedWith.add(who)
                dlog("No Wi-Fi link (the other device can't host it). Asking it to connect to us instead")
                waitForPeer = who
                client.sendPayload(pid, Payload.fromBytes("SWAP|0|0".toByteArray(Charsets.UTF_8)))
                viewModelScope.launch { delay(30_000); if (waitForPeer == who) waitForPeer = null }
            }
        }
    }

    private fun onSwapRequest() {
        val who = peerName ?: return
        dlog("Swapping roles: reconnecting to $who from this side")
        swappedWith.add(who)
        turboJob?.cancel()
        switching = false
        connectTo = who
        viewModelScope.launch { delay(30_000); if (connectTo == who) connectTo = null }
        val pid = peerId
        if (pid != null) client.disconnectFromEndpoint(pid)
        lostConnection() // goes back to the radar; we will connect to it as soon as it shows up
    }

    /**
     * While Wi-Fi Direct is the plan, the pairing link must NOT grab Wi-Fi (it would try a hotspot,
     * which tablets like the Tab A7 don't have). After a Wi-Fi Direct failure, let it use Wi-Fi fully.
     */
    private fun pairingType(): Int = ConnectionType.DISRUPTIVE

    private fun canTurbo(): Boolean {
        if (standardOnly) return false
        val wifi = ctx.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        return Turbo.supported() && peerSdk >= 29 && wifi?.isWifiEnabled == true && !turboFailedFor.contains(peerName ?: "")
    }

    /** Host side: tell the other phone the private Wi-Fi details, then build the Turbo link. */
    /** This phone's address on the home/office Wi-Fi (not the private Wi-Fi Direct one). */
    private fun lanIp(): String? = runCatching {
        java.net.NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback && it.name.startsWith("wlan") && !it.name.contains("p2p") }
            .flatMap { ni -> ni.inetAddresses.toList().filterIsInstance<java.net.Inet4Address>() }
            .firstOrNull { it.isSiteLocalAddress }?.hostAddress
    }.getOrNull()

    private var lanServer: java.net.ServerSocket? = null
    private var turboJob: Job? = null
    /** The pairing link closed while we were setting up Turbo. */
    private var pairingClosed = false

    /**
     * Host: find the fastest route.
     * 1) Both on the same Wi-Fi (home/office)? Connect straight over it. Nothing to set up, very reliable.
     * 2) Otherwise build a private Wi-Fi Direct network.
     */
    /**
     * TURBO, reliable version: the pairing link has already built a fast Wi-Fi path between the phones
     * (Wi-Fi Direct / hotspot / same router). We KEEP it and simply open our own direct data stream over it.
     * Nothing is torn down or rebuilt, so nothing can fall out of sync.
     */
    private fun startTurboAsHost() {
        val pid = peerId ?: return
        if (switching || turbo != null) return
        switching = true
        pairingClosed = false
        switchStartedAt = System.currentTimeMillis()
        turboJob = viewModelScope.launch {
            // Route 1 (best, works without any hotspot): our own private Wi-Fi Direct network, 5 GHz when possible
            // Route 1 (Zapya-style): this device creates a Wi-Fi network with a name/password chosen IN ADVANCE,
            // the pairing link is closed (Wi-Fi fully free), the other device joins it like a normal Wi-Fi.
            if (Turbo.supported() && peerSdk >= 29 && !p2pFailedFor.contains(peerName ?: "")) {
                startNetworkRouteHost(pid)
                return@launch
            }
            if (false && Turbo.supported() && peerSdk >= 29 && !hotspotFailedFor.contains(peerName ?: "")) {
                if (startHotspotRoute(pid)) return@launch
                val who = peerName ?: ""
                hotspotFailedFor.add(who)
                dlog("Own hotspot didn't work here: ${Turbo.lastError ?: "unknown"}")
                // This device can't host (e.g. tablet without hotspot): let the OTHER phone host instead
                if (!swappedWith.contains(who) && connected) {
                    swappedWith.add(who)
                    dlog("Asking $who to host the hotspot instead")
                    client.sendPayload(pid, Payload.fromBytes("SWAPME|0|0".toByteArray(Charsets.UTF_8)))
                    delay(500)
                    onSwapRequest()
                    return@launch
                }
            }
            if (false) { // own Wi-Fi Direct route disabled: doesn't work on some devices (e.g. Tab A7)
                dlog("Building a private Wi-Fi Direct link (no hotspot needed)")
                startP2pHost(pid)
                return@launch
            }
            // Route 2: reuse the Wi-Fi path the pairing link already built
            // give the fast Wi-Fi path a moment to come up (up to 12 s)
            val until = System.currentTimeMillis() + 12_000
            while (link < 2 && System.currentTimeMillis() < until && connected) delay(250)
            // Linked only through the home router? Build a direct phone-to-phone Wi-Fi first (much faster),
            // keeping everything else as it is. If that doesn't work in time, use the router path below.
            if (false) { // direct "boost" disabled: rebuilding Wi-Fi mid-connection breaks the link on some tablets
                dlog("Phones are linked through the Wi-Fi router: building a faster direct link")
                if (tryDirectBoost(pid)) return@launch
                peerName?.let { boostFailedFor.add(it) }
                dlog("Direct link didn't work: using the router path")
            }
            val ips = Turbo.localAddresses()
            if (ips.isEmpty()) {
                dlog("No Wi-Fi path between the phones yet")
                lastTurboError = "no Wi-Fi path"
                stayStandard(); return@launch
            }
            dlog("Opening Turbo on " + ips.joinToString(", "))
            val ss = withContext(Dispatchers.IO) {
                runCatching {
                    java.net.ServerSocket().apply {
                        reuseAddress = true
                        bind(java.net.InetSocketAddress(Turbo.PORT + 1)); soTimeout = 18_000
                    }
                }.getOrNull()
            }
            if (ss == null) { lastTurboError = "couldn't open Turbo port"; stayStandard(); return@launch }
            lanServer = ss
            client.sendPayload(pid, Payload.fromBytes("ADDR|${ips.joinToString(",")}|${Turbo.PORT + 1}".toByteArray(Charsets.UTF_8)))
            val sock = withContext(Dispatchers.IO) { runCatching { ss.accept() }.getOrNull() }
            runCatching { ss.close() }; lanServer = null
            if (sock != null) {
                Turbo.tune(sock)
                dlog("Other phone connected")
                startTurbo(sock) // the pairing link stays up underneath and keeps the Wi-Fi path alive
            } else {
                dlog("Other phone couldn't connect")
                if (lastTurboError == null) lastTurboError = "other phone couldn't connect"
                stayStandard()
            }
        }
    }

    private val boostFailedFor = HashSet<String>()
    /** True while Turbo runs on a Wi-Fi Direct network that WE created (must be removed afterwards). */
    private var ownGroup = false
    private fun shutdownTurbo() { val own = ownGroup; ownGroup = false; viewModelScope.launch { Turbo.shutdown(ctx, removeOwnGroup = own) } }
    private var boostAnswer = 0 // 0 waiting, 2 = other phone couldn't join

    /** Host: private Wi-Fi Direct network next to the router connection (nothing is disconnected). */
    private suspend fun tryDirectBoost(pid: String): Boolean {
        val (ssid, pass) = Turbo.newCredentials()
        boostAnswer = 0
        val sock = Turbo.host(ctx, ssid, pass, createMs = 8_000, acceptMs = 25_000) {
            dlog("Direct link ready, asking the other phone to join")
            client.sendPayload(pid, Payload.fromBytes("BOOST|$ssid|$pass".toByteArray(Charsets.UTF_8)))
        }
        if (sock == null) {
            dlog("Direct link failed: ${Turbo.lastError ?: "unknown"}")
            viewModelScope.launch { Turbo.shutdown(ctx, removeOwnGroup = true) }
            return false
        }
        ownGroup = true
        startTurbo(sock)
        return true
    }

    /** Client: join the host's direct Wi-Fi next to our router connection. */
    private fun joinDirectBoost(ssid: String, pass: String) {
        val pid = peerId ?: return
        if (turbo != null) return
        switching = true
        switchStartedAt = System.currentTimeMillis()
        dlog("Joining the faster direct link")
        turboJob?.cancel()
        turboJob = viewModelScope.launch {
            val sock = Turbo.join(ctx, ssid, pass, firstDelay = 300, joinMs = 10_000, formedMs = 10_000, connectMs = 8_000)
            if (sock != null) {
                ownGroup = true
                startTurbo(sock)
            } else {
                dlog("Couldn't join the direct link: ${Turbo.lastError ?: "unknown"}")
                Turbo.shutdown(ctx, removeOwnGroup = true) // leave the half-joined network
                client.sendPayload(pid, Payload.fromBytes("BOOSTFAIL|0|0".toByteArray(Charsets.UTF_8)))
                // stay in "switching": the host will now offer the router path (ADDR)
            }
        }
    }

    /** Turbo isn't possible right now: keep the normal link, keep working, explain why. */
    private fun stayStandard() {
        switching = false
        if (pairingClosed && turbo == null) {
            // the normal link died while we were trying Turbo: reconnect instead of pretending to be connected
            dlog("Link was lost during Turbo setup: reconnecting")
            lostConnection()
            return
        }
        peerName?.let { turboFailedFor.add(it) }
        dlog("Using standard speed")
        explainNoTurbo()
        startQueuedWork()
        pump()
    }

    /** Client: connect to the host over the existing fast Wi-Fi path. */
    private fun connectDirect(ips: List<String>, port: Int) {
        val pid = peerId ?: return
        if (turbo != null) return
        switching = true
        switchStartedAt = System.currentTimeMillis()
        dlog("Turbo offered on " + ips.joinToString(", "))
        turboJob?.cancel()
        turboJob = viewModelScope.launch {
            val sock = Turbo.connectAny(ctx, ips, port)
            if (sock != null) {
                startTurbo(sock)
            } else {
                dlog("Couldn't reach the other phone's Turbo")
                lastTurboError = "couldn't reach the other phone"
                client.sendPayload(pid, Payload.fromBytes("LANFAIL|0|0".toByteArray(Charsets.UTF_8)))
                stayStandard()
            }
        }
    }

    private suspend fun startP2pHost(pid: String) {
        val (ssid, pass) = Turbo.newCredentials()
        turboAnswer = 0
        dlog("Asking the other phone to join a private Wi-Fi")
        client.sendPayload(pid, Payload.fromBytes("TURBO|$ssid|$pass".toByteArray(Charsets.UTF_8)))
        // Wait (up to 12 s) for "ready". The other phone repeats it, so one lost message doesn't matter.
        val until = System.currentTimeMillis() + 12_000
        while (turboAnswer == 0 && System.currentTimeMillis() < until && !pairingClosed) delay(100)
        if (turboAnswer != 1) {
            dlog(if (turboAnswer == 2) "Other phone can't use Turbo" else "Other phone didn't confirm")
            lastTurboError = if (turboAnswer == 2) "other phone can't use Turbo" else "other phone didn't answer"
            if (!pairingClosed) client.sendPayload(pid, Payload.fromBytes("TURBOCANCEL|0|0".toByteArray(Charsets.UTF_8)))
            // reconnect with full Wi-Fi allowed and use the other Turbo route
            turboFailed()
            return
        }
        dlog("Other phone is ready")
        delay(300)
        client.disconnectFromEndpoint(pid) // free Wi-Fi for the private network
        peerId = null
        val sock = Turbo.host(ctx, ssid, pass)
        if (sock != null) { ownGroup = true; startTurbo(sock) } else turboFailed()
    }

    /** Client: the host offers a route over the shared Wi-Fi network. */
    private fun tryLanAsClient(ip: String, port: Int) {
        val pid = peerId ?: return
        if (turbo != null) return
        switching = true
        switchStartedAt = System.currentTimeMillis()
        dlog("Trying Turbo over your Wi-Fi network (to $ip)")
        turboJob = viewModelScope.launch {
            val sock = withContext(Dispatchers.IO) {
                runCatching {
                    java.net.Socket().apply {
                        connect(java.net.InetSocketAddress(ip, port), 4000)
                    }
                }.getOrNull()
            }
            if (sock != null) {
                Turbo.tune(sock)
                dlog("Connected over your Wi-Fi network")
                startTurbo(sock) // the host closes the pairing link
            } else {
                dlog("Can't reach it over the Wi-Fi network")
                switching = false // the host will offer a private Wi-Fi next
                client.sendPayload(pid, Payload.fromBytes("LANFAIL|0|0".toByteArray(Charsets.UTF_8)))
            }
        }
    }

    /** Client: join the host's private Wi-Fi and connect. */
    private fun startTurboAsClient(ssid: String, pass: String) {
        val pid = peerId ?: return
        if (turbo != null) return
        switching = true
        pairingClosed = false
        switchStartedAt = System.currentTimeMillis()
        dlog("Private Wi-Fi offered, getting ready")
        turboJob?.cancel()
        turboJob = viewModelScope.launch {
            // Say "ready" a few times (the host closes the pairing link when it hears it). Never close it ourselves.
            launch {
                repeat(6) {
                    if (pairingClosed || turbo != null) return@launch
                    client.sendPayload(pid, Payload.fromBytes("TURBOOK|0|0".toByteArray(Charsets.UTF_8)))
                    delay(700)
                }
            }
            val sock = Turbo.join(ctx, ssid, pass)
            peerId = null
            if (sock != null) { ownGroup = true; startTurbo(sock) } else turboFailed()
        }
    }

    /** Host gave up on the private Wi-Fi: stop joining, keep using the normal link. */
    private fun cancelTurboAsClient() {
        dlog("Host cancelled Turbo, staying on standard speed")
        turboJob?.cancel()
        switching = false
        peerName?.let { p2pFailedFor.add(it) } // the host will reconnect and use the other route
        lastTurboError = "host cancelled"
        shutdownTurbo()
        explainNoTurbo()
        startQueuedWork()
        pump()
    }

    init {
        viewModelScope.launch {
            while (true) {
                delay(5000)
                if (switching && System.currentTimeMillis() - switchStartedAt > 220_000) turboFailed()
            }
        }
    }
    private var switchStartedAt = 0L

    private fun saveBand() {} // band memory removed: it could lock a phone to slow 2.4 GHz

    private fun startTurbo(sock: java.net.Socket) {
        saveBand()
        if (!connected) { dlog("Turbo link ready but session already closed"); runCatching { sock.close() }; return }
        val iface = Turbo.ifaceOf(sock) ?: "?"
        dlog("TURBO ON via $iface (${sock.localAddress?.hostAddress} -> ${sock.inetAddress?.hostAddress})")
        linkText = null
        Turbo.linkInfo(ctx, Turbo.joinedNetwork)?.let { linkText = it; dlog("Wi-Fi link: $it") }
        if (linkText == null) viewModelScope.launch { Turbo.groupBand(ctx)?.let { linkText = it; dlog("Wi-Fi link: $it") } }
        viewModelScope.launch {
            while (turbo != null) {
                val on = Turbo.alsoOnRouterWifi(ctx)
                if (on != routerTip) { routerTip = on; if (on) dlog("This device is also on a home Wi-Fi: Turbo will be slower") }
                turbo?.probeDelay()
                delay(10_000)
            }
            routerTip = false
        }
        val direct = iface.contains("p2p") || iface.startsWith("ap") || iface.contains("swlan") || iface == "wlan1"
        val onRouter = iface.startsWith("wlan") && !direct
        if (false && (onRouter || ownGroup)) {
            // Turbo doesn't depend on the pairing link here: close it so Bluetooth/second Wi-Fi channel stop slowing us down
            viewModelScope.launch {
                delay(1500)
                if (turbo != null) peerId?.let { dlog("Closing pairing link (not needed)"); client.disconnectFromEndpoint(it) }
            }
        }
        engineNote = null
        Turbo.holdLocks(ctx)
        val link = TurboLink(sock, ::openSource, ::openSink, turboCallbacks)
        turbo = link
        turboRemote = sock.inetAddress
        val accepted = sock.localPort in setOf(Turbo.PORT, Turbo.PORT + 1, Turbo.PORT + 2)
        if (accepted) openLanes(link)
        switching = false
        this.link = 4
        lastProgressAt = System.currentTimeMillis()
        // Anything that was half-way on the old (Nearby) link: send it again on Turbo
        onWire.clear()
        val queued = queue.map { it.first }.toSet()
        for (i in transfers.indices) {
            val t = transfers[i]
            val busy = t.state == TState.RUNNING || t.state == TState.WAITING
            if (!busy) continue
            if (t.incoming) { transfers[i] = t.copy(state = TState.FAILED); continue }
            val src = t.source ?: continue
            if (t.id in queued) continue
            val ph = nextPlaceholder--
            transfers[i] = t.copy(id = ph, state = TState.WAITING, done = 0, started = false)
            queue.addLast(ph to src)
        }
        link.start()
        startQueuedWork()
        pump()
    }

    /** Turbo couldn't be built: reconnect the normal way (Nearby) and remember not to try again with this phone. */
    private var lastTurboError: String? = null
    /** Host waits for the other phone: 0 = no answer yet, 1 = ready, 2 = can't. */
    private var turboAnswer = 0

    /** Try Turbo again with this phone (after a failure). */
    fun retryTurbo() {
        standardOnly = false
        dlog("Trying Turbo again")
        peerName?.let { turboFailedFor.remove(it) }
        engineNote = null
        if (connected && amHost && canTurbo()) startTurboAsHost()
        else if (connected) peerId?.let { client.sendPayload(it, Payload.fromBytes("RETRYTURBO|0|0".toByteArray(Charsets.UTF_8))) }
    }

    private fun turboFailed() {
        turboJob?.cancel()
        runCatching { lanServer?.close() }; lanServer = null
        lastTurboError = Turbo.lastError ?: lastTurboError
        dlog("Fast Wi-Fi link failed: ${lastTurboError ?: "unknown"}. Reconnecting at standard speed")
        switching = false
        peerName?.let {
            val n = (p2pAttempts[it] ?: 0) + 1
            p2pAttempts[it] = n
            if (n >= 2) p2pFailedFor.add(it) // tried twice (also with swapped roles): stay at standard speed
        }
        shutdownTurbo()
        lostConnection()
    }

    private fun openSource(f: PickedFile): Source? = runCatching {
        val pfd = if (f.uri.scheme == "file") ParcelFileDescriptor.open(File(f.uri.path!!), ParcelFileDescriptor.MODE_READ_ONLY)
        else ctx.contentResolver.openFileDescriptor(f.uri, "r")!!
        val fis = java.io.FileInputStream(pfd.fileDescriptor)
        object : Source {
            override val channel: java.nio.channels.FileChannel = fis.channel
            override fun close() { runCatching { fis.close() }; runCatching { pfd.close() } }
        }
    }.getOrNull()

    /** Incoming Turbo file: write straight to its final place (no copy later). */
    @Suppress("DEPRECATION")
    private fun openSink(rawName: String, size: Long): Sink? = runCatching {
        val name = safeName(rawName)
        if (canUseOwnFolder()) {
            val dir = File(rootFolder(), subFolder(name)).apply { mkdirs() }
            val file = uniqueFile(dir, name)
            val raf = java.io.RandomAccessFile(file, "rw")
            object : Sink {
                override val channel: java.nio.channels.FileChannel = raf.channel
                override fun finish(): Uri? {
                    runCatching { raf.close() }
                    MediaScannerConnection.scanFile(ctx, arrayOf(file.path), null, null)
                    return FileProvider.getUriForFile(ctx, ctx.packageName + ".files", file)
                }
                override fun abort() { runCatching { raf.close() }; file.delete() }
            }
        } else if (Build.VERSION.SDK_INT >= 29) {
            val r = ctx.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + SAVE_FOLDER)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val dst = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)!!
            val pfd = r.openFileDescriptor(dst, "rw")!!
            val fos = java.io.FileOutputStream(pfd.fileDescriptor)
            object : Sink {
                override val channel: java.nio.channels.FileChannel = fos.channel
                override fun finish(): Uri? {
                    runCatching { fos.close() }; runCatching { pfd.close() }
                    val v = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                    r.update(dst, v, null, null)
                    return dst
                }
                override fun abort() { runCatching { fos.close() }; runCatching { pfd.close() }; runCatching { r.delete(dst, null, null) } }
            }
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), SAVE_FOLDER).apply { mkdirs() }
            val file = uniqueFile(dir, name)
            val raf = java.io.RandomAccessFile(file, "rw")
            object : Sink {
                override val channel: java.nio.channels.FileChannel = raf.channel
                override fun finish(): Uri? {
                    runCatching { raf.close() }
                    MediaScannerConnection.scanFile(ctx, arrayOf(file.path), null, null)
                    return FileProvider.getUriForFile(ctx, ctx.packageName + ".files", file)
                }
                override fun abort() { runCatching { raf.close() }; file.delete() }
            }
        }
    }.getOrNull()

    private fun uniqueFile(dir: File, name: String): File {
        var out = File(dir, name)
        var n = 1
        val base = name.substringBeforeLast('.')
        val ext = name.substringAfterLast('.', "")
        while (out.exists()) out = File(dir, if (ext.isEmpty()) "$base (${n++})" else "$base (${n++}).$ext")
        return out
    }

    private var turboRemote: java.net.InetAddress? = null
    private var laneServer: java.net.ServerSocket? = null
    private val LANES = 3

    /** Accepting side: listen for the extra lanes and tell the other side to connect them. */
    private fun openLanes(link: TurboLink) {
        viewModelScope.launch(Dispatchers.IO) {
            var ss: java.net.ServerSocket? = null
            repeat(6) {
                if (ss == null) ss = runCatching {
                    java.net.ServerSocket().apply { reuseAddress = true; bind(java.net.InetSocketAddress(Turbo.PORT + 3)); soTimeout = 10_000 }
                }.getOrNull()
                if (ss == null) delay(300)
            }
            val server = ss ?: return@launch // no extra lanes: the main connection still works on its own
            laneServer = server
            link.offerLanes(Turbo.PORT + 3, LANES)
            repeat(LANES) {
                val s = runCatching { server.accept() }.getOrNull() ?: return@repeat
                Turbo.tune(s); link.addLane(s)
            }
            runCatching { server.close() }; laneServer = null
            withContext(Dispatchers.Main) { dlog("Turbo lanes: ${link.laneCount}") }
        }
    }

    private val turboCallbacks = object : TurboLink.Callbacks {
        override fun onIncomingCancelled(remoteId: Long) {
            val id = incomingIds.remove(remoteId) ?: return
            val i = transfers.indexOfFirst { it.id == id }
            if (i >= 0 && transfers[i].active) transfers[i] = transfers[i].copy(state = TState.CANCELLED, speed = 0.0)
            notifyProgress()
        }
        override fun onOutgoingCancelled(id: Long) {
            val i = transfers.indexOfFirst { it.id == id }
            if (i >= 0 && transfers[i].active) transfers[i] = transfers[i].copy(state = TState.CANCELLED, speed = 0.0)
            notifyProgress()
        }
        override fun onLanesOffer(port: Int, count: Int) {
            val link = turbo ?: return
            val ip = turboRemote ?: return
            val net = Turbo.joinedNetwork
            viewModelScope.launch(Dispatchers.IO) {
                repeat(count) {
                    val s = runCatching {
                        (net?.socketFactory?.createSocket() ?: java.net.Socket()).apply {
                            connect(java.net.InetSocketAddress(ip, port), 4000)
                        }
                    }.getOrNull()
                    if (s != null) { Turbo.tune(s); link.addLane(s) }
                }
                withContext(Dispatchers.Main) { dlog("Turbo lanes: ${link.laneCount}") }
            }
        }
        override fun onBatch(count: Int, bytes: Long) {
            beginRunIfIdle(); runExpectedCount += count; runExpectedBytes += bytes
            expectedCount += count; expectedBytes += bytes
            lastProgressAt = System.currentTimeMillis()
            notifyProgress()
        }
        override fun onIncomingStart(remoteId: Long, name: String, size: Long) {
            lastProgressAt = System.currentTimeMillis()
            val clean = safeName(name)
            beginRunIfIdle()
            val old = transfers.indexOfFirst { it.incoming && it.name == clean && it.size == size && (it.state == TState.FAILED || (it.state == TState.WAITING && it.done == 0L)) }
            val rowId = if (old >= 0) transfers[old].id else nextIncoming++
            incomingIds[remoteId] = rowId
            if (old >= 0) transfers[old] = transfers[old].copy(state = TState.RUNNING, done = 0)
            else { val row = Transfer(rowId, clean, size, incoming = true, state = TState.RUNNING); transfers.add(row) }
            transfers.firstOrNull { it.id == rowId }?.let { addToRun(it) }
        }
        override fun onIncomingProgress(remoteId: Long, done: Long) {
            lastProgressAt = System.currentTimeMillis()
            val id = incomingIds[remoteId] ?: return
            val i = transfers.indexOfFirst { it.id == id }
            if (i >= 0 && transfers[i].state != TState.CANCELLED) transfers[i] = transfers[i].copy(state = TState.RUNNING, done = done)
            notifyProgress()
        }
        override fun onIncomingDone(remoteId: Long, saved: Uri?) {
            lastProgressAt = System.currentTimeMillis()
            val id = incomingIds.remove(remoteId) ?: return
            val i = transfers.indexOfFirst { it.id == id }
            if (i >= 0) transfers[i] = transfers[i].copy(
                state = if (saved != null) TState.DONE else TState.FAILED,
                done = if (saved != null) transfers[i].size else transfers[i].done, saved = saved,
            )
            notifyProgress()
        }
        override fun onOutgoingProgress(id: Long, done: Long) {
            lastProgressAt = System.currentTimeMillis()
            val i = transfers.indexOfFirst { it.id == id }
            if (i >= 0 && transfers[i].state != TState.DONE && transfers[i].state != TState.CANCELLED) transfers[i] = transfers[i].copy(state = TState.RUNNING, done = done)
            notifyProgress()
        }
        override fun onOutgoingDone(id: Long, ok: Boolean) {
            lastProgressAt = System.currentTimeMillis()
            val i = transfers.indexOfFirst { it.id == id }
            if (i >= 0) transfers[i] = transfers[i].copy(
                state = if (ok) TState.DONE else TState.FAILED, done = if (ok) transfers[i].size else transfers[i].done,
            )
            notifyProgress()
        }
        override fun onBye() { byeReceived = true }
        override fun onDelay(ms: Long) { dlog("Link delay: $ms ms" + if (ms > 30) " (high: the Wi-Fi is saving power or busy)" else "") }
        override fun onHello(name: String) {
            dlog("Other phone: $name")
            if (historyPeer != name && transfers.none { it.state == TState.RUNNING || it.state == TState.WAITING }) {
                transfers.clear(); expectedCount = 0; expectedBytes = 0L
            }
            historyPeer = name
            peerName = name
            if (groupResume) { groupResume = false; resumeUnfinished() }
        }
        override fun onClosed() {
            dlog(if (closingOnPurpose) "Turbo link closed" else "Turbo link dropped")
            turbo = null
            shutdownTurbo()
            if (closingOnPurpose) { closingOnPurpose = false; return }
            if (connected) lostConnection()
        }
    }

    /** True from tapping Accept until the connection is ready (or fails). */
    private var accepting = false

    fun accept() {
        freshStart()
        request?.let {
            names[it.id] = it.name
            accepting = true
            client.stopDiscovery() // searching while connecting/sending slows everything down
            client.acceptConnection(it.id, payloadCb)
            viewModelScope.launch { delay(30_000); accepting = false }
        }
        request = null
    }

    fun decline() {
        request?.let { client.rejectConnection(it.id) }
        request = null
    }

    /** User chose to leave (Disconnect / Close / Back to home). */
    fun goHome() {
        groupMode = false
        abortTurboSetup()
        reconnectName = null
        resumeCount = 0
        turbo?.let { link ->
            closingOnPurpose = true
            link.sendBye()
            viewModelScope.launch { delay(700); link.close() }
        }
        turbo = null
        switching = false
        turboJob?.cancel()
        runCatching { lanServer?.close() }; lanServer = null
        val pid = peerId
        if (pid != null && connected) {
            // let the other phone know this was on purpose, so it doesn't try to reconnect
            client.sendPayload(pid, Payload.fromBytes("BYE|0|0".toByteArray(Charsets.UTF_8)))
            viewModelScope.launch { delay(900); if (!connected) client.stopAllEndpoints() }
        }
        resetSession()
        clearSelection()
        screen = Screen.HOME
    }

    fun cancelReconnect() {
        reconnectName = null
        resumeCount = 0
        clearSelection()
    }

    private fun resetSession() {
        client.stopDiscovery()
        client.stopAdvertising()
        if (peerId == null) client.stopAllEndpoints()
        // keep the list (so unfinished files can be resumed later), just stop what was running
        for (i in transfers.indices) {
            val t = transfers[i]
            if (t.state == TState.RUNNING || t.state == TState.WAITING)
                transfers[i] = t.copy(state = if (!t.incoming && t.source != null) TState.PAUSED else TState.FAILED, speed = 0.0)
        }
        devices.clear()
        incomingFiles.clear(); startedAt.clear(); names.clear(); lastUi.clear()
        liveSpeed = 0.0
        peerId = null; peerName = null; connected = false; request = null; status = ""
        link = 0; waitingForFast = false; fastTimer?.cancel()
        started = false; failed = false; connecting = null; iRequested = false
        queue.clear(); onWire.clear(); retries.clear(); expectedCount = 0; expectedBytes = 0L; lastNotified = -1
        byeReceived = false
        watchdog?.cancel()
        TransferService.stop(ctx)
    }

    private fun stopAll() {
        client.stopDiscovery()
        client.stopAdvertising()
        client.stopAllEndpoints()
    }

    override fun onCleared() { Turbo.logger = null; stopAll(); TransferService.stop(ctx) }

    private val discoveryCb = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) {
            val (shown, tag) = parseName(info.endpointName)
            if (tag != null && tag == installId) return // that's this phone itself: never show it
            val d = Device(id, shown)
            // same phone with a new ID (it restarted its signal): replace the old, dead entry
            devices.removeAll { it.name == d.name && it.id != id }
            if (devices.none { it.id == id }) devices.add(d)
            // The phone we lost came back: reconnect by ourselves.
            // Only one side asks (the one with unfinished files, or the "smaller" name) to avoid a clash.
            if (connectTo != null && d.name == connectTo) { connectTo = null; connect(d, auto = true); return }
            val lost = reconnectName
            if (lost != null && waitForPeer != lost && System.currentTimeMillis() < reconnectUntil && d.name == lost &&
                (picked.isNotEmpty() || lostPeerToken?.let { myToken < it } ?: (myName < lost))
            ) connect(d, auto = true)
        }
        override fun onEndpointLost(id: String) { devices.removeAll { it.id == id } }
    }

    private val connCb = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            if (info.isIncomingConnection) {
                if (peerId != null || connecting != null) { client.rejectConnection(id); return }
                val shownName = parseName(info.endpointName).first
                if (reconnectName != null && shownName == reconnectName && System.currentTimeMillis() < reconnectUntil) {
                    names[id] = shownName
                    client.acceptConnection(id, payloadCb) // same phone as before: no need to ask again
                    return
                }
                request = Device(id, shownName) // receiver confirms first
                viewModelScope.launch { delay(45_000); if (request?.id == id && !connected) { runCatching { client.rejectConnection(id) }; request = null } }
            } else {
                client.acceptConnection(id, payloadCb)
            }
        }

        override fun onConnectionResult(id: String, res: ConnectionResolution) {
            if (res.status.statusCode == ConnectionsStatusCodes.STATUS_OK) {
                abortTurboSetup()
                peerId = id
                peerName = names[id] ?: "Nearby phone"
                amHost = !iRequested // the phone that accepted builds the Turbo network
                dlog("Paired with ${names[id] ?: "phone"} (" + (if (!iRequested) "this phone hosts Turbo" else "other phone hosts Turbo") + ")")
                peerSdk = 0
                connected = true
                accepting = false
                TransferService.start(ctx)
                startWatchdog()
                peerToken = null
                client.sendPayload(id, Payload.fromBytes("HELLO|$myToken|${Build.VERSION.SDK_INT}".toByteArray(Charsets.UTF_8)))
                client.sendPayload(id, Payload.fromBytes("VER|$myVersion|0".toByteArray(Charsets.UTF_8)))
                peerCanHost = null
                client.sendPayload(id, Payload.fromBytes("CAPS|${myHostScore()}|0".toByteArray(Charsets.UTF_8)))
                engineNote = null; peerOutdated = false; peerVersion = 0L
                // Old app on the other side never says its Android version: explain after a few seconds
                viewModelScope.launch {
                    delay(4000)
                    if (connected && turbo == null && !switching && peerSdk == 0) { peerOutdated = true; explainNoTurbo() }
                }
                status = ""
                client.stopDiscovery()
                client.stopAdvertising()
                val autoSend = picked.isNotEmpty()
                // A different phone: start a fresh list. The same phone: keep the list so files can be resumed.
                if (peerName != historyPeer) {
                    transfers.clear(); meta.clear(); incomingFiles.clear(); completed.clear()
                    expectedCount = 0; expectedBytes = 0L
                    autoResume = false
                }
                historyPeer = peerName
                val resumeNow = autoResume
                autoResume = false
                startSpeedTicker()
                if (waitForPeer == peerName) waitForPeer = null
                checkNeedSwap(wasRequester = !amHost)
                reconnectName = null
                resumeCount = 0
                byeReceived = false
                connecting = null
                iRequested = false
                screen = Screen.CONNECTED
                // Files already chosen (e.g. shared from Gallery): send as soon as the fast link is up
                if (autoSend || resumeNow) {
                    pendingResume = resumeNow
                    waitingForTurbo = true
                    // Connections start on Bluetooth. Wait (max 6 s) for the switch to direct Wi-Fi before sending.
                    waitingForFast = true
                    fastTimer?.cancel()
                    fastTimer = viewModelScope.launch {
                        delay(6000)
                        // Turbo on its way? it will start the work. Otherwise go now.
                        if (waitingForFast && !switching && turbo == null) { waitingForFast = false; startQueuedWork() }
                    }
                }
            } else {
                accepting = false
                if (request?.id == id) request = null
                val who = connecting?.name
                connecting = null
                iRequested = false
                if (screen == Screen.HOME) startRadar()
                if (who != null) status = tr("$who didn't accept. Try again.", "$who نے قبول نہیں کیا۔ دوبارہ کوشش کریں۔")
            }
        }

        override fun onBandwidthChanged(id: String, info: BandwidthInfo) {
            if (id != peerId) return
            if (turbo != null) return // Turbo is running on top: keep showing Turbo
            dlog("Pairing link speed: " + when (info.quality) { BandwidthInfo.Quality.HIGH -> "fast Wi-Fi"; BandwidthInfo.Quality.MEDIUM -> "Wi-Fi"; BandwidthInfo.Quality.LOW -> "Bluetooth"; else -> "unknown" })
            link = when (info.quality) {
                BandwidthInfo.Quality.HIGH -> 3
                BandwidthInfo.Quality.MEDIUM -> 2
                BandwidthInfo.Quality.LOW -> 1
                else -> 0
            }
            if (waitingForFast && link == 3 && !switching && turbo == null && !canTurbo()) {
                waitingForFast = false
                fastTimer?.cancel()
                startQueuedWork()
            }
        }

        override fun onDisconnected(id: String) {
            dlog("Pairing link closed" + if (switching || turbo != null) " (expected, switching to Turbo)" else "")
            if (switching && turbo == null) { pairingClosed = true; return }
            if (turbo != null) { pairingClosed = true; return } // the Turbo stream itself will report if it breaks
            if (id != peerId) return
            lostConnection()
        }
    }

    /** Connection dropped (or got stuck): keep unfinished files and reconnect automatically. */
    private fun lostConnection() {
            abortTurboSetup()
            switching = false
            turbo?.let { closingOnPurpose = true; it.close() }
            turbo = null
            shutdownTurbo()
            if (groupMode) {
                groupMode = false
                val who = peerName ?: tr("the other phone", "دوسرے فون")
                val bye = byeReceived
                val keep = transfers.any { !it.incoming && it.state != TState.DONE && it.source != null }
                resetSession()
                groupResume = keep
                screen = Screen.HOME
                status = if (bye) "$who " + tr("disconnected", "نے رابطہ ختم کر دیا")
                else tr("Connection to $who was lost. Create or join the group again; unfinished files will continue.",
                    "$who سے رابطہ ٹوٹ گیا۔ دوبارہ گروپ بنائیں یا جوائن کریں؛ نامکمل فائلیں جاری ہو جائیں گی۔")
                return
            }
            // Files we were sending that didn't finish: keep them to send again
            val unfinished = transfers.filter { !it.incoming && it.state != TState.DONE }.mapNotNull { it.source }
            peerId = null
            connected = false
            for (i in transfers.indices) {
                val t = transfers[i]
                if (t.state == TState.RUNNING || t.state == TState.WAITING)
                    transfers[i] = t.copy(state = if (!t.incoming && t.source != null) TState.PAUSED else TState.FAILED, speed = 0.0)
            }
            queue.clear(); onWire.clear()
            liveSpeed = 0.0
            TransferService.stop(ctx)
            if (byeReceived) {
                val msg = "${peerName ?: tr("The other phone", "دوسرے فون")} " + tr("disconnected", "نے رابطہ ختم کر دیا")
                resetSession()
                clearSelection()
                reconnectName = null
                resumeCount = 0
                screen = Screen.HOME
                status = msg
                return
            }
            // Accidental drop: go back to the radar and reconnect automatically
            val nowT = System.currentTimeMillis()
            reconnectTimes.addLast(nowT)
            while (reconnectTimes.isNotEmpty() && nowT - reconnectTimes.first() > 120_000) reconnectTimes.removeFirst()
            if (reconnectTimes.size >= 3) {
                // keeps dropping: stop the loop, use standard speed, and let the user decide
                dlog("Connection dropped 3 times in 2 minutes: stopped reconnecting")
                standardOnly = true
                reconnectTimes.clear()
                val who = peerName
                resetSession()
                screen = Screen.HOME
                status = tr("The connection to ${who ?: "the other phone"} kept dropping. Tap it on the radar to connect again (standard speed).",
                    "${who ?: "دوسرے فون"} سے رابطہ بار بار ٹوٹ رہا تھا۔ دوبارہ جوڑنے کے لیے ریڈار پر اس پر ٹیپ کریں (عام رفتار)۔")
                return
            }
            dlog("Connection lost, reconnecting automatically")
            val lost = peerName
            lostPeerToken = peerToken
            val keep = unfinished
            resetSession()
            if (lost != null) {
                reconnectName = lost
                reconnectUntil = System.currentTimeMillis() + 5 * 60_000L
            }
            autoResume = keep.isNotEmpty()
            resumeCount = keep.size
            screen = Screen.HOME
    }

    private var pendingResume = false
    private var waitingForTurbo = false

    private fun startQueuedWork() {
        waitingForFast = false; waitingForTurbo = false
        if (pendingResume) { pendingResume = false; resumeUnfinished() }
        if (picked.isNotEmpty()) sendAll()
    }

    /** Files that stopped half-way (disconnect) and can be sent again. */
    val resumable: Int get() = transfers.count { !it.incoming && it.source != null && (it.state == TState.PAUSED || it.state == TState.FAILED) }

    /** Send unfinished files again, re-using their place in the list. */
    fun resumeUnfinished() {
        if (!connected) return
        beginRunIfIdle()
        lastProgressAt = System.currentTimeMillis()
        for (i in transfers.indices) {
            val t = transfers[i]
            val src = t.source ?: continue
            if (t.incoming || (t.state != TState.PAUSED && t.state != TState.FAILED)) continue
            val ph = nextPlaceholder--
            transfers[i] = t.copy(id = ph, state = TState.WAITING, done = 0, speed = 0.0, started = false)
            addToRun(transfers[i])
            queue.addLast(ph to src)
        }
        pump()
    }

    fun clearHistory() {
        if (transfers.any { it.active }) return
        transfers.clear(); expectedCount = 0; expectedBytes = 0L
        runUids.clear(); runExpectedCount = 0; runExpectedBytes = 0L
    }

    // ---------- "This transfer" vs "Earlier" ----------
    /** Rows that belong to the transfer happening now (the summary counts only these). */
    val runUids = mutableStateMapOf<Long, Boolean>()
    var runExpectedCount by mutableStateOf(0)
    var runExpectedBytes by mutableStateOf(0L)

    /** Start counting a new transfer when nothing is moving and nothing more is announced. */
    private fun beginRunIfIdle() {
        val idle = transfers.none { it.active } && runUids.size >= runExpectedCount
        if (idle) { runUids.clear(); runExpectedCount = 0; runExpectedBytes = 0L }
    }
    private fun addToRun(t: Transfer) { runUids[t.uid] = true }

    // ---------- Cancel ----------
    fun cancelTransfer(t: Transfer) {
        val i = transfers.indexOfFirst { it.uid == t.uid }
        if (i < 0 || !transfers[i].active) return
        val row = transfers[i]
        if (!row.incoming) {
            queue.removeAll { it.first == row.id }
            turbo?.cancelOutgoing(row.id)
            if (turbo == null) { onWire.remove(row.id)?.let { runCatching { client.cancelPayload(row.id) } }; pump() }
        } else {
            val remote = incomingIds.entries.firstOrNull { it.value == row.id }?.key
            if (turbo != null && remote != null) { turbo?.cancelIncoming(remote); incomingIds.remove(remote) }
            else runCatching { client.cancelPayload(row.id) }
        }
        transfers[i] = row.copy(state = TState.CANCELLED, speed = 0.0)
        dlog("Cancelled ${row.name}")
        notifyProgress()
    }

    /** Remove rows from the list (a file still moving is cancelled first). Files already saved stay on the phone. */
    fun removeTransfers(uids: Set<Long>) {
        for (t in transfers.toList()) if (t.uid in uids && t.active) cancelTransfer(t)
        transfers.removeAll { it.uid in uids }
        uids.forEach { runUids.remove(it) }
        if (runUids.isEmpty()) { runExpectedCount = 0; runExpectedBytes = 0L }
    }

    fun cancelAll() {
        for (t in transfers.toList()) if (t.active) cancelTransfer(t)
    }

    private fun startSpeedTicker() {
        speedTicker?.cancel()
        speedTicker = viewModelScope.launch {
            var last = transfers.sumOf { it.done }
            var lastT = System.currentTimeMillis()
            var idle = 0
            while (true) {
                delay(700)
                val now = System.currentTimeMillis()
                val done = transfers.sumOf { it.done }
                val delta = (done - last).coerceAtLeast(0)
                val inst = delta * 1000.0 / (now - lastT).coerceAtLeast(1)
                last = done; lastT = now
                if (delta == 0L) idle++ else idle = 0
                liveSpeed = when {
                    idle >= 6 -> 0.0
                    liveSpeed == 0.0 -> inst
                    else -> liveSpeed * 0.55 + inst * 0.45
                }
                if (!connected && idle >= 6) break
            }
        }
    }

    // ---------- Stuck-transfer watchdog ----------
    private var lastProgressAt = 0L
    private var watchdog: Job? = null

    private fun startWatchdog() {
        lastProgressAt = System.currentTimeMillis()
        watchdog?.cancel()
        watchdog = viewModelScope.launch {
            while (connected) {
                delay(2000)
                client.stopDiscovery()
                client.stopAdvertising()
                val now = System.currentTimeMillis()
                // A file that was handed over but hasn't started after 10 s: cancel it and send it again
                for ((pid, at) in onWire.entries.toList()) {
                    val i = transfers.indexOfFirst { it.id == pid }
                    if (i < 0) { onWire.remove(pid); continue }
                    val t = transfers[i]
                    val src = t.source ?: continue
                    if (t.done == 0L && now - at > 12_000) {
                        val key = src.uri.toString()
                        val n = (retries[key] ?: 0) + 1
                        retries[key] = n
                        if (n > 2) break // keeps failing: let the full reconnect below handle it
                        client.cancelPayload(pid)
                        onWire.remove(pid)
                        val ph = nextPlaceholder--
                        transfers[i] = t.copy(id = ph, state = TState.WAITING, done = 0, started = false)
                        queue.addFirst(ph to src)
                        // (don't reset the 15 s timer: if retrying doesn't help, a quick reconnect will)
                    }
                }
                pump()
                val busy = transfers.any { it.state == TState.WAITING || it.state == TState.RUNNING }
                if (!busy) { lastProgressAt = now; continue }
                // Nothing moved for 15 seconds: the link is stuck. Reconnect and continue by itself.
                if (now - lastProgressAt > 15_000) {
                    turbo?.let { it.close(); return@launch }
                    if (switching) continue
                    val pid = peerId ?: break
                    client.disconnectFromEndpoint(pid)
                    lostConnection()
                    break
                }
            }
        }
    }

    // ---------- Sending ----------
    fun sendMore(uris: List<Uri>) {
        clearSelection()
        addFiles(uris)
        sendAll()
    }

    private fun sendAll() {
        if (!connected) return
        beginRunIfIdle()
        val active = transfers.filter { !it.incoming && (it.state == TState.WAITING || it.state == TState.RUNNING) }
            .mapNotNull { it.source?.uri?.toString() }.toSet()
        val batch = picked.toList().filter { it.uri.toString() !in active }
        if (batch.isEmpty()) { clearSelection(); return }
        lastProgressAt = System.currentTimeMillis()
        val bytes = batch.sumOf { it.size }
        expectedCount += batch.size
        expectedBytes += bytes
        runExpectedCount += batch.size
        runExpectedBytes += bytes
        // tell the receiver how much is coming
        val t = turbo
        val pid = peerId
        if (t != null) t.sendBatch(batch.size, bytes)
        else if (pid != null) client.sendPayload(pid, Payload.fromBytes("BATCH|${batch.size}|$bytes".toByteArray(Charsets.UTF_8)))
        clearSelection()
        for (f in batch) {
            val ph = nextPlaceholder--
            queue.addLast(ph to f)
            val row = Transfer(ph, f.name, f.size, incoming = false, source = f)
            transfers.add(row); addToRun(row)
        }
        pump()
    }

    /** Keeps 2 files on the wire at a time: full speed, little memory, works for any number of files. */
    private fun pump() {
        // Turbo: hand everything to the fast link (it sends one after another at full speed)
        turbo?.let { link ->
            while (queue.isNotEmpty()) {
                val (ph, f) = queue.removeFirst()
                val i = transfers.indexOfFirst { it.id == ph }
                if (i >= 0) transfers[i] = transfers[i].copy(started = true)
                link.sendFile(ph, f)
            }
            return
        }
        if (switching) return // wait until the fast link is ready
        val id = peerId ?: return
        while (onWire.size < 2 && queue.isNotEmpty()) {
            val (ph, f) = queue.removeFirst()
            val idx = transfers.indexOfFirst { it.id == ph }
            val pfd = runCatching {
                if (f.uri.scheme == "file") ParcelFileDescriptor.open(File(f.uri.path!!), ParcelFileDescriptor.MODE_READ_ONLY)
                else ctx.contentResolver.openFileDescriptor(f.uri, "r")
            }.getOrNull()
            if (pfd == null) {
                if (idx >= 0) transfers[idx] = transfers[idx].copy(state = TState.FAILED)
                continue
            }
            val p = Payload.fromFile(pfd)
            // small header so the receiver knows the real file name
            client.sendPayload(id, Payload.fromBytes("${p.id}|${f.size}|${f.name}".toByteArray(Charsets.UTF_8)))
            client.sendPayload(id, p)
            onWire[p.id] = System.currentTimeMillis()
            if (idx >= 0) transfers[idx] = transfers[idx].copy(id = p.id, started = true)
        }
        notifyProgress()
    }

    private var lastNotifyAt = 0L
    /** This device is also on home Wi-Fi during Turbo: show a tip (it slows Turbo down a lot). */
    var routerTip by mutableStateOf(false)
    /** e.g. "5 GHz, 866 Mbps": the real Turbo link, shown in the header. */
    var linkText by mutableStateOf<String?>(null)
    /** Network we're joining right now: shown so people know which one to tap if Android shows a Wi-Fi list. */
    var joinTarget by mutableStateOf<String?>(null)

    private fun notifyProgress() {
        val total = maxOf(expectedBytes, transfers.sumOf { it.size })
        val done = transfers.sumOf { it.done }
        val count = maxOf(expectedCount, transfers.size)
        val finished = transfers.count { it.state == TState.DONE || it.state == TState.FAILED || it.state == TState.CANCELLED }
        val pct = if (total > 0) ((done * 100) / total).toInt() else 0
        val key = pct * 100000 + finished
        if (key == lastNotified) return
        val nowN = System.currentTimeMillis()
        val doneAll = count > 0 && finished >= count
        if (!doneAll && nowN - lastNotifyAt < 1000) return // the status bar redraw was making the screen flicker
        lastNotifyAt = nowN
        lastNotified = key
        val text = if (count > 0 && finished >= count) tr("Done: $count files", "مکمل: $count فائلیں") else tr("$finished of $count files, ${fmt(done)} of ${fmt(total)}", "$count میں سے $finished فائلیں، ${fmt(total)} میں سے ${fmt(done)}")
        TransferService.update(ctx, text, if (finished >= count && count > 0) 100 else pct)
    }

    // ---------- Receiving ----------
    private val payloadCb = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, p: Payload) {
            when (p.type) {
                Payload.Type.BYTES -> {
                    val bytes = p.asBytes() ?: return
                    val parts = String(bytes, Charsets.UTF_8).split("|", limit = 3)
                    if (parts.size < 3) return
                    if (parts[0] == "BYE") { byeReceived = true; return }
                    if (parts[0] == "HELLO") {
                        peerToken = parts[1].toLongOrNull()
                        peerSdk = parts[2].toIntOrNull() ?: 0
                        dlog("Other phone: Android SDK $peerSdk")
                        if (peerSdk == 0) peerOutdated = true
                        if (!canTurbo()) explainNoTurbo()
                        if (canTurbo()) maybeStartTurbo()
                        else if (!canTurbo() && waitingForTurbo) { waitingForTurbo = false; startQueuedWork() }
                        return
                    }
                    if (parts[0] == "RETRYTURBO") {
                        peerName?.let { turboFailedFor.remove(it) }
                        engineNote = null
                        if (amHost && canTurbo()) startTurboAsHost()
                        return
                    }
                    if (parts[0] == "CAPS") {
                        peerHostScore = parts[1].toIntOrNull() ?: 0
                        peerCanHost = peerHostScore > 0
                        maybeStartTurbo()
                        return
                    }
                    if (parts[0] == "VER") {
                        peerVersion = parts[1].toLongOrNull() ?: 0L
                        if (peerVersion in 1 until myVersion) peerOutdated = true
                        return
                    }
                    if (parts[0] == "TURBO") {
                        // The host decides when to try Turbo; always follow it if this phone can
                        if (Turbo.supported()) {
                            peerName?.let { turboFailedFor.remove(it) }
                            engineNote = null
                            startTurboAsClient(parts[1], parts[2])
                        } else {
                            peerId?.let { client.sendPayload(it, Payload.fromBytes("TURBONO|0|0".toByteArray(Charsets.UTF_8))) }
                        }
                        return
                    }
                    if (parts[0] == "TURBOOK") { turboAnswer = 1; return }
                    if (parts[0] == "TURBOCANCEL") { cancelTurboAsClient(); return }
                    if (parts[0] == "LAN") {
                        tryLanAsClient(parts[1], parts[2].toIntOrNull() ?: (Turbo.PORT + 1))
                        return
                    }
                    if (parts[0] == "SWAP") { onSwapRequest(); return }
                    if (parts[0] == "SWAPME") {
                        // the other phone can't host a hotspot: wait for it to reconnect, then WE host
                        peerName?.let { swappedWith.add(it); waitForPeer = it }
                        dlog("Other phone can't host a hotspot: it will reconnect and this phone hosts")
                        return
                    }
                    if (parts[0] == "P2PL") { joinNetworkRoute(parts[1], parts[2]); return }
                    if (parts[0] == "LOH") { lohIps = null; lohPort = 0; dlog("Hotspot offered: ${parts[1]}"); joinHostHotspot(parts[1], parts[2]); return }
                    if (parts[0] == "LOHIP") {
                        lohIps = parts[1].split(",").filter { it.isNotBlank() }
                        lohPort = parts[2].toIntOrNull() ?: 0
                        return
                    }
                    if (parts[0] == "LOHFAIL") { runCatching { lanServer?.close() }; return }
                    if (parts[0] == "BOOST") { joinDirectBoost(parts[1], parts[2]); return }
                    if (parts[0] == "BOOSTFAIL") { Turbo.cancelAccept(); return }
                    if (parts[0] == "ADDR") {
                        val ips = parts[1].split(",").filter { it.isNotBlank() }
                        connectDirect(ips, parts[2].toIntOrNull() ?: (Turbo.PORT + 1))
                        return
                    }
                    if (parts[0] == "LANFAIL") { runCatching { lanServer?.close() }; return }
                    if (parts[0] == "TURBONO") { turboAnswer = 2; return }
                    if (parts[0] == "BATCH") {
                        beginRunIfIdle(); runExpectedCount += parts[1].toIntOrNull() ?: 0; runExpectedBytes += parts[2].toLongOrNull() ?: 0L
                        lastProgressAt = System.currentTimeMillis()
                        expectedCount += parts[1].toIntOrNull() ?: 0
                        expectedBytes += parts[2].toLongOrNull() ?: 0L
                        notifyProgress()
                        return
                    }
                    val pid = parts[0].toLongOrNull() ?: return
                    val size = parts[1].toLongOrNull() ?: 0L
                    val name = safeName(parts[2])
                    meta[pid] = name to size
                    // same file sent again after a disconnect: reuse its old place in the list
                    val old = transfers.indexOfFirst {
                        it.incoming && it.name == name && it.size == size &&
                            (it.state == TState.FAILED || (it.state == TState.WAITING && it.done == 0L))
                    }
                    if (old >= 0 && transfers.none { it.id == pid }) transfers[old] = transfers[old].copy(id = pid, state = TState.WAITING, done = 0)
                    upsertIncoming(pid) { it.copy(name = name, size = if (size > 0) size else it.size) }
                    tryFinish(pid)
                }
                Payload.Type.FILE -> {
                    incomingFiles[p.id] = p
                    upsertIncoming(p.id) { it }
                    tryFinish(p.id)
                }
                else -> {}
            }
        }

        override fun onPayloadTransferUpdate(endpointId: String, u: PayloadTransferUpdate) {
            val ended = u.status != PayloadTransferUpdate.Status.IN_PROGRESS
            if (ended && onWire.remove(u.payloadId) != null) {
                // a slot is free: start the next file right away
                viewModelScope.launch { pump() }
            }
            val idx = transfers.indexOfFirst { it.id == u.payloadId }
            if (idx < 0) return
            val t = transfers[idx]
            if (t.state == TState.DONE || t.state == TState.SAVING || t.state == TState.CANCELLED) return
            val total = if (u.totalBytes > 0) u.totalBytes else t.size
            if (u.status == PayloadTransferUpdate.Status.IN_PROGRESS && u.bytesTransferred > t.done ||
                u.status == PayloadTransferUpdate.Status.SUCCESS
            ) lastProgressAt = System.currentTimeMillis()
            when (u.status) {
                PayloadTransferUpdate.Status.IN_PROGRESS -> {
                    val now = System.currentTimeMillis()
                    // redraw each file at most ~5 times a second: keeps the phone free to move data
                    if (t.state == TState.RUNNING && now - (lastUi[u.payloadId] ?: 0L) < 200) return
                    lastUi[u.payloadId] = now
                    val start = startedAt.getOrPut(u.payloadId) { now }
                    val secs = (now - start) / 1000.0
                    transfers[idx] = t.copy(
                        state = TState.RUNNING,
                        done = u.bytesTransferred,
                        size = total,
                        speed = if (secs > 0.3) u.bytesTransferred / secs else t.speed,
                    )
                }
                PayloadTransferUpdate.Status.SUCCESS -> {
                    if (t.incoming) {
                        transfers[idx] = t.copy(state = TState.SAVING, done = total, size = total)
                        completed.add(u.payloadId)
                        tryFinish(u.payloadId)
                    } else {
                        transfers[idx] = t.copy(state = TState.DONE, done = total, size = total)
                    }
                }
                PayloadTransferUpdate.Status.FAILURE, PayloadTransferUpdate.Status.CANCELED -> {
                    transfers[idx] = t.copy(state = TState.FAILED)

                }
            }
            notifyProgress()
        }
    }

    private fun upsertIncoming(pid: Long, change: (Transfer) -> Transfer) {
        val i = transfers.indexOfFirst { it.id == pid }
        if (i >= 0) transfers[i] = change(transfers[i])
        else {
            val m = meta[pid]
            val row = change(Transfer(pid, m?.first ?: "Incoming file", m?.second ?: 0L, incoming = true))
            transfers.add(row); addToRun(row)
        }
    }

    /** Runs once the file has fully arrived AND we know its name. */
    private fun tryFinish(pid: Long) {
        if (pid !in completed) return
        val p = incomingFiles[pid] ?: return
        val name = meta[pid]?.first ?: return
        completed.remove(pid)
        incomingFiles.remove(pid)
        val file = p.asFile() ?: return
        viewModelScope.launch {
            val saved = withContext(Dispatchers.IO) { runCatching { save(file, name) }.getOrNull() }
            val i = transfers.indexOfFirst { it.id == pid }
            if (i >= 0) transfers[i] = transfers[i].copy(state = if (saved != null) TState.DONE else TState.FAILED, saved = saved)
            notifyProgress()
        }
    }

    private fun safeName(n: String): String =
        n.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifEmpty { "file" }

    /** Moves the received file into Downloads/Asan Share. */
    @Suppress("DEPRECATION")
    private fun save(f: Payload.File, name: String): Uri? {
        val r = ctx.contentResolver
        if (canUseOwnFolder()) {
            // Phone storage / Asan Share / Photos, Videos, Music, Apps, Files
            val dir = File(rootFolder(), subFolder(name)).apply { mkdirs() }
            var out = File(dir, name)
            var n = 1
            val base = name.substringBeforeLast('.')
            val ext = name.substringAfterLast('.', "")
            while (out.exists()) out = File(dir, if (ext.isEmpty()) "$base (${n++})" else "$base (${n++}).$ext")
            if (Build.VERSION.SDK_INT >= 29) {
                val src = f.asUri() ?: return null
                // Fast path: just MOVE the file (instant, even for big videos) instead of copying it
                @Suppress("DEPRECATION")
                val srcPath = runCatching {
                    r.query(src, arrayOf(MediaStore.MediaColumns.DATA), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
                }.getOrNull()
                val moved = srcPath != null && runCatching { File(srcPath).renameTo(out) }.getOrDefault(false)
                if (!moved) {
                    r.openInputStream(src)?.use { i -> FileOutputStream(out).use { o -> i.copyTo(o, 1 shl 20) } } ?: return null
                }
                runCatching { r.delete(src, null, null) }
            } else {
                val src = f.asJavaFile() ?: return null
                if (!src.renameTo(out)) {
                    FileInputStream(src).use { i -> FileOutputStream(out).use { o -> i.copyTo(o, 1 shl 20) } }
                    src.delete()
                }
            }
            MediaScannerConnection.scanFile(ctx, arrayOf(out.path), null, null) // show in Gallery / Music
            return FileProvider.getUriForFile(ctx, ctx.packageName + ".files", out)
        }
        if (Build.VERSION.SDK_INT >= 29) {
            val src = f.asUri() ?: return null
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + SAVE_FOLDER)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val dst = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return null
            r.openInputStream(src)?.use { input ->
                r.openOutputStream(dst)?.use { out -> input.copyTo(out, 1 shl 20) }
            }
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            r.update(dst, values, null, null)
            runCatching { r.delete(src, null, null) }
            return dst
        } else {
            val src = f.asJavaFile() ?: return null
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), SAVE_FOLDER)
            dir.mkdirs()
            var out = File(dir, name)
            var n = 1
            while (out.exists()) out = File(dir, "(${n++}) $name")
            if (!src.renameTo(out)) {
                FileInputStream(src).use { i -> FileOutputStream(out).use { o -> i.copyTo(o, 1 shl 20) } }
                src.delete()
            }
            return FileProvider.getUriForFile(ctx, ctx.packageName + ".files", out)
        }
    }
}
