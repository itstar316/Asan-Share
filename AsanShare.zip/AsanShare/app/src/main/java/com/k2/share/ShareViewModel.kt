package com.k2.share

import android.app.Application
import android.bluetooth.BluetoothManager
import android.location.LocationManager
import android.net.wifi.WifiManager
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.media.ThumbnailUtils
import androidx.core.content.ContextCompat
import android.os.ParcelFileDescriptor
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import androidx.core.location.LocationManagerCompat
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.common.api.ApiException
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.BandwidthInfo
import com.google.android.gms.nearby.connection.ConnectionOptions
import com.google.android.gms.nearby.connection.ConnectionType
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsStatusCodes
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.Locale

enum class Screen { HOME, CONNECTED, RECEIVED, INVITE }
enum class Kind { APP, PHOTO, VIDEO, MUSIC, FILE }

/** Something on the phone that can be picked for sending. */
data class MediaItem(
    val key: String,
    val uri: Uri,
    val name: String,
    val size: Long,
    val kind: Kind,
    val extra: String = "",
    val pkg: String? = null,
    val path: String? = null,
)
enum class TState { WAITING, RUNNING, SAVING, DONE, FAILED }

data class PickedFile(val uri: Uri, val name: String, val size: Long)
data class Device(val id: String, val name: String)
data class Transfer(
    val id: Long,
    val name: String,
    val size: Long,
    val incoming: Boolean,
    val done: Long = 0,
    val state: TState = TState.WAITING,
    val speed: Double = 0.0,
    val saved: Uri? = null,
    /** Source file, for outgoing transfers (used to resume after a dropped connection). */
    val source: PickedFile? = null,
)

private const val SERVICE_ID = "com.javed.asanshare.TRANSFER"
// Point-to-point = one sender, one receiver, highest bandwidth (direct Wi-Fi link)
private val STRATEGY = Strategy.P2P_POINT_TO_POINT
const val SAVE_FOLDER = "Asan Share"

val APK_EXTS = setOf("apk", "xapk", "apks", "apkm")
val DOC_EXTS = setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "rtf", "odt", "ods", "odp", "csv", "epub", "vcf")
val ARCHIVE_EXTS = setOf("zip", "rar", "7z", "tar", "gz")
val DESIGN_EXTS = setOf("dst", "emb", "pes", "jef", "exp", "dsb", "vp3", "hus", "xxx", "cdr", "ai", "psd", "eps", "svg", "dxf", "plt")
val FILE_EXTS = APK_EXTS + DOC_EXTS + ARCHIVE_EXTS + DESIGN_EXTS

fun fmt(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var v = bytes / 1024.0
    var i = 0
    while (v >= 1024 && i < units.size - 1) { v /= 1024; i++ }
    return String.format(Locale.US, if (v < 10) "%.1f %s" else "%.0f %s", v, units[i])
}

class ShareViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Context = app.applicationContext
    private val client = Nearby.getConnectionsClient(ctx)
    private val prefs = ctx.getSharedPreferences("k2share", Context.MODE_PRIVATE)

    var myName by mutableStateOf(prefs.getString("name", null) ?: defaultName())
        private set

    init { Lang.urdu = prefs.getBoolean("urdu", false) }

    fun setUrdu(on: Boolean) { Lang.urdu = on; prefs.edit().putBoolean("urdu", on).apply() }

    /** True when received files can go to their own "Asan Share" folder at the top of phone storage. */
    var ownFolder by mutableStateOf(canUseOwnFolder())
        private set

    fun refreshFolderAccess() {
        val before = ownFolder
        ownFolder = canUseOwnFolder()
        // just got "All files access": load the full Files list again
        if (!before && ownFolder) loadedWithMedia?.let { loadLibrary(it, force = true) }
    }

    private fun canUseOwnFolder(): Boolean = when {
        Build.VERSION.SDK_INT >= 30 -> Environment.isExternalStorageManager()
        Build.VERSION.SDK_INT == 29 -> runCatching { Environment.isExternalStorageLegacy() }.getOrDefault(false) &&
            ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        else -> ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    }

    @Suppress("DEPRECATION")
    private fun rootFolder() = File(Environment.getExternalStorageDirectory(), SAVE_FOLDER)

    private fun subFolder(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return when (ext) {
            "jpg", "jpeg", "png", "gif", "webp", "heic", "bmp" -> "Photos"
            "mp4", "mkv", "mov", "avi", "3gp", "webm" -> "Videos"
            "mp3", "m4a", "wav", "aac", "ogg", "opus", "flac", "amr" -> "Music"
            "apk", "xapk", "apks" -> "Apps"
            else -> "Files"
        }
    }
    var screen by mutableStateOf(Screen.HOME)
    var status by mutableStateOf("")
    var peerName by mutableStateOf<String?>(null)
    var connected by mutableStateOf(false)
    var request by mutableStateOf<Device?>(null)
    /** 0 = unknown, 1 = Bluetooth (slow), 2 = Wi-Fi, 3 = fast direct Wi-Fi */
    var link by mutableStateOf(0)

    /** Things the user must switch on: "Bluetooth", "Wi-Fi", "Location" */
    var problems by mutableStateOf(listOf<String>())
    var failed by mutableStateOf(false)
    /** Phone we asked to connect to and are waiting for. */
    var connecting by mutableStateOf<Device?>(null)
    private var paused = false

    // ---- Auto-reconnect & resume after an accidental disconnect ----
    /** Name of the phone we lost by accident, and until when we try to get it back. */
    var reconnectName by mutableStateOf<String?>(null)
    private var reconnectUntil = 0L
    private var byeReceived = false
    /** Unfinished files that will be sent again after reconnecting. */
    var resumeCount by mutableStateOf(0)
    private val myToken = (Math.random() * Long.MAX_VALUE).toLong()
    private var peerToken: Long? = null
    private var lostPeerToken: Long? = null
    private var iRequested = false
    private var started = false

    // Files waiting to be sent. Sent a couple at a time so even thousands of files work.
    private val queue = ArrayDeque<Pair<Long, PickedFile>>()
    private var inFlight = 0
    private var nextPlaceholder = -1L
    /** Whole batch size, so both phones can show "12 of 120 files". */
    var expectedCount by mutableStateOf(0)
    var expectedBytes by mutableStateOf(0L)
    private var lastNotified = -1

    private var waitingForFast = false
    private var fastTimer: Job? = null

    val picked = mutableStateListOf<PickedFile>()
    private val selectedKeys = mutableStateMapOf<String, Boolean>()

    // Phone library (like Zapya's tabs)
    var apps by mutableStateOf(listOf<MediaItem>())
    var photos by mutableStateOf(listOf<MediaItem>())
    var videos by mutableStateOf(listOf<MediaItem>())
    var music by mutableStateOf(listOf<MediaItem>())
    var docs by mutableStateOf(listOf<MediaItem>())
    var loading by mutableStateOf(false)
    var received by mutableStateOf(listOf<MediaItem>())
    private var loadedWithMedia: Boolean? = null
    val devices = mutableStateListOf<Device>()
    val transfers = mutableStateListOf<Transfer>()

    private var peerId: String? = null
    private val names = HashMap<String, String>()          // endpointId -> name
    private val meta = HashMap<Long, Pair<String, Long>>()  // payloadId -> (file name, size)
    private val incomingFiles = HashMap<Long, Payload>()
    private val completed = HashSet<Long>()
    private val startedAt = HashMap<Long, Long>()

    private fun defaultName(): String {
        val n = runCatching { Settings.Global.getString(ctx.contentResolver, "device_name") }.getOrNull()
        return if (!n.isNullOrBlank()) n
        else "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}"
    }

    fun rename(n: String) {
        val t = n.trim()
        if (t.isNotEmpty()) { myName = t; prefs.edit().putString("name", t).apply() }
    }

    // ---------- Files ----------
    fun addFiles(uris: List<Uri>) {
        for (u in uris) {
            if (selectedKeys.containsKey(u.toString())) continue
            var name = "file"
            var size = 0L
            runCatching {
                ctx.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        c.getString(0)?.let { name = it }
                        if (!c.isNull(1)) size = c.getLong(1)
                    }
                }
            }
            picked.add(PickedFile(u, name, size))
            selectedKeys[u.toString()] = true
        }
    }

    fun removeFile(f: PickedFile) { picked.remove(f); selectedKeys.remove(f.uri.toString()) }

    fun isSelected(item: MediaItem) = selectedKeys.containsKey(item.uri.toString())

    fun toggle(item: MediaItem) {
        val k = item.uri.toString()
        if (selectedKeys.containsKey(k)) {
            selectedKeys.remove(k)
            picked.removeAll { it.uri.toString() == k }
        } else {
            selectedKeys[k] = true
            picked.add(PickedFile(item.uri, item.name, item.size))
        }
    }

    fun selectAll(items: List<MediaItem>, select: Boolean) {
        for (i in items) if (isSelected(i) != select) toggle(i)
    }

    fun clearSelection() { picked.clear(); selectedKeys.clear() }

    fun openInvite() { stopRadar(); screen = Screen.INVITE }

    /** Send whatever is ticked to the connected phone. */
    fun sendSelected() {
        if (!connected || picked.isEmpty()) return
        sendAll()
    }

    // ---------- Phone library ----------
    fun loadLibrary(hasMedia: Boolean, force: Boolean = false) {
        if (loading || (!force && loadedWithMedia == hasMedia)) return
        loading = true
        viewModelScope.launch {
            apps = withContext(Dispatchers.IO) { runCatching { queryApps() }.getOrDefault(emptyList()) }
            if (hasMedia) {
                photos = withContext(Dispatchers.IO) { runCatching { queryMedia(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, Kind.PHOTO) }.getOrDefault(emptyList()) }
                videos = withContext(Dispatchers.IO) { runCatching { queryMedia(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, Kind.VIDEO) }.getOrDefault(emptyList()) }
                music = withContext(Dispatchers.IO) { runCatching { queryMedia(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, Kind.MUSIC) }.getOrDefault(emptyList()) }
            }
            // Files (APK, PDF…) can be visible even without photo access, e.g. with "All files access"
            docs = withContext(Dispatchers.IO) { runCatching { queryDocs() }.getOrDefault(emptyList()) }
            loadedWithMedia = hasMedia
            loading = false
        }
    }

    @Suppress("DEPRECATION")
    private fun queryApps(): List<MediaItem> {
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(launcher, 0)
            .map { it.activityInfo.applicationInfo }
            .distinctBy { it.packageName }
            .filter {
                it.packageName == ctx.packageName ||
                    (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 ||
                    (it.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
            }
            .mapNotNull { ai ->
                val f = File(ai.sourceDir ?: return@mapNotNull null)
                if (!f.canRead()) return@mapNotNull null
                val label = pm.getApplicationLabel(ai).toString()
                val uri = Uri.fromFile(f)
                MediaItem(uri.toString(), uri, "$label.apk", f.length(), Kind.APP, pkg = ai.packageName)
            }
            .sortedBy { it.name.lowercase() }
        // Asan Share itself first, so it's easy to give the app to friends
        return list.sortedByDescending { it.pkg == ctx.packageName }
    }

    private fun dur(ms: Long): String {
        if (ms <= 0) return ""
        val s = ms / 1000
        return if (s >= 3600) String.format(Locale.US, "%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60)
        else String.format(Locale.US, "%d:%02d", s / 60, s % 60)
    }

    private fun queryMedia(base: Uri, kind: Kind): List<MediaItem> {
        val out = ArrayList<MediaItem>()
        val proj = mutableListOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE)
        if (kind != Kind.PHOTO) proj += "duration"
        if (kind == Kind.MUSIC) proj += "artist"
        val sel = if (kind == Kind.MUSIC) "${MediaStore.Audio.AudioColumns.IS_MUSIC} != 0" else null
        ctx.contentResolver.query(base, proj.toTypedArray(), sel, null, "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val iName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val iSize = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            val iDur = c.getColumnIndex("duration")
            val iArtist = c.getColumnIndex("artist")
            while (c.moveToNext()) {
                val uri = ContentUris.withAppendedId(base, c.getLong(iId))
                val name = c.getString(iName) ?: "file"
                val d = if (iDur >= 0) dur(c.getLong(iDur)) else ""
                val extra = when (kind) {
                    Kind.VIDEO -> d
                    Kind.MUSIC -> listOfNotNull(
                        (if (iArtist >= 0) c.getString(iArtist) else null)?.takeIf { it.isNotBlank() && it != "<unknown>" }, d.ifEmpty { null },
                    ).joinToString("   ")
                    else -> ""
                }
                out += MediaItem(uri.toString(), uri, name, c.getLong(iSize), kind, extra)
            }
        }
        return out
    }

    /** Every useful non-media file on the phone: APKs, PDFs, Office files, ZIPs, embroidery/design files… */
    @Suppress("DEPRECATION")
    private fun queryDocs(): List<MediaItem> {
        val base = MediaStore.Files.getContentUri("external")
        val sel = FILE_EXTS.joinToString(" OR ") { "${MediaStore.MediaColumns.DISPLAY_NAME} LIKE ?" }
        val args = FILE_EXTS.map { "%.$it" }.toTypedArray()
        val out = ArrayList<MediaItem>()
        ctx.contentResolver.query(
            base,
            arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.DATA),
            "(${sel}) AND ${MediaStore.MediaColumns.SIZE} > 0", args, "${MediaStore.MediaColumns.DATE_MODIFIED} DESC",
        )?.use { c ->
            while (c.moveToNext() && out.size < 8000) {
                val name = c.getString(1) ?: continue
                val path = c.getString(3)
                // skip hidden files and app-private folders
                if (name.startsWith(".") || (path != null && (path.contains("/Android/data/") || path.contains("/Android/obb/") || path.contains("/."))))
                    continue
                val uri = ContentUris.withAppendedId(base, c.getLong(0))
                out += MediaItem(uri.toString(), uri, name, c.getLong(2), Kind.FILE, path = path)
            }
        }
        return out
    }

    fun openReceived() { stopRadar(); screen = Screen.RECEIVED; loadReceived() }

    fun loadReceived() {
        viewModelScope.launch {
            received = withContext(Dispatchers.IO) { runCatching { queryReceived() }.getOrDefault(emptyList()) }
        }
    }

    private fun kindOf(name: String, mime: String?): Kind {
        val m = mime ?: ""
        val ext = name.substringAfterLast('.', "").lowercase()
        return when {
            m.startsWith("image/") || ext in setOf("jpg", "jpeg", "png", "gif", "webp", "heic") -> Kind.PHOTO
            m.startsWith("video/") || ext in setOf("mp4", "mkv", "mov", "3gp", "webm", "avi") -> Kind.VIDEO
            else -> Kind.FILE
        }
    }

    private fun queryReceived(): List<MediaItem> {
        val out = ArrayList<MediaItem>()
        if (ownFolder) {
            rootFolder().walkTopDown().filter { it.isFile && !it.name.startsWith(".") }.forEach { f ->
                val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
                out += MediaItem("f:${f.path}", uri, f.name, f.length(), kindOf(f.name, null), path = f.path)
            }
        }
        if (Build.VERSION.SDK_INT >= 29) {
            val base = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            ctx.contentResolver.query(
                base,
                arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.MIME_TYPE),
                "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?",
                arrayOf(Environment.DIRECTORY_DOWNLOADS + "/" + SAVE_FOLDER + "%"),
                "${MediaStore.MediaColumns.DATE_ADDED} DESC",
            )?.use { c ->
                while (c.moveToNext()) {
                    val uri = ContentUris.withAppendedId(base, c.getLong(0))
                    val name = c.getString(1) ?: "file"
                    out += MediaItem("r:$uri", uri, name, c.getLong(2), kindOf(name, c.getString(3)))
                }
            }
        } else if (!ownFolder) {
            @Suppress("DEPRECATION")
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), SAVE_FOLDER)
            dir.listFiles()?.filter { it.isFile }?.sortedByDescending { it.lastModified() }?.forEach { f ->
                val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
                out += MediaItem("r:${f.path}", uri, f.name, f.length(), kindOf(f.name, null), path = f.path)
            }
        }
        return out.distinctBy { it.name + it.size }.sortedByDescending { it.path?.let { p -> File(p).lastModified() } ?: 0L }
    }

    // ---------- Finding & connecting ----------
    /**
     * Zapya-style: while the app is open on the home screen, this phone is visible to others
     * AND looking for others at the same time. No "Receive" button needed.
     */
    fun startRadar() {
        if (!playServicesOk()) return
        status = ""; failed = false; started = true
        radarStartedAt = System.currentTimeMillis()
        client.stopAdvertising()
        client.stopDiscovery()
        if (!connected && connecting == null && request == null) client.stopAllEndpoints() // clear leftovers of the last session
        devices.clear()
        client.startAdvertising(myName, SERVICE_ID, connCb, AdvertisingOptions.Builder().setStrategy(STRATEGY).setConnectionType(ConnectionType.DISRUPTIVE).build())
            .addOnFailureListener { onStartFailed(it, "become visible") }
        startDiscoveryOnly()
    }

    private fun startDiscoveryOnly() {
        client.startDiscovery(SERVICE_ID, discoveryCb, DiscoveryOptions.Builder().setStrategy(STRATEGY).build())
            .addOnFailureListener { onStartFailed(it, "search for phones") }
    }

    fun stopRadar() {
        client.stopDiscovery()
        client.stopAdvertising()
        started = false
        connecting = null
    }

    /** App went to the background: stop the radar to save battery (but never drop a live connection). */
    fun onAppBackground() { paused = true; if (!connected && connecting == null) stopRadar() }
    fun onAppForeground() { paused = false }

    /** Called every second or so by the home screen. Starts (or restarts) once everything is switched on. */
    fun keepAlive() {
        if (connected || screen != Screen.HOME || paused || connecting != null || request != null) return
        val wasBlocked = problems.isNotEmpty()
        refreshRadios()
        if (problems.isNotEmpty()) return
        val now = System.currentTimeMillis()
        when {
            !started || (failed && wasBlocked) -> startRadar()
            // Nobody found for a while: restart the radar (Bluetooth scans sometimes go quiet after a session)
            !failed && devices.isEmpty() && now - radarStartedAt > 15_000 -> startRadar()
            // Even with phones listed, refresh now and then so phones that left disappear and new ones show up
            !failed && now - radarStartedAt > 90_000 -> startRadar()
        }
    }

    private var radarStartedAt = 0L

    fun retry() = startRadar()

    private fun refreshRadios() {
        val p = mutableListOf<String>()
        val bt = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
        if (bt != null && !runCatching { bt.isEnabled }.getOrDefault(true)) p += "Bluetooth"
        val wifi = ctx.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        if (wifi != null && !wifi.isWifiEnabled) p += "Wi-Fi"
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        if (lm != null && !LocationManagerCompat.isLocationEnabled(lm)) p += "Location"
        if (p != problems) problems = p
    }

    private fun playServicesOk(): Boolean {
        val ok = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(ctx) == ConnectionResult.SUCCESS
        if (!ok) {
            failed = true; started = true
            status = tr("This phone needs Google Play services (or an update of it) to use Asan Share.", "آسان شیئر کے لیے اس فون میں Google Play services (یا اس کی اپڈیٹ) ضروری ہے۔")
        }
        return ok
    }

    private fun onStartFailed(e: Exception, what: String) {
        val code = (e as? ApiException)?.statusCode ?: -1
        // Already running is fine
        if (code == ConnectionsStatusCodes.STATUS_ALREADY_DISCOVERING || code == ConnectionsStatusCodes.STATUS_ALREADY_ADVERTISING) return
        failed = true
        status = when (code) {
            in 8030..8040 -> tr("Couldn't $what: a permission is missing. Open Settings, Apps, Asan Share, Permissions and allow Location and Nearby devices.", "ایک اجازت نہیں ملی۔ سیٹنگز > ایپس > آسان شیئر > اجازتیں میں جا کر لوکیشن اور قریبی ڈیوائسز کی اجازت دیں۔")
            ConnectionsStatusCodes.STATUS_BLUETOOTH_ERROR -> tr("Couldn't $what: Bluetooth error. Turn Bluetooth off and on, then tap Try again.", "بلوٹوتھ میں مسئلہ۔ بلوٹوتھ بند کر کے دوبارہ آن کریں، پھر دوبارہ کوشش کریں۔")
            else -> tr("Couldn't $what (error $code). Turn Wi-Fi and Bluetooth off and on, then tap Try again.", "شروع نہیں ہو سکا (خرابی $code)۔ وائی فائی اور بلوٹوتھ بند کر کے دوبارہ آن کریں، پھر دوبارہ کوشش کریں۔")
        }
    }

    fun connect(d: Device) {
        if (connecting != null || connected) return
        connecting = d
        iRequested = true
        names[d.id] = d.name
        client.stopDiscovery() // discovery slows down the link, stop it while connecting
        client.requestConnection(myName, d.id, connCb, ConnectionOptions.Builder().setConnectionType(ConnectionType.DISRUPTIVE).build())
            .addOnFailureListener {
                if (connecting?.id != d.id) return@addOnFailureListener
                connecting = null
                iRequested = false
                startRadar()
                status = tr("Couldn't reach ${d.name}. Make sure Asan Share is open on it, then try again.", "${d.name} تک رسائی نہیں ہوئی۔ اس پر آسان شیئر کھلا رکھیں اور دوبارہ کوشش کریں۔")
            }
        // If the other phone never answers, don't stay on "Connecting…" forever
        viewModelScope.launch {
            delay(40_000)
            if (connecting?.id == d.id && !connected) {
                cancelConnect()
                status = tr("${d.name} didn't answer. Try again.", "${d.name} نے جواب نہیں دیا۔ دوبارہ کوشش کریں۔")
            }
        }
    }

    fun cancelConnect() {
        val d = connecting ?: return
        client.disconnectFromEndpoint(d.id)
        connecting = null
        iRequested = false
        startRadar()
    }

    fun accept() {
        request?.let { names[it.id] = it.name; client.acceptConnection(it.id, payloadCb) }
        request = null
    }

    fun decline() {
        request?.let { client.rejectConnection(it.id) }
        request = null
    }

    /** User chose to leave (Disconnect / Close / Back to home). */
    fun goHome() {
        reconnectName = null
        resumeCount = 0
        val pid = peerId
        if (pid != null && connected) {
            // let the other phone know this was on purpose, so it doesn't try to reconnect
            client.sendPayload(pid, Payload.fromBytes("BYE|0|0".toByteArray(Charsets.UTF_8)))
            viewModelScope.launch { delay(900); if (!connected) client.stopAllEndpoints() }
        }
        resetSession()
        clearSelection()
        screen = Screen.HOME
    }

    fun cancelReconnect() {
        reconnectName = null
        resumeCount = 0
        clearSelection()
    }

    private fun resetSession() {
        client.stopDiscovery()
        client.stopAdvertising()
        if (peerId == null) client.stopAllEndpoints()
        transfers.clear(); devices.clear()
        meta.clear(); incomingFiles.clear(); completed.clear(); startedAt.clear(); names.clear()
        peerId = null; peerName = null; connected = false; request = null; status = ""
        link = 0; waitingForFast = false; fastTimer?.cancel()
        started = false; failed = false; connecting = null; iRequested = false
        queue.clear(); inFlight = 0; expectedCount = 0; expectedBytes = 0L; lastNotified = -1
        byeReceived = false
        watchdog?.cancel()
        TransferService.stop(ctx)
    }

    private fun stopAll() {
        client.stopDiscovery()
        client.stopAdvertising()
        client.stopAllEndpoints()
    }

    override fun onCleared() { stopAll(); TransferService.stop(ctx) }

    private val discoveryCb = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) {
            val d = Device(id, info.endpointName)
            if (devices.none { it.id == id }) devices.add(d)
            // The phone we lost came back: reconnect by ourselves.
            // Only one side asks (the one with unfinished files, or the "smaller" name) to avoid a clash.
            val lost = reconnectName
            if (lost != null && System.currentTimeMillis() < reconnectUntil && d.name == lost &&
                (picked.isNotEmpty() || lostPeerToken?.let { myToken < it } ?: (myName < lost))
            ) connect(d)
        }
        override fun onEndpointLost(id: String) { devices.removeAll { it.id == id } }
    }

    private val connCb = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            if (info.isIncomingConnection) {
                if (peerId != null || connecting != null) { client.rejectConnection(id); return }
                if (reconnectName != null && info.endpointName == reconnectName && System.currentTimeMillis() < reconnectUntil) {
                    names[id] = info.endpointName
                    client.acceptConnection(id, payloadCb) // same phone as before: no need to ask again
                    return
                }
                request = Device(id, info.endpointName) // receiver confirms first
            } else {
                client.acceptConnection(id, payloadCb)
            }
        }

        override fun onConnectionResult(id: String, res: ConnectionResolution) {
            if (res.status.statusCode == ConnectionsStatusCodes.STATUS_OK) {
                peerId = id
                peerName = names[id] ?: "Nearby phone"
                connected = true
                TransferService.start(ctx)
                startWatchdog()
                peerToken = null
                client.sendPayload(id, Payload.fromBytes("HELLO|$myToken|0".toByteArray(Charsets.UTF_8)))
                status = ""
                client.stopDiscovery()
                client.stopAdvertising()
                val autoSend = picked.isNotEmpty()
                reconnectName = null
                resumeCount = 0
                byeReceived = false
                connecting = null
                iRequested = false
                screen = Screen.CONNECTED
                // Files already chosen (e.g. shared from Gallery): send as soon as the fast link is up
                if (autoSend) {
                    // Connections start on Bluetooth. Wait (max 6 s) for the switch to direct Wi-Fi before sending.
                    waitingForFast = true
                    fastTimer?.cancel()
                    fastTimer = viewModelScope.launch {
                        delay(6000)
                        if (waitingForFast) { waitingForFast = false; sendAll() }
                    }
                }
            } else {
                val who = connecting?.name
                connecting = null
                iRequested = false
                if (screen == Screen.HOME) startRadar()
                if (who != null) status = tr("$who didn't accept. Try again.", "$who نے قبول نہیں کیا۔ دوبارہ کوشش کریں۔")
            }
        }

        override fun onBandwidthChanged(id: String, info: BandwidthInfo) {
            if (id != peerId) return
            link = when (info.quality) {
                BandwidthInfo.Quality.HIGH -> 3
                BandwidthInfo.Quality.MEDIUM -> 2
                BandwidthInfo.Quality.LOW -> 1
                else -> 0
            }
            if (waitingForFast && link == 3) {
                waitingForFast = false
                fastTimer?.cancel()
                sendAll()
            }
        }

        override fun onDisconnected(id: String) {
            if (id != peerId) return
            lostConnection()
        }
    }

    /** Connection dropped (or got stuck): keep unfinished files and reconnect automatically. */
    private fun lostConnection() {
            // Files we were sending that didn't finish: keep them to send again
            val unfinished = transfers.filter { !it.incoming && it.state != TState.DONE }.mapNotNull { it.source }
            peerId = null
            connected = false
            for (i in transfers.indices) {
                val t = transfers[i]
                if (t.state == TState.RUNNING || t.state == TState.WAITING) transfers[i] = t.copy(state = TState.FAILED)
            }
            queue.clear(); inFlight = 0
            TransferService.stop(ctx)
            if (byeReceived) {
                val msg = "${peerName ?: tr("The other phone", "دوسرے فون")} " + tr("disconnected", "نے رابطہ ختم کر دیا")
                resetSession()
                clearSelection()
                reconnectName = null
                resumeCount = 0
                screen = Screen.HOME
                status = msg
                return
            }
            // Accidental drop: go back to the radar and reconnect automatically
            val lost = peerName
            lostPeerToken = peerToken
            val keep = unfinished
            resetSession()
            if (lost != null) {
                reconnectName = lost
                reconnectUntil = System.currentTimeMillis() + 5 * 60_000L
            }
            for (f in keep) if (!selectedKeys.containsKey(f.uri.toString())) {
                picked.add(f); selectedKeys[f.uri.toString()] = true
            }
            resumeCount = keep.size
            screen = Screen.HOME
    }

    // ---------- Stuck-transfer watchdog ----------
    private var lastProgressAt = 0L
    private var watchdog: Job? = null

    private fun startWatchdog() {
        lastProgressAt = System.currentTimeMillis()
        watchdog?.cancel()
        watchdog = viewModelScope.launch {
            while (connected) {
                delay(3000)
                val busy = transfers.any { it.state == TState.WAITING || it.state == TState.RUNNING }
                if (!busy) { lastProgressAt = System.currentTimeMillis(); continue }
                // Nothing moved for 20 seconds: the link is stuck. Reconnect and continue by itself.
                if (System.currentTimeMillis() - lastProgressAt > 20_000) {
                    val pid = peerId ?: break
                    client.disconnectFromEndpoint(pid)
                    lostConnection()
                    break
                }
            }
        }
    }

    // ---------- Sending ----------
    fun sendMore(uris: List<Uri>) {
        clearSelection()
        addFiles(uris)
        sendAll()
    }

    private fun sendAll() {
        val id = peerId ?: return
        val batch = picked.toList()
        if (batch.isEmpty()) return
        lastProgressAt = System.currentTimeMillis()
        val bytes = batch.sumOf { it.size }
        expectedCount += batch.size
        expectedBytes += bytes
        // tell the receiver how much is coming
        client.sendPayload(id, Payload.fromBytes("BATCH|${batch.size}|$bytes".toByteArray(Charsets.UTF_8)))
        clearSelection()
        for (f in batch) {
            val ph = nextPlaceholder--
            queue.addLast(ph to f)
            transfers.add(Transfer(ph, f.name, f.size, incoming = false, source = f))
        }
        pump()
    }

    /** Keeps 2 files on the wire at a time: full speed, little memory, works for any number of files. */
    private fun pump() {
        val id = peerId ?: return
        while (inFlight < 2 && queue.isNotEmpty()) {
            val (ph, f) = queue.removeFirst()
            val idx = transfers.indexOfFirst { it.id == ph }
            val pfd = runCatching {
                if (f.uri.scheme == "file") ParcelFileDescriptor.open(File(f.uri.path!!), ParcelFileDescriptor.MODE_READ_ONLY)
                else ctx.contentResolver.openFileDescriptor(f.uri, "r")
            }.getOrNull()
            if (pfd == null) {
                if (idx >= 0) transfers[idx] = transfers[idx].copy(state = TState.FAILED)
                continue
            }
            val p = Payload.fromFile(pfd)
            // small header so the receiver knows the real file name
            client.sendPayload(id, Payload.fromBytes("${p.id}|${f.size}|${f.name}".toByteArray(Charsets.UTF_8)))
            client.sendPayload(id, p)
            inFlight++
            if (idx >= 0) transfers[idx] = transfers[idx].copy(id = p.id)
        }
        notifyProgress()
    }

    private fun notifyProgress() {
        val total = maxOf(expectedBytes, transfers.sumOf { it.size })
        val done = transfers.sumOf { it.done }
        val count = maxOf(expectedCount, transfers.size)
        val finished = transfers.count { it.state == TState.DONE || it.state == TState.FAILED }
        val pct = if (total > 0) ((done * 100) / total).toInt() else 0
        val key = pct * 100000 + finished
        if (key == lastNotified) return
        lastNotified = key
        val text = if (count > 0 && finished >= count) tr("Done: $count files", "مکمل: $count فائلیں") else tr("$finished of $count files, ${fmt(done)} of ${fmt(total)}", "$count میں سے $finished فائلیں، ${fmt(total)} میں سے ${fmt(done)}")
        TransferService.update(ctx, text, if (finished >= count && count > 0) 100 else pct)
    }

    // ---------- Receiving ----------
    private val payloadCb = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, p: Payload) {
            when (p.type) {
                Payload.Type.BYTES -> {
                    val bytes = p.asBytes() ?: return
                    val parts = String(bytes, Charsets.UTF_8).split("|", limit = 3)
                    if (parts.size < 3) return
                    if (parts[0] == "BYE") { byeReceived = true; return }
                    if (parts[0] == "HELLO") { peerToken = parts[1].toLongOrNull(); return }
                    if (parts[0] == "BATCH") {
                        lastProgressAt = System.currentTimeMillis()
                        expectedCount += parts[1].toIntOrNull() ?: 0
                        expectedBytes += parts[2].toLongOrNull() ?: 0L
                        notifyProgress()
                        return
                    }
                    val pid = parts[0].toLongOrNull() ?: return
                    val size = parts[1].toLongOrNull() ?: 0L
                    val name = safeName(parts[2])
                    meta[pid] = name to size
                    upsertIncoming(pid) { it.copy(name = name, size = if (size > 0) size else it.size) }
                    tryFinish(pid)
                }
                Payload.Type.FILE -> {
                    incomingFiles[p.id] = p
                    upsertIncoming(p.id) { it }
                    tryFinish(p.id)
                }
                else -> {}
            }
        }

        override fun onPayloadTransferUpdate(endpointId: String, u: PayloadTransferUpdate) {
            val idx = transfers.indexOfFirst { it.id == u.payloadId }
            if (idx < 0) return
            val t = transfers[idx]
            if (t.state == TState.DONE || t.state == TState.SAVING) return
            val total = if (u.totalBytes > 0) u.totalBytes else t.size
            if (u.status == PayloadTransferUpdate.Status.IN_PROGRESS && u.bytesTransferred > t.done ||
                u.status == PayloadTransferUpdate.Status.SUCCESS
            ) lastProgressAt = System.currentTimeMillis()
            when (u.status) {
                PayloadTransferUpdate.Status.IN_PROGRESS -> {
                    val now = System.currentTimeMillis()
                    val start = startedAt.getOrPut(u.payloadId) { now }
                    val secs = (now - start) / 1000.0
                    transfers[idx] = t.copy(
                        state = TState.RUNNING,
                        done = u.bytesTransferred,
                        size = total,
                        speed = if (secs > 0.3) u.bytesTransferred / secs else t.speed,
                    )
                }
                PayloadTransferUpdate.Status.SUCCESS -> {
                    if (t.incoming) {
                        transfers[idx] = t.copy(state = TState.SAVING, done = total, size = total)
                        completed.add(u.payloadId)
                        tryFinish(u.payloadId)
                    } else {
                        transfers[idx] = t.copy(state = TState.DONE, done = total, size = total)
                        inFlight = (inFlight - 1).coerceAtLeast(0)
                        pump()
                    }
                }
                PayloadTransferUpdate.Status.FAILURE, PayloadTransferUpdate.Status.CANCELED -> {
                    transfers[idx] = t.copy(state = TState.FAILED)
                    if (!t.incoming) { inFlight = (inFlight - 1).coerceAtLeast(0); pump() }
                }
            }
            notifyProgress()
        }
    }

    private fun upsertIncoming(pid: Long, change: (Transfer) -> Transfer) {
        val i = transfers.indexOfFirst { it.id == pid }
        if (i >= 0) transfers[i] = change(transfers[i])
        else {
            val m = meta[pid]
            transfers.add(change(Transfer(pid, m?.first ?: "Incoming file", m?.second ?: 0L, incoming = true)))
        }
    }

    /** Runs once the file has fully arrived AND we know its name. */
    private fun tryFinish(pid: Long) {
        if (pid !in completed) return
        val p = incomingFiles[pid] ?: return
        val name = meta[pid]?.first ?: return
        completed.remove(pid)
        incomingFiles.remove(pid)
        val file = p.asFile() ?: return
        viewModelScope.launch {
            val saved = withContext(Dispatchers.IO) { runCatching { save(file, name) }.getOrNull() }
            val i = transfers.indexOfFirst { it.id == pid }
            if (i >= 0) transfers[i] = transfers[i].copy(state = if (saved != null) TState.DONE else TState.FAILED, saved = saved)
            notifyProgress()
        }
    }

    private fun safeName(n: String): String =
        n.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifEmpty { "file" }

    /** Moves the received file into Downloads/Asan Share. */
    @Suppress("DEPRECATION")
    private fun save(f: Payload.File, name: String): Uri? {
        val r = ctx.contentResolver
        if (canUseOwnFolder()) {
            // Phone storage / Asan Share / Photos, Videos, Music, Apps, Files
            val dir = File(rootFolder(), subFolder(name)).apply { mkdirs() }
            var out = File(dir, name)
            var n = 1
            val base = name.substringBeforeLast('.')
            val ext = name.substringAfterLast('.', "")
            while (out.exists()) out = File(dir, if (ext.isEmpty()) "$base (${n++})" else "$base (${n++}).$ext")
            if (Build.VERSION.SDK_INT >= 29) {
                val src = f.asUri() ?: return null
                r.openInputStream(src)?.use { i -> FileOutputStream(out).use { o -> i.copyTo(o, 1 shl 20) } } ?: return null
                runCatching { r.delete(src, null, null) }
            } else {
                val src = f.asJavaFile() ?: return null
                if (!src.renameTo(out)) {
                    FileInputStream(src).use { i -> FileOutputStream(out).use { o -> i.copyTo(o, 1 shl 20) } }
                    src.delete()
                }
            }
            MediaScannerConnection.scanFile(ctx, arrayOf(out.path), null, null) // show in Gallery / Music
            return FileProvider.getUriForFile(ctx, ctx.packageName + ".files", out)
        }
        if (Build.VERSION.SDK_INT >= 29) {
            val src = f.asUri() ?: return null
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + SAVE_FOLDER)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val dst = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return null
            r.openInputStream(src)?.use { input ->
                r.openOutputStream(dst)?.use { out -> input.copyTo(out, 1 shl 20) }
            }
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            r.update(dst, values, null, null)
            runCatching { r.delete(src, null, null) }
            return dst
        } else {
            val src = f.asJavaFile() ?: return null
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), SAVE_FOLDER)
            dir.mkdirs()
            var out = File(dir, name)
            var n = 1
            while (out.exists()) out = File(dir, "(${n++}) $name")
            if (!src.renameTo(out)) {
                FileInputStream(src).use { i -> FileOutputStream(out).use { o -> i.copyTo(o, 1 shl 20) } }
                src.delete()
            }
            return FileProvider.getUriForFile(ctx, ctx.packageName + ".files", out)
        }
    }
}
