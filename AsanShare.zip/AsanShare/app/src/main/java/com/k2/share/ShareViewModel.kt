package com.k2.share

import android.app.Application
import android.bluetooth.BluetoothManager
import android.location.LocationManager
import android.net.wifi.WifiManager
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import androidx.core.location.LocationManagerCompat
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.common.api.ApiException
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.BandwidthInfo
import com.google.android.gms.nearby.connection.ConnectionOptions
import com.google.android.gms.nearby.connection.ConnectionType
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsStatusCodes
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.Locale

enum class Screen { HOME, SEND, RECEIVE }
enum class TState { WAITING, RUNNING, SAVING, DONE, FAILED }

data class PickedFile(val uri: Uri, val name: String, val size: Long)
data class Device(val id: String, val name: String)
data class Transfer(
    val id: Long,
    val name: String,
    val size: Long,
    val incoming: Boolean,
    val done: Long = 0,
    val state: TState = TState.WAITING,
    val speed: Double = 0.0,
    val saved: Uri? = null,
)

private const val SERVICE_ID = "com.javed.asanshare.TRANSFER"
// Point-to-point = one sender, one receiver, highest bandwidth (direct Wi-Fi link)
private val STRATEGY = Strategy.P2P_POINT_TO_POINT
const val SAVE_FOLDER = "Asan Share"

fun fmt(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var v = bytes / 1024.0
    var i = 0
    while (v >= 1024 && i < units.size - 1) { v /= 1024; i++ }
    return String.format(Locale.US, if (v < 10) "%.1f %s" else "%.0f %s", v, units[i])
}

class ShareViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Context = app.applicationContext
    private val client = Nearby.getConnectionsClient(ctx)
    private val prefs = ctx.getSharedPreferences("k2share", Context.MODE_PRIVATE)

    var myName by mutableStateOf(prefs.getString("name", null) ?: defaultName())
        private set
    var screen by mutableStateOf(Screen.HOME)
    var status by mutableStateOf("")
    var peerName by mutableStateOf<String?>(null)
    var connected by mutableStateOf(false)
    var request by mutableStateOf<Device?>(null)
    /** 0 = unknown, 1 = Bluetooth (slow), 2 = Wi-Fi, 3 = fast direct Wi-Fi */
    var link by mutableStateOf(0)

    /** Things the user must switch on: "Bluetooth", "Wi-Fi", "Location" */
    var problems by mutableStateOf(listOf<String>())
    var failed by mutableStateOf(false)
    private var started = false

    private var waitingForFast = false
    private var fastTimer: Job? = null

    val picked = mutableStateListOf<PickedFile>()
    val devices = mutableStateListOf<Device>()
    val transfers = mutableStateListOf<Transfer>()

    private var peerId: String? = null
    private val names = HashMap<String, String>()          // endpointId -> name
    private val meta = HashMap<Long, Pair<String, Long>>()  // payloadId -> (file name, size)
    private val incomingFiles = HashMap<Long, Payload>()
    private val completed = HashSet<Long>()
    private val startedAt = HashMap<Long, Long>()

    private fun defaultName(): String {
        val n = runCatching { Settings.Global.getString(ctx.contentResolver, "device_name") }.getOrNull()
        return if (!n.isNullOrBlank()) n
        else "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}"
    }

    fun rename(n: String) {
        val t = n.trim()
        if (t.isNotEmpty()) { myName = t; prefs.edit().putString("name", t).apply() }
    }

    // ---------- Files ----------
    fun addFiles(uris: List<Uri>) {
        for (u in uris) {
            if (picked.any { it.uri == u }) continue
            var name = "file"
            var size = 0L
            runCatching {
                ctx.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        c.getString(0)?.let { name = it }
                        if (!c.isNull(1)) size = c.getLong(1)
                    }
                }
            }
            picked.add(PickedFile(u, name, size))
        }
    }

    fun removeFile(f: PickedFile) { picked.remove(f) }

    fun openSend() { screen = Screen.SEND }
    fun openReceive() { screen = Screen.RECEIVE }

    // ---------- Finding & connecting ----------
    fun startDiscovery() {
        if (!playServicesOk()) return
        devices.clear()
        status = ""; failed = false; started = true
        client.stopDiscovery()
        client.startDiscovery(SERVICE_ID, discoveryCb, DiscoveryOptions.Builder().setStrategy(STRATEGY).build())
            .addOnFailureListener { onStartFailed(it, "search for phones") }
    }

    fun startAdvertising() {
        if (!playServicesOk()) return
        status = ""; failed = false; started = true
        client.stopAdvertising()
        client.startAdvertising(myName, SERVICE_ID, connCb, AdvertisingOptions.Builder().setStrategy(STRATEGY).setConnectionType(ConnectionType.DISRUPTIVE).build())
            .addOnFailureListener { onStartFailed(it, "become visible") }
    }

    /** Called every second or so by the Send/Receive screens. Starts (or restarts) once everything is switched on. */
    fun keepAlive() {
        if (connected) return
        val wasBlocked = problems.isNotEmpty()
        refreshRadios()
        if (problems.isNotEmpty()) return
        if (!started || (failed && wasBlocked)) retry()
    }

    fun retry() {
        if (screen == Screen.SEND) startDiscovery() else if (screen == Screen.RECEIVE) startAdvertising()
    }

    private fun refreshRadios() {
        val p = mutableListOf<String>()
        val bt = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
        if (bt != null && !runCatching { bt.isEnabled }.getOrDefault(true)) p += "Bluetooth"
        val wifi = ctx.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        if (wifi != null && !wifi.isWifiEnabled) p += "Wi-Fi"
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        if (lm != null && !LocationManagerCompat.isLocationEnabled(lm)) p += "Location"
        if (p != problems) problems = p
    }

    private fun playServicesOk(): Boolean {
        val ok = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(ctx) == ConnectionResult.SUCCESS
        if (!ok) {
            failed = true; started = true
            status = "This phone needs Google Play services (or an update of it) to use Asan Share."
        }
        return ok
    }

    private fun onStartFailed(e: Exception, what: String) {
        val code = (e as? ApiException)?.statusCode ?: -1
        // Already running is fine
        if (code == ConnectionsStatusCodes.STATUS_ALREADY_DISCOVERING || code == ConnectionsStatusCodes.STATUS_ALREADY_ADVERTISING) return
        failed = true
        status = when (code) {
            in 8030..8040 -> "Couldn't $what: a permission is missing. Open Settings, Apps, Asan Share, Permissions and allow Location and Nearby devices."
            ConnectionsStatusCodes.STATUS_BLUETOOTH_ERROR -> "Couldn't $what: Bluetooth error. Turn Bluetooth off and on, then tap Try again."
            else -> "Couldn't $what (error $code). Turn Wi-Fi and Bluetooth off and on, then tap Try again."
        }
    }

    fun connect(d: Device) {
        if (picked.isEmpty()) { status = "Choose files first"; return }
        status = "Connecting to ${d.name}…"
        names[d.id] = d.name
        client.stopDiscovery() // discovery slows down the link, stop it while connecting
        client.requestConnection(myName, d.id, connCb, ConnectionOptions.Builder().setConnectionType(ConnectionType.DISRUPTIVE).build())
            .addOnFailureListener { startDiscovery(); status = "Couldn't connect to ${d.name}. Try again." }
    }

    fun accept() {
        request?.let { names[it.id] = it.name; client.acceptConnection(it.id, payloadCb) }
        request = null
    }

    fun decline() {
        request?.let { client.rejectConnection(it.id) }
        request = null
    }

    fun goHome() {
        stopAll()
        transfers.clear(); devices.clear(); picked.clear()
        meta.clear(); incomingFiles.clear(); completed.clear(); startedAt.clear(); names.clear()
        peerId = null; peerName = null; connected = false; request = null; status = ""
        link = 0; waitingForFast = false; fastTimer?.cancel()
        started = false; failed = false
        screen = Screen.HOME
    }

    private fun stopAll() {
        client.stopDiscovery()
        client.stopAdvertising()
        client.stopAllEndpoints()
    }

    override fun onCleared() { stopAll() }

    private val discoveryCb = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) {
            if (devices.none { it.id == id }) devices.add(Device(id, info.endpointName))
        }
        override fun onEndpointLost(id: String) { devices.removeAll { it.id == id } }
    }

    private val connCb = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            if (info.isIncomingConnection) {
                if (peerId != null) { client.rejectConnection(id); return }
                request = Device(id, info.endpointName) // receiver confirms first
            } else {
                client.acceptConnection(id, payloadCb)
            }
        }

        override fun onConnectionResult(id: String, res: ConnectionResolution) {
            if (res.status.statusCode == ConnectionsStatusCodes.STATUS_OK) {
                peerId = id
                peerName = names[id] ?: "Nearby phone"
                connected = true
                status = ""
                client.stopDiscovery()
                client.stopAdvertising()
                if (screen == Screen.SEND) {
                    // Connections start on Bluetooth. Wait (max 6 s) for the switch to direct Wi-Fi before sending.
                    waitingForFast = true
                    fastTimer?.cancel()
                    fastTimer = viewModelScope.launch {
                        delay(6000)
                        if (waitingForFast) { waitingForFast = false; sendAll() }
                    }
                }
            } else {
                if (screen == Screen.SEND) {
                    startDiscovery()
                    status = "The other phone declined, or the connection failed. Try again."
                }
            }
        }

        override fun onBandwidthChanged(id: String, info: BandwidthInfo) {
            if (id != peerId) return
            link = when (info.quality) {
                BandwidthInfo.Quality.HIGH -> 3
                BandwidthInfo.Quality.MEDIUM -> 2
                BandwidthInfo.Quality.LOW -> 1
                else -> 0
            }
            if (waitingForFast && link == 3) {
                waitingForFast = false
                fastTimer?.cancel()
                sendAll()
            }
        }

        override fun onDisconnected(id: String) {
            if (id != peerId) return
            peerId = null
            connected = false
            for (i in transfers.indices) {
                val t = transfers[i]
                if (t.state == TState.RUNNING || t.state == TState.WAITING) transfers[i] = t.copy(state = TState.FAILED)
            }
            if (transfers.any { it.state == TState.FAILED }) status = "Connection lost"
        }
    }

    // ---------- Sending ----------
    fun sendMore(uris: List<Uri>) {
        picked.clear()
        addFiles(uris)
        sendAll()
    }

    private fun sendAll() {
        val id = peerId ?: return
        for (f in picked) {
            val pfd = runCatching { ctx.contentResolver.openFileDescriptor(f.uri, "r") }.getOrNull() ?: continue
            val p = Payload.fromFile(pfd)
            // small header so the receiver knows the real file name
            val header = "${p.id}|${f.size}|${f.name}".toByteArray(Charsets.UTF_8)
            client.sendPayload(id, Payload.fromBytes(header))
            client.sendPayload(id, p)
            transfers.add(Transfer(p.id, f.name, f.size, incoming = false))
        }
    }

    // ---------- Receiving ----------
    private val payloadCb = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, p: Payload) {
            when (p.type) {
                Payload.Type.BYTES -> {
                    val bytes = p.asBytes() ?: return
                    val parts = String(bytes, Charsets.UTF_8).split("|", limit = 3)
                    if (parts.size < 3) return
                    val pid = parts[0].toLongOrNull() ?: return
                    val size = parts[1].toLongOrNull() ?: 0L
                    val name = safeName(parts[2])
                    meta[pid] = name to size
                    upsertIncoming(pid) { it.copy(name = name, size = if (size > 0) size else it.size) }
                    tryFinish(pid)
                }
                Payload.Type.FILE -> {
                    incomingFiles[p.id] = p
                    upsertIncoming(p.id) { it }
                    tryFinish(p.id)
                }
                else -> {}
            }
        }

        override fun onPayloadTransferUpdate(endpointId: String, u: PayloadTransferUpdate) {
            val idx = transfers.indexOfFirst { it.id == u.payloadId }
            if (idx < 0) return
            val t = transfers[idx]
            if (t.state == TState.DONE || t.state == TState.SAVING) return
            val total = if (u.totalBytes > 0) u.totalBytes else t.size
            when (u.status) {
                PayloadTransferUpdate.Status.IN_PROGRESS -> {
                    val now = System.currentTimeMillis()
                    val start = startedAt.getOrPut(u.payloadId) { now }
                    val secs = (now - start) / 1000.0
                    transfers[idx] = t.copy(
                        state = TState.RUNNING,
                        done = u.bytesTransferred,
                        size = total,
                        speed = if (secs > 0.3) u.bytesTransferred / secs else t.speed,
                    )
                }
                PayloadTransferUpdate.Status.SUCCESS -> {
                    if (t.incoming) {
                        transfers[idx] = t.copy(state = TState.SAVING, done = total, size = total)
                        completed.add(u.payloadId)
                        tryFinish(u.payloadId)
                    } else {
                        transfers[idx] = t.copy(state = TState.DONE, done = total, size = total)
                    }
                }
                PayloadTransferUpdate.Status.FAILURE, PayloadTransferUpdate.Status.CANCELED ->
                    transfers[idx] = t.copy(state = TState.FAILED)
            }
        }
    }

    private fun upsertIncoming(pid: Long, change: (Transfer) -> Transfer) {
        val i = transfers.indexOfFirst { it.id == pid }
        if (i >= 0) transfers[i] = change(transfers[i])
        else {
            val m = meta[pid]
            transfers.add(change(Transfer(pid, m?.first ?: "Incoming file", m?.second ?: 0L, incoming = true)))
        }
    }

    /** Runs once the file has fully arrived AND we know its name. */
    private fun tryFinish(pid: Long) {
        if (pid !in completed) return
        val p = incomingFiles[pid] ?: return
        val name = meta[pid]?.first ?: return
        completed.remove(pid)
        incomingFiles.remove(pid)
        val file = p.asFile() ?: return
        viewModelScope.launch {
            val saved = withContext(Dispatchers.IO) { runCatching { save(file, name) }.getOrNull() }
            val i = transfers.indexOfFirst { it.id == pid }
            if (i >= 0) transfers[i] = transfers[i].copy(state = if (saved != null) TState.DONE else TState.FAILED, saved = saved)
        }
    }

    private fun safeName(n: String): String =
        n.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifEmpty { "file" }

    /** Moves the received file into Downloads/Asan Share. */
    @Suppress("DEPRECATION")
    private fun save(f: Payload.File, name: String): Uri? {
        val r = ctx.contentResolver
        if (Build.VERSION.SDK_INT >= 29) {
            val src = f.asUri() ?: return null
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + SAVE_FOLDER)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val dst = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return null
            r.openInputStream(src)?.use { input ->
                r.openOutputStream(dst)?.use { out -> input.copyTo(out, 1 shl 20) }
            }
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            r.update(dst, values, null, null)
            runCatching { r.delete(src, null, null) }
            return dst
        } else {
            val src = f.asJavaFile() ?: return null
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), SAVE_FOLDER)
            dir.mkdirs()
            var out = File(dir, name)
            var n = 1
            while (out.exists()) out = File(dir, "(${n++}) $name")
            if (!src.renameTo(out)) {
                FileInputStream(src).use { i -> FileOutputStream(out).use { o -> i.copyTo(o, 1 shl 20) } }
                src.delete()
            }
            return FileProvider.getUriForFile(ctx, ctx.packageName + ".files", out)
        }
    }
}
