package com.k2.share.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material.icons.automirrored.filled.ViewList
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.LinkOff
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.k2.share.Lang
import com.k2.share.tr
import androidx.compose.ui.res.painterResource
import com.k2.share.R
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.Phone
import com.k2.share.AppInvite
import com.k2.share.InviteServer
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.withFrameNanos
import androidx.compose.animation.core.Animatable
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import com.k2.share.Kind
import com.k2.share.APK_EXTS
import com.k2.share.ARCHIVE_EXTS
import com.k2.share.DESIGN_EXTS
import com.k2.share.DOC_EXTS
import com.k2.share.MEDIA_PERMS
import com.k2.share.MediaItem
import com.k2.share.Thumbs
import com.k2.share.hasMediaAccess
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.k2.share.Device
import com.k2.share.SAVE_FOLDER
import com.k2.share.Screen
import com.k2.share.ShareViewModel
import com.k2.share.TState
import com.k2.share.Transfer
import com.k2.share.fmt

private val muted: Color @Composable get() = MaterialTheme.colorScheme.onSurfaceVariant
private val card: Color @Composable get() = MaterialTheme.colorScheme.surfaceVariant

@Composable
fun AppRoot(vm: ShareViewModel, granted: Boolean, onRequest: () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides if (Lang.urdu) LayoutDirection.Rtl else LayoutDirection.Ltr) {
        AppRootContent(vm, granted, onRequest)
    }
}

@Composable
private fun AppRootContent(vm: ShareViewModel, granted: Boolean, onRequest: () -> Unit) {
    val view = LocalView.current
    val busy = vm.screen == Screen.CONNECTED
    DisposableEffect(busy) {
        view.keepScreenOn = busy // screen stays on during a transfer
        onDispose { view.keepScreenOn = false }
    }
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        if (!granted) PermissionScreen(onRequest)
        else AnimatedContent(
            targetState = vm.screen,
            transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(160)) },
            label = "nav",
        ) { s ->
            when (s) {
                Screen.HOME -> HomeScreen(vm)
                Screen.CONNECTED -> ConnectedScreen(vm)
                Screen.INVITE -> InviteScreen(vm)
                Screen.RECEIVED -> ReceivedScreen(vm)
            }
        }
    }
    vm.request?.let { r ->
        AlertDialog(
            onDismissRequest = {},
            icon = { Avatar(r.name, 64.dp) },
            title = { Text(r.name, textAlign = TextAlign.Center) },
            text = {
                Text(
                    tr("wants to connect with you to share files.", "آپ سے جُڑ کر فائلیں شیئر کرنا چاہتا ہے۔"), textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(), fontSize = 16.sp,
                )
            },
            confirmButton = {
                Button(onClick = vm::accept, modifier = Modifier.height(48.dp), shape = RoundedCornerShape(16.dp)) {
                    Text(tr("Accept", "قبول کریں"), fontSize = 16.sp)
                }
            },
            dismissButton = { TextButton(onClick = vm::decline) { Text(tr("Decline", "انکار")) } },
        )
    }
    vm.connecting?.let { d ->
        AlertDialog(
            onDismissRequest = {},
            icon = { Avatar(d.name, 64.dp) },
            title = { Text(tr("Connecting to ${d.name}", "${d.name} سے جُڑ رہے ہیں"), textAlign = TextAlign.Center) },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Spinner(40.dp)
                    Spacer(Modifier.height(14.dp))
                    Text(tr("Waiting for ${d.name} to tap Accept…", "${d.name} کے قبول کرنے کا انتظار…"), textAlign = TextAlign.Center, color = muted)
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = vm::cancelConnect) { Text(tr("Cancel", "منسوخ")) } },
        )
    }
}

// ---------------- Permissions ----------------

@Composable
private fun PermissionScreen(onRequest: () -> Unit) {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(Modifier.size(96.dp).clip(CircleShape).background(Ink), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.LocationOn, null, tint = Saffron, modifier = Modifier.size(44.dp))
        }
        Spacer(Modifier.height(24.dp))
        Text(tr("Allow nearby access", "قریبی فونز تک رسائی دیں"), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            tr("Asan Share needs this to find phones near you and connect to them directly. Files never go through the internet.", "آسان شیئر کو قریبی فون ڈھونڈنے اور اُن سے براہِ راست جُڑنے کے لیے یہ اجازت چاہیے۔ فائلیں انٹرنیٹ سے نہیں جاتیں۔"),
            textAlign = TextAlign.Center, color = muted,
        )
        Spacer(Modifier.height(28.dp))
        Button(onClick = onRequest, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(16.dp)) {
            Text(tr("Allow", "اجازت دیں"), fontSize = 16.sp)
        }
        TextButton(onClick = {
            ctx.startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }) { Text(tr("Open app settings", "ایپ کی سیٹنگز کھولیں")) }
    }
}

// ---------------- Home: always visible + always searching (like Zapya) ----------------

@Composable
private fun HomeScreen(vm: ShareViewModel) {
    var renaming by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        vm.loadReceived()
        while (true) { vm.keepAlive(); delay(1200) }
    }
    val found = vm.devices.size
    Column(
        Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Logo(42.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(tr("Asan Share", "آسان شیئر"), fontSize = 21.sp, fontWeight = FontWeight.Bold, lineHeight = 24.sp)
                Text(
                    tr("by JAVED IQBAL", "از جاوید اقبال"), style = MaterialTheme.typography.labelMedium,
                    color = muted, letterSpacing = 0.8.sp,
                )
            }
            Text(
                if (Lang.urdu) "English" else "اردو",
                fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.clip(RoundedCornerShape(50))
                    .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f), RoundedCornerShape(50))
                    .clickable { vm.setUrdu(!Lang.urdu) }.padding(horizontal = 12.dp, vertical = 6.dp),
            )
            Spacer(Modifier.width(8.dp))
            val ctx = LocalContext.current
            Box(Modifier.clip(CircleShape).clickable { openWhatsApp(ctx) }.padding(4.dp)) { WhatsAppIcon(34.dp) }
        }
        Spacer(Modifier.height(10.dp))
        MyPhoneCard(vm.myName, visible = vm.problems.isEmpty() && !vm.failed) { renaming = true }
        Spacer(Modifier.height(12.dp))
        if (!vm.ownFolder && android.os.Build.VERSION.SDK_INT >= 30) {
            FolderAccessCard()
            Spacer(Modifier.height(12.dp))
        }
        Spacer(Modifier.height(4.dp))
        if (vm.reconnectName != null) {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Saffron.copy(alpha = 0.18f))
                    .padding(start = 16.dp, end = 6.dp, top = 12.dp, bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Spinner(22.dp, Saffron, 2.5.dp)
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text(tr("Reconnecting to ${vm.reconnectName}…", "${vm.reconnectName} سے دوبارہ جُڑ رہے ہیں…"), fontWeight = FontWeight.Bold)
                    Text(
                        if (vm.resumeCount > 0) tr("${vm.resumeCount} unfinished files will continue automatically", "${vm.resumeCount} نامکمل فائلیں خود بخود جاری ہوں گی")
                        else tr("Keep Asan Share open on both phones", "دونوں فونز پر آسان شیئر کھلا رکھیں"),
                        style = MaterialTheme.typography.bodySmall, color = muted,
                    )
                }
                TextButton(onClick = vm::cancelReconnect) { Text(tr("Cancel", "منسوخ")) }
            }
            Spacer(Modifier.height(14.dp))
        }

        if (vm.picked.isNotEmpty() && vm.reconnectName == null) {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Ink).padding(start = 16.dp, end = 6.dp, top = 12.dp, bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.Send, null, tint = Saffron)
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text(tr("${vm.picked.size} files ready", "${vm.picked.size} فائلیں تیار ہیں"), color = Color.White, fontWeight = FontWeight.Bold)
                    Text(tr("Tap a phone below to send them", "بھیجنے کے لیے کسی فون پر ٹیپ کریں"), color = Color.White.copy(alpha = 0.75f), style = MaterialTheme.typography.bodySmall)
                }
                TextButton(onClick = vm::clearSelection) { Text(tr("Clear", "صاف کریں"), color = Saffron) }
            }
            Spacer(Modifier.height(14.dp))
        }

        val blocked = vm.problems.isNotEmpty() || vm.failed
        if (!blocked) {
            Text(
                if (found == 0) tr("Looking for phones…", "فونز تلاش ہو رہے ہیں…") else tr("Tap a phone to connect", "جُڑنے کے لیے فون پر ٹیپ کریں"),
                fontSize = 24.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                if (found == 0) tr("Open Asan Share on the other phone.\nIt will show up here by itself.", "دوسرے فون پر آسان شیئر کھولیں۔\nوہ خود یہاں نظر آ جائے گا۔")
                else if (found == 1) tr("1 phone nearby", "قریب 1 فون") else tr("$found phones nearby", "قریب $found فونز"),
                color = muted, textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(4.dp))
            Radar(vm)
        } else {
            FixItCard(vm)
        }
        if (vm.status.isNotEmpty() && !vm.failed) {
            Text(
                vm.status, color = MaterialTheme.colorScheme.primary, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            )
        }

        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ActionCard(
                Icons.Filled.Download, tr("Received files", "موصول شدہ فائلیں"),
                if (vm.received.isEmpty()) tr("Nothing yet", "ابھی کچھ نہیں") else tr("${vm.received.size} files", "${vm.received.size} فائلیں"),
                Saffron, OnSaffron, Modifier.weight(1f).fillMaxHeight(), vm::openReceived,
            )
            ActionCard(
                Icons.Filled.PersonAdd, tr("Friend has no app?", "دوست کے پاس ایپ نہیں؟"),
                tr("Send Asan Share to them", "انہیں آسان شیئر بھیجیں"),
                Ink, Color.White, Modifier.weight(1f).fillMaxHeight(), vm::openInvite,
            )
        }
        Spacer(Modifier.height(24.dp))
    }
    if (renaming) {
        var text by remember { mutableStateOf(vm.myName) }
        AlertDialog(
            onDismissRequest = { renaming = false },
            title = { Text(tr("Your phone's name", "آپ کے فون کا نام")) },
            text = {
                Column {
                    Text(tr("Other phones will see this name.", "دوسرے فونز پر یہی نام نظر آئے گا۔"), color = muted)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = text, onValueChange = { text = it.take(30) }, singleLine = true)
                }
            },
            confirmButton = { Button(onClick = { vm.rename(text); renaming = false }) { Text(tr("Save", "محفوظ کریں")) } },
            dismissButton = { TextButton(onClick = { renaming = false }) { Text(tr("Cancel", "منسوخ")) } },
        )
    }
}

@Composable
private fun ActionCard(
    icon: ImageVector, title: String, subtitle: String,
    accent: Color, onAccent: Color, modifier: Modifier, onClick: () -> Unit,
) {
    Column(
        modifier.clip(RoundedCornerShape(24.dp)).background(card).clickable(onClick = onClick).padding(16.dp)
    ) {
        Box(Modifier.size(46.dp).clip(RoundedCornerShape(15.dp)).background(accent), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = onAccent)
        }
        Spacer(Modifier.height(12.dp))
        Text(title, fontWeight = FontWeight.Bold)
        Text(subtitle, style = MaterialTheme.typography.bodySmall, color = muted)
    }
}

@Composable
private fun MyPhoneCard(name: String, visible: Boolean, onEdit: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(card)
            .border(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f), RoundedCornerShape(22.dp))
            .clickable(onClick = onEdit).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box {
            Avatar(name, 46.dp)
            Box(
                Modifier.align(Alignment.BottomEnd).size(14.dp).clip(CircleShape).background(card).padding(2.dp)
                    .clip(CircleShape).background(if (visible) Good else MaterialTheme.colorScheme.error)
            )
        }
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Text(
                if (visible) tr("Visible to nearby phones", "قریبی فونز کو نظر آ رہا ہے") else tr("Not visible right now", "ابھی نظر نہیں آ رہا"),
                style = MaterialTheme.typography.labelMedium,
                color = if (visible) Good else MaterialTheme.colorScheme.error,
            )
            Text(name, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Box(
            Modifier.size(38.dp).clip(CircleShape).background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f)),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Filled.Edit, tr("Change name", "نام بدلیں"), tint = muted, modifier = Modifier.size(18.dp)) }
    }
}

@Composable
private fun DeveloperCredit() {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(tr("Developed by", "تیار کردہ"), style = MaterialTheme.typography.labelSmall, color = muted)
        Text("JAVED IQBAL", fontWeight = FontWeight.Black, letterSpacing = 1.5.sp, style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(8.dp))
        Row(
            Modifier.clip(RoundedCornerShape(50)).background(Color(0xFF25D366).copy(alpha = 0.14f)).clickable { openWhatsApp(ctx) }.padding(start = 6.dp, end = 14.dp, top = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            WhatsAppIcon(26.dp)
            Spacer(Modifier.width(8.dp))
            Text("0303 2901193", fontWeight = FontWeight.Bold, color = Color(0xFF1FAF55))
        }
    }
}

/** WhatsApp-style mark: green chat bubble with a white phone. */
@Composable
private fun WhatsAppIcon(size: Dp) {
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = this.size.width
            val green = Color(0xFF25D366)
            drawCircle(green, radius = w * 0.44f, center = Offset(w * 0.52f, w * 0.46f))
            val tail = Path().apply {
                moveTo(w * 0.18f, w * 0.62f); lineTo(w * 0.08f, w * 0.95f); lineTo(w * 0.40f, w * 0.84f); close()
            }
            drawPath(tail, green)
            drawCircle(Color.White, radius = w * 0.34f, center = Offset(w * 0.52f, w * 0.46f), style = Stroke(width = w * 0.07f))
        }
        Icon(Icons.Filled.Phone, null, tint = Color.White, modifier = Modifier.size(size * 0.40f).offset(x = size * 0.02f, y = (-0.02f * size.value).dp))
    }
}

@Composable
private fun DeviceRow(d: Device, enabled: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().alpha(if (enabled) 1f else 0.5f).clip(RoundedCornerShape(20.dp)).background(card)
            .clickable(enabled = enabled, onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Avatar(d.name, 48.dp)
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Text(d.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                tr("Tap to connect", "جُڑنے کے لیے ٹیپ کریں"),
                style = MaterialTheme.typography.bodySmall, color = muted,
            )
        }
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = muted)
    }
}

@Composable
private fun Logo(size: Dp) {
    Image(painterResource(R.drawable.app_logo), "Asan Share", Modifier.size(size))
}

@Composable
private fun InviteScreen(vm: ShareViewModel) {
    val ctx = LocalContext.current
    var wifiMode by remember { mutableStateOf(false) }
    BackHandler { if (wifiMode) wifiMode = false else vm.goHome() }
    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        TopBar(if (wifiMode) tr("Download over Wi-Fi", "وائی فائی سے ڈاؤن لوڈ") else tr("Send the app to a friend", "دوست کو ایپ بھیجیں")) { if (wifiMode) wifiMode = false else vm.goHome() }
        if (wifiMode) {
            WifiInvite()
        } else {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text(tr("Your friend doesn't need internet. Pick one way:", "دوست کو انٹرنیٹ کی ضرورت نہیں۔ کوئی ایک طریقہ چنیں:"), color = muted)
                InviteOption(Icons.Filled.Bluetooth, tr("Send by Bluetooth", "بلوٹوتھ سے بھیجیں"), tr("Works on every phone. Takes about a minute.", "ہر فون پر چلتا ہے۔ تقریباً ایک منٹ لگتا ہے۔"), Ink, Color.White) {
                    AppInvite.sendByBluetooth(ctx)
                }
                InviteOption(Icons.Filled.Wifi, tr("Download over Wi-Fi", "وائی فائی سے ڈاؤن لوڈ"), tr("Fastest. Your friend scans 2 codes with the camera.", "سب سے تیز۔ دوست کیمرے سے 2 کوڈ اسکین کرے۔"), Saffron, OnSaffron) {
                    wifiMode = true
                }
                InviteOption(Icons.Filled.Share, tr("Quick Share, WhatsApp and more", "کوئیک شیئر، واٹس ایپ وغیرہ"), tr("Use any sharing app on your phone.", "فون کی کوئی بھی شیئرنگ ایپ استعمال کریں۔"), card, MaterialTheme.colorScheme.onSurface) {
                    AppInvite.shareAnyWay(ctx)
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    tr("When it arrives, your friend taps the file, then Install. The phone may ask to allow installing from this source. That's normal.", "فائل ملنے پر دوست اسے کھول کر انسٹال دبائے۔ فون اس ذریعے سے انسٹال کی اجازت مانگ سکتا ہے، یہ عام بات ہے۔"),
                    style = MaterialTheme.typography.bodySmall, color = muted,
                )
            }
        }
    }
}

@Composable
private fun InviteOption(icon: ImageVector, title: String, desc: String, accent: Color, onAccent: Color, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(card).clickable(onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(54.dp).clip(RoundedCornerShape(17.dp)).background(accent), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = onAccent, modifier = Modifier.size(28.dp))
        }
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text(desc, style = MaterialTheme.typography.bodySmall, color = muted)
        }
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = muted)
    }
}

@Composable
private fun WifiInvite() {
    val ctx = LocalContext.current
    val server = remember { InviteServer(ctx.applicationContext) }
    var ssid by remember { mutableStateOf<String?>(null) }
    var pass by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var timedOut by remember { mutableStateOf(false) }
    var ip by remember { mutableStateOf<String?>(null) }
    DisposableEffect(Unit) {
        server.startWeb()
        server.startHotspot({ s, p -> ssid = s; pass = p }, { error = it })
        onDispose { server.stop() }
    }
    // keep the download link up to date (it changes when a hotspot turns on)
    LaunchedEffect(Unit) { while (true) { ip = AppInvite.localIp(); delay(1000) } }
    // some phones never answer: don't keep the user waiting forever
    LaunchedEffect(Unit) { delay(12_000); if (ssid == null && error == null) timedOut = true }
    val url = ip?.let { "http://$it:${server.port}" }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        when {
            ssid != null -> {
                StepCard(
                    1, tr("Join this Wi-Fi", "یہ وائی فائی جوائن کریں"),
                    tr("On your friend's phone, open the Camera and point it at this code. Tap the Wi-Fi message to join.",
                        "دوست کے فون پر کیمرہ کھول کر اس کوڈ کی طرف کریں، پھر وائی فائی والے پیغام پر ٹیپ کریں۔"),
                    AppInvite.wifiQrText(ssid!!, pass ?: ""),
                    tr("Wi-Fi: $ssid\nPassword: $pass", "وائی فائی: $ssid\nپاس ورڈ: $pass"),
                )
                if (url != null) {
                    StepCard(
                        2, tr("Download the app", "ایپ ڈاؤن لوڈ کریں"),
                        tr("Now point the camera at this code and open the link. Tap Download the app.",
                            "اب کیمرہ اس کوڈ کی طرف کریں اور لنک کھولیں، پھر Download the app دبائیں۔"),
                        url, url,
                    )
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Spinner(22.dp); Spacer(Modifier.width(10.dp))
                        Text(tr("Getting the download link ready…", "ڈاؤن لوڈ لنک تیار ہو رہا ہے…"), color = muted)
                    }
                }
            }
            error != null || timedOut -> HotspotFallback(url, error)
            else -> {
                Spacer(Modifier.height(48.dp))
                Spinner(48.dp)
                Text(tr("Starting Wi-Fi…", "وائی فائی شروع ہو رہا ہے…"), color = muted)
                Text(
                    tr("This takes a few seconds.", "اس میں چند سیکنڈ لگتے ہیں۔"),
                    style = MaterialTheme.typography.bodySmall, color = muted,
                )
            }
        }
    }
}

/** When the phone won't create its own Wi-Fi: use the normal Mobile Hotspot (or the same Wi-Fi) instead. */
@Composable
private fun HotspotFallback(url: String?, error: String?) {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(card).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(tr("Let's use your hotspot instead", "اس کے بجائے ہاٹ اسپاٹ استعمال کریں"), fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(
            tr("This phone didn't allow Asan Share to make its own Wi-Fi. It's easy another way:",
                "اس فون نے آسان شیئر کو اپنا وائی فائی بنانے نہیں دیا۔ دوسرا آسان طریقہ:"),
            color = muted,
        )
        Text(tr("1.  Turn on your Mobile Hotspot", "1.  اپنا موبائل ہاٹ اسپاٹ آن کریں"), fontWeight = FontWeight.SemiBold)
        Button(
            onClick = {
                runCatching { ctx.startActivity(Intent("android.settings.TETHER_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                    .onFailure { runCatching { ctx.startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
            },
            modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(16.dp),
        ) { Text(tr("Open hotspot settings", "ہاٹ اسپاٹ کی سیٹنگز کھولیں")) }
        Text(tr("2.  Your friend joins your hotspot from their Wi-Fi list", "2.  دوست اپنی وائی فائی لسٹ سے آپ کا ہاٹ اسپاٹ جوائن کرے"), fontWeight = FontWeight.SemiBold)
        Text(tr("3.  Your friend scans this code with the camera", "3.  دوست کیمرے سے یہ کوڈ اسکین کرے"), fontWeight = FontWeight.SemiBold)
        Text(
            tr("Tip: if both phones are already on the same Wi-Fi, skip steps 1 and 2.",
                "مشورہ: اگر دونوں فون پہلے سے ایک ہی وائی فائی پر ہیں تو 1 اور 2 چھوڑ دیں۔"),
            style = MaterialTheme.typography.bodySmall, color = muted,
        )
        if (error != null) Text(error, style = MaterialTheme.typography.bodySmall, color = muted)
    }
    if (url != null) {
        StepCard(3, tr("Download the app", "ایپ ڈاؤن لوڈ کریں"),
            tr("Scan with the camera and open the link.", "کیمرے سے اسکین کر کے لنک کھولیں۔"), url, url)
    } else {
        Text(
            tr("The download code will appear here once your hotspot or Wi-Fi is on.",
                "ہاٹ اسپاٹ یا وائی فائی آن ہوتے ہی ڈاؤن لوڈ کوڈ یہاں نظر آئے گا۔"),
            color = muted, textAlign = TextAlign.Center,
        )
    }
}

/** Loading spinner that keeps turning even when phone animations are switched off. */
@Composable
private fun Spinner(size: Dp = 36.dp, color: Color = MaterialTheme.colorScheme.primary, stroke: Dp = 3.5.dp) {
    val phase = rememberLoopPhase(1000)
    Canvas(Modifier.size(size)) {
        val sw = stroke.toPx()
        val tl = Offset(sw / 2, sw / 2)
        val sz = androidx.compose.ui.geometry.Size(this.size.width - sw, this.size.height - sw)
        drawArc(color.copy(alpha = 0.18f), 0f, 360f, false, topLeft = tl, size = sz, style = Stroke(sw))
        drawArc(
            color, phase.value * 360f - 90f, 110f, false, topLeft = tl, size = sz,
            style = Stroke(sw, cap = StrokeCap.Round),
        )
    }
}

@Composable
private fun StepCard(n: Int, title: String, desc: String, qrText: String, caption: String) {
    val img = remember(qrText) { AppInvite.qr(qrText) }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(card).padding(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(34.dp).clip(CircleShape).background(Ink), contentAlignment = Alignment.Center) {
                Text("$n", color = Saffron, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.width(12.dp))
            Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        Spacer(Modifier.height(8.dp))
        Text(desc, color = muted, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(14.dp))
        if (img != null) {
            Image(
                img, "QR code",
                Modifier.size(230.dp).clip(RoundedCornerShape(16.dp)).background(Color.White).padding(10.dp),
            )
        }
        Spacer(Modifier.height(10.dp))
        Text(caption, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
    }
}

// ---------------- Transfer progress ----------------

@Composable
private fun TransfersPanel(vm: ShareViewModel) {
    val ctx = LocalContext.current
    val list = vm.transfers
    val total = maxOf(vm.expectedBytes, list.sumOf { it.size })
    val done = list.sumOf { it.done }
    val count = maxOf(vm.expectedCount, list.size)
    val doneCount = list.count { it.state == TState.DONE }
    val finished = list.isNotEmpty() && list.size >= count && list.all { it.state == TState.DONE || it.state == TState.FAILED }
    val speed = list.filter { it.state == TState.RUNNING }.sumOf { it.speed }
    val progress by animateFloatAsState(
        if (total > 0) (done.toFloat() / total).coerceIn(0f, 1f) else 0f, label = "progress",
    )
    if (list.isEmpty()) {
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Pulse(MaterialTheme.colorScheme.primary, 170.dp) {
                Box(Modifier.size(64.dp).clip(CircleShape).background(Ink), contentAlignment = Alignment.Center) {
                    Icon(Icons.AutoMirrored.Filled.Send, null, tint = Saffron, modifier = Modifier.size(28.dp))
                }
            }
            Spacer(Modifier.height(14.dp))
            Text(tr("You're connected", "آپ جُڑ گئے ہیں"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(
                tr("Pick photos, videos, apps or files from the tabs above and tap Send. Files from ${vm.peerName ?: "the other phone"} will show up here too.", "اوپر کے ٹیبز سے تصاویر، ویڈیوز، ایپس یا فائلیں چنیں اور «بھیجیں» دبائیں۔ ${vm.peerName ?: "دوسرے فون"} کی بھیجی فائلیں بھی یہیں نظر آئیں گی۔"),
                color = muted, textAlign = TextAlign.Center,
            )
        }
        return
    }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(card).padding(20.dp)
            ) {
                Text(
                    if (finished) tr("All done", "سب مکمل") else "${(progress * 100).toInt()}%",
                    fontSize = 40.sp, fontWeight = FontWeight.Black,
                )
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth().height(8.dp),
                    color = if (finished) Good else MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.15f),
                    strokeCap = StrokeCap.Round,
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    buildString {
                        append(tr("$doneCount of $count files   ${fmt(done)} of ${fmt(total)}", "$count میں سے $doneCount فائلیں   ${fmt(total)} میں سے ${fmt(done)}"))
                        if (speed > 0 && !finished) append("   ${fmt(speed.toLong())}/s")
                    },
                    color = muted, style = MaterialTheme.typography.bodySmall,
                )
            }
        }
        items(list.asReversed(), key = { it.id }) { t -> TransferRow(t) { t.saved?.let { openFile(ctx, it) } } }
    }
}

@Composable
private fun TransferRow(t: Transfer, onOpen: () -> Unit) {
    val p = if (t.size > 0) (t.done.toFloat() / t.size).coerceIn(0f, 1f) else 0f
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(card)
            .clickable(enabled = t.saved != null, onClick = onOpen).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        FileBadge(t.name)
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(t.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
            if (t.state == TState.RUNNING || t.state == TState.WAITING) {
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { p }, modifier = Modifier.fillMaxWidth(), strokeCap = StrokeCap.Round,
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(
                when (t.state) {
                    TState.WAITING -> tr("Waiting…", "انتظار…")
                    TState.RUNNING -> (if (t.incoming) tr("Receiving ", "وصول ہو رہی ہے ") else tr("Sending ", "جا رہی ہے ")) + tr("${fmt(t.done)} of ${fmt(t.size)}", "${fmt(t.size)} میں سے ${fmt(t.done)}")
                    TState.SAVING -> tr("Saving…", "محفوظ ہو رہی ہے…")
                    TState.DONE -> if (t.incoming) tr("Received ${fmt(t.size)}, tap to open", "موصول ${fmt(t.size)}، کھولنے کے لیے ٹیپ کریں") else tr("Sent ${fmt(t.size)}", "بھیج دی ${fmt(t.size)}")
                    TState.FAILED -> tr("Didn't arrive. Send it again.", "نہیں پہنچی۔ دوبارہ بھیجیں۔")
                },
                style = MaterialTheme.typography.bodySmall, color = muted,
            )
        }
        when (t.state) {
            TState.DONE -> Icon(Icons.Filled.CheckCircle, tr("Done", "مکمل"), tint = Good)
            TState.FAILED -> Icon(Icons.Filled.Warning, tr("Failed", "ناکام"), tint = MaterialTheme.colorScheme.error)
            else -> {}
        }
    }
}

@Composable
private fun FixItCard(vm: ShareViewModel) {
    val ctx = LocalContext.current
    fun open(action: String) {
        runCatching { ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(card).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(Icons.Filled.Warning, null, tint = Saffron, modifier = Modifier.size(36.dp))
        Spacer(Modifier.height(10.dp))
        if (vm.problems.isNotEmpty()) {
            Text(
                if (Lang.urdu) vm.problems.joinToString(" اور ") { urName(it) } + " آن کریں"
                else "Turn on ${vm.problems.joinToString(" and ")}", fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Spacer(Modifier.height(4.dp))
            Text(tr("Asan Share starts by itself once it's on.", "آن ہوتے ہی آسان شیئر خود شروع ہو جائے گا۔"), color = muted, textAlign = TextAlign.Center)
            Spacer(Modifier.height(14.dp))
            for (p in vm.problems) {
                OutlinedButton(
                    onClick = {
                        open(
                            when (p) {
                                "Bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                                "Wi-Fi" -> Settings.ACTION_WIFI_SETTINGS
                                else -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
                            }
                        )
                    },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).height(50.dp),
                    shape = RoundedCornerShape(16.dp),
                ) { Text(if (Lang.urdu) "${urName(p)} کی سیٹنگز کھولیں" else "Open $p settings") }
            }
        } else {
            Text(vm.status, textAlign = TextAlign.Center)
            Spacer(Modifier.height(14.dp))
            Button(
                onClick = vm::retry, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp),
            ) { Text(tr("Try again", "دوبارہ کوشش کریں"), fontSize = 16.sp) }
            TextButton(onClick = {
                runCatching {
                    ctx.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            }) { Text(tr("Open app permissions", "ایپ کی اجازتیں کھولیں")) }
        }
    }
}

// ---------------- Small pieces ----------------

@Composable
private fun TopBar(title: String, onBack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, tr("Back", "واپس")) }
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SectionTitle(title: String, trailing: String?) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (trailing != null) Text(trailing, style = MaterialTheme.typography.bodySmall, color = muted)
    }
}

private val avatarColors = listOf(0xFF1F2A6B, 0xFF0E8C7F, 0xFFC2410C, 0xFF9D174D, 0xFF4338CA, 0xFF15803D).map { Color(it) }

@Composable
private fun Avatar(name: String, size: Dp) {
    val c = avatarColors[(name.hashCode() and 0x7fffffff) % avatarColors.size]
    val light = Color(
        red = (c.red + (1f - c.red) * 0.35f), green = (c.green + (1f - c.green) * 0.35f), blue = (c.blue + (1f - c.blue) * 0.35f),
    )
    Box(
        Modifier.size(size).clip(CircleShape).background(Brush.linearGradient(listOf(light, c))),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            name.trim().take(1).uppercase().ifEmpty { "?" },
            color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.42f).sp,
        )
    }
}

@Composable
private fun FileBadge(name: String) {
    val ext = name.substringAfterLast('.', "").lowercase()
    val (label, color) = when (ext) {
        "jpg", "jpeg", "png", "gif", "webp", "heic" -> "IMG" to Color(0xFFDB2777)
        "mp4", "mkv", "mov", "avi", "3gp", "webm" -> "VID" to Color(0xFFEA580C)
        "mp3", "m4a", "wav", "aac", "ogg", "opus" -> "AUD" to Color(0xFF7C3AED)
        "apk" -> "APK" to Color(0xFF16A34A)
        "pdf" -> "PDF" to Color(0xFFDC2626)
        "zip", "rar", "7z" -> "ZIP" to Color(0xFF92400E)
        "dst", "emb", "pes", "jef", "exp", "dsb" -> "EMB" to Color(0xFF0E8C7F)
        else -> ext.take(4).uppercase().ifEmpty { "FILE" } to Color(0xFF4F5BD5)
    }
    Box(
        Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(color.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = color, fontWeight = FontWeight.Bold, fontSize = 11.sp) }
}

/**
 * A 0..1 value that loops forever. Driven by the screen's frame clock, so it keeps moving
 * even on phones where "animations" are switched off in settings or by battery saver.
 */
@Composable
private fun rememberLoopPhase(periodMs: Int): State<Float> {
    val phase = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(periodMs) {
        val start = withFrameNanos { it }
        while (true) {
            withFrameNanos { t -> phase.floatValue = (((t - start) / 1_000_000L) % periodMs) / periodMs.toFloat() }
        }
    }
    return phase
}

@Composable
private fun Pulse(color: Color, size: Dp, content: @Composable () -> Unit) {
    val phase = rememberLoopPhase(2400)
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = this.size.minDimension / 2f
            val p = phase.value
            for (i in 0 until 3) {
                val f = (p + i / 3f) % 1f
                drawCircle(color.copy(alpha = (1f - f) * 0.28f), radius = r * (0.3f + 0.7f * f))
            }
        }
        content()
    }
}

@Composable
private fun Radar(vm: ShareViewModel) {
    val phase = rememberLoopPhase(2600)
    val primary = MaterialTheme.colorScheme.primary
    val ring = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.2f)
    val surface = MaterialTheme.colorScheme.background
    BoxWithConstraints(
        Modifier.widthIn(max = 360.dp).fillMaxWidth().aspectRatio(1f),
        contentAlignment = Alignment.Center,
    ) {
        val half = maxWidth / 2
        Canvas(Modifier.fillMaxSize()) {
            val r = this.size.minDimension / 2f
            val p = phase.value
            for (i in 1..3) drawCircle(ring, radius = r * i / 3f, style = Stroke(width = 1.dp.toPx()))
            drawCircle(primary.copy(alpha = (1f - p) * 0.18f), radius = r * p)
            rotate(p * 360f) {
                drawArc(
                    brush = Brush.sweepGradient(
                        0f to Color.Transparent,
                        0.18f to primary.copy(alpha = 0.32f),
                        0.181f to Color.Transparent,
                        center = center,
                    ),
                    startAngle = 0f, sweepAngle = 65f, useCenter = true,
                    topLeft = Offset(center.x - r, center.y - r),
                    size = androidx.compose.ui.geometry.Size(r * 2, r * 2),
                )
            }
        }
        Box(Modifier.size(70.dp).clip(CircleShape).background(surface).padding(4.dp)) { Avatar(vm.myName, 62.dp) }
        val list = vm.devices
        list.forEachIndexed { i, d ->
            val angle = Math.toRadians(-90.0 + 40.0 + i * 360.0 / list.size)
            val dist = half * 0.68f
            DeviceBubble(
                d,
                Modifier.offset(x = dist * cos(angle).toFloat(), y = dist * sin(angle).toFloat()),
            ) { vm.connect(d) }
        }
    }
}

@Composable
private fun DeviceBubble(d: Device, modifier: Modifier, onClick: () -> Unit) {
    val pop = remember { Animatable(0.6f) }
    LaunchedEffect(d.id) { pop.animateTo(1f, tween(260)) }
    Column(
        modifier.scale(pop.value).width(96.dp).clip(RoundedCornerShape(18.dp)).clickable(onClick = onClick).padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(62.dp).clip(CircleShape).background(Saffron).padding(3.dp)) { Avatar(d.name, 56.dp) }
        Spacer(Modifier.height(4.dp))
        Text(d.name, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
    }
}

private fun openFile(ctx: Context, uri: Uri) {
    val type = ctx.contentResolver.getType(uri) ?: "*/*"
    val view = Intent(Intent.ACTION_VIEW).setDataAndType(uri, type)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    runCatching {
        ctx.startActivity(Intent.createChooser(view, tr("Open with", "اس سے کھولیں")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}


// ---------------- Pick files (Zapya-style tabs) ----------------

@Composable
private fun ConnectedScreen(vm: ShareViewModel) {
    val ctx = LocalContext.current
    var askDisconnect by remember { mutableStateOf(false) }
    BackHandler { if (vm.connected) askDisconnect = true else vm.goHome() }
    var hasMedia by remember { mutableStateOf(hasMediaAccess(ctx)) }
    val mediaPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        hasMedia = hasMediaAccess(ctx)
        vm.loadLibrary(hasMedia)
    }
    val browse = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.addFiles(it) }
    LaunchedEffect(Unit) {
        vm.loadLibrary(hasMedia)
        if (!hasMedia) mediaPerm.launch(MEDIA_PERMS)
    }
    var tab by rememberSaveable { mutableIntStateOf(if (vm.transfers.isNotEmpty()) 0 else 2) }
    // jump to Transfers when the other phone starts sending (unless you're busy picking)
    LaunchedEffect(vm.expectedCount) { if (vm.expectedCount > 0 && vm.picked.isEmpty()) tab = 0 }
    val active = vm.transfers.count { it.state == TState.RUNNING || it.state == TState.WAITING || it.state == TState.SAVING }
    val tabs = listOf(
        (if (active > 0) tr("Transfers $active", "منتقلی $active") else tr("Transfers", "منتقلی")) to emptyList<MediaItem>(),
        tr("Apps", "ایپس") to vm.apps, tr("Photos", "تصاویر") to vm.photos, tr("Videos", "ویڈیوز") to vm.videos, tr("Music", "گانے") to vm.music, tr("Files", "فائلیں") to vm.docs,
    )

    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        PeerHeader(vm) { if (vm.connected) askDisconnect = true else vm.goHome() }
        ScrollableTabRow(
            selectedTabIndex = tab,
            edgePadding = 12.dp,
            containerColor = Color.Transparent,
            divider = {},
        ) {
            tabs.forEachIndexed { i, (label, list) ->
                Tab(
                    selected = tab == i,
                    onClick = { tab = i },
                    text = {
                        Text(
                            if (i == 0 || list.isEmpty()) label else "$label ${list.size}",
                            fontWeight = if (tab == i) FontWeight.Bold else FontWeight.Normal,
                        )
                    },
                )
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            val list = tabs[tab].second
            when {
                tab == 0 -> TransfersPanel(vm)
                tab in 2..4 && !hasMedia -> MediaAccessCard { mediaPerm.launch(MEDIA_PERMS) }
                vm.loading && list.isEmpty() -> Box(Modifier.align(Alignment.Center)) { Spinner() }
                tab == 1 -> AppsGrid(vm, list)
                tab == 2 || tab == 3 -> MediaGrid(vm, list)
                tab == 4 -> ItemList(vm, list, null)
                else -> FilesTab(vm, list) { browse.launch(arrayOf("*/*")) }
            }
        }
        if (vm.picked.isNotEmpty()) {
            SelectionBar(vm, enabled = vm.connected) { vm.sendSelected(); tab = 0 }
        }
    }
    if (askDisconnect) {
        AlertDialog(
            onDismissRequest = { askDisconnect = false },
            title = { Text(tr("Disconnect?", "رابطہ ختم کریں؟")) },
            text = { Text(tr("You'll stop sharing with ${vm.peerName ?: "this phone"}. Files being sent will stop.", "${vm.peerName ?: "اس فون"} سے شیئرنگ بند ہو جائے گی۔ جاری فائلیں رک جائیں گی۔")) },
            confirmButton = { Button(onClick = { askDisconnect = false; vm.goHome() }) { Text(tr("Disconnect", "رابطہ ختم")) } },
            dismissButton = { TextButton(onClick = { askDisconnect = false }) { Text(tr("Stay", "رہنے دیں")) } },
        )
    }
}

@Composable
private fun PeerHeader(vm: ShareViewModel, onClose: () -> Unit) {
    val on = vm.connected
    val dot = if (on) Good else MaterialTheme.colorScheme.error
    Row(
        Modifier.fillMaxWidth().padding(start = 16.dp, end = 10.dp, top = 10.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box {
            Avatar(vm.peerName ?: "?", 44.dp)
            Box(
                Modifier.align(Alignment.BottomEnd).size(14.dp).clip(CircleShape)
                    .background(MaterialTheme.colorScheme.background).padding(2.dp).clip(CircleShape).background(dot)
            )
        }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(
                vm.peerName ?: tr("Nearby phone", "قریبی فون"),
                style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (on) {
                    Icon(
                        if (vm.link >= 2) Icons.Filled.Wifi else Icons.Filled.Bluetooth, null,
                        tint = if (vm.link == 3) Good else muted, modifier = Modifier.size(14.dp),
                    )
                    Spacer(Modifier.width(4.dp))
                }
                Text(
                    if (!on) tr("Disconnected", "رابطہ ختم ہو گیا")
                    else when (vm.link) {
                        3 -> tr("Connected, fast Wi-Fi", "جُڑا ہوا، تیز وائی فائی")
                        2 -> tr("Connected, Wi-Fi", "جُڑا ہوا، وائی فائی")
                        else -> tr("Connected, speeding up…", "جُڑا ہوا، رفتار بڑھ رہی ہے…")
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = if (on) muted else MaterialTheme.colorScheme.error,
                )
            }
        }
        Row(
            Modifier.clip(RoundedCornerShape(50))
                .border(1.dp, (if (on) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary).copy(alpha = 0.45f), RoundedCornerShape(50))
                .clickable(onClick = onClose).padding(horizontal = 12.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                if (on) Icons.Filled.LinkOff else Icons.Filled.Close, null,
                tint = if (on) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp),
            )
            Spacer(Modifier.width(6.dp))
            Text(
                if (on) tr("Disconnect", "رابطہ ختم") else tr("Close", "بند کریں"),
                style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold,
                color = if (on) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
            )
        }
    }
}

@Composable
private fun FolderAccessCard(
    title: String = tr("Give files their own folder", "فائلوں کا اپنا فولڈر"),
    desc: String = tr("Save received files in “Asan Share” on your phone, not inside Downloads.",
        "موصول فائلیں ڈاؤن لوڈز کے بجائے فون میں «Asan Share» فولڈر میں محفوظ ہوں۔"),
) {
    val ctx = LocalContext.current
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f))
            .padding(start = 14.dp, end = 8.dp, top = 12.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Folder, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(
                desc,
                style = MaterialTheme.typography.bodySmall, color = muted,
            )
        }
        Button(onClick = {
            val pkg = Uri.parse("package:" + ctx.packageName)
            runCatching {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }.onFailure {
                runCatching { ctx.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            }
        }, shape = RoundedCornerShape(16.dp)) { Text(tr("Allow", "اجازت دیں")) }
    }
}

/** Opens WhatsApp chat directly (WhatsApp or WhatsApp Business), web as last resort. */
private fun openWhatsApp(ctx: Context) {
    val uri = Uri.parse("https://wa.me/923032901193")
    for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
        val ok = runCatching {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }.isSuccess
        if (ok) return
    }
    runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}

@Composable
private fun MediaAccessCard(onAllow: () -> Unit) {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(tr("Allow access to your photos, videos and music", "اپنی تصاویر، ویڈیوز اور گانوں تک رسائی دیں"), fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
            style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(6.dp))
        Text(tr("Asan Share only reads them to show here. Nothing is uploaded.", "آسان شیئر انہیں صرف یہاں دکھانے کے لیے پڑھتا ہے۔ کچھ اپ لوڈ نہیں ہوتا۔"), color = muted, textAlign = TextAlign.Center)
        Spacer(Modifier.height(18.dp))
        Button(onClick = onAllow, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) { Text(tr("Allow", "اجازت دیں")) }
        TextButton(onClick = {
            runCatching {
                ctx.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }) { Text(tr("Open app settings", "ایپ کی سیٹنگز کھولیں")) }
    }
}

@Composable
private fun GridHeader(vm: ShareViewModel, list: List<MediaItem>, label: String) {
    val all = list.isNotEmpty() && list.all { vm.isSelected(it) }
    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = muted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
        if (list.isNotEmpty()) TextButton(onClick = { vm.selectAll(list, !all) }) { Text(if (all) tr("Unselect all", "سب ہٹائیں") else tr("Select all", "سب چنیں")) }
    }
}

@Composable
private fun EmptyNote(text: String) {
    Text(text, color = muted, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(32.dp))
}

@Composable
private fun AppsGrid(vm: ShareViewModel, list: List<MediaItem>) {
    val tick = rememberTick()
    LazyVerticalGrid(
        columns = GridCells.Adaptive(86.dp),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) { GridHeader(vm, list, tr("${list.size} apps", "${list.size} ایپس")) }
        if (list.isEmpty()) item(span = { GridItemSpan(maxLineSpan) }) { EmptyNote(tr("No apps found", "کوئی ایپ نہیں ملی")) }
        items(list.size, key = { list[it].key }) { idx ->
            val item = list[idx]
            val sel = vm.isSelected(item)
            Column(
                Modifier.clip(RoundedCornerShape(16.dp))
                    .background(if (sel) Saffron.copy(alpha = 0.2f) else Color.Transparent)
                    .clickable { tick(); vm.toggle(item) }
                    .padding(vertical = 10.dp, horizontal = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box {
                    Thumb(item, Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)), ContentScale.Fit)
                    if (sel) CheckDot(true, onImage = true, modifier = Modifier.align(Alignment.TopEnd).offset(x = 6.dp, y = (-6).dp))
                }
                Spacer(Modifier.height(6.dp))
                Text(item.name.removeSuffix(".apk"), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                Text(fmt(item.size), fontSize = 10.sp, color = muted)
            }
        }
    }
}

@Composable
private fun MediaGrid(vm: ShareViewModel, list: List<MediaItem>) {
    val tick = rememberTick()
    LazyVerticalGrid(
        columns = GridCells.Adaptive(104.dp),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) { GridHeader(vm, list, tr("${list.size} items", "${list.size} آئٹمز")) }
        if (list.isEmpty()) item(span = { GridItemSpan(maxLineSpan) }) { EmptyNote(tr("Nothing here yet", "یہاں ابھی کچھ نہیں")) }
        items(list.size, key = { list[it].key }) { idx ->
            val item = list[idx]
            val sel = vm.isSelected(item)
            Box(Modifier.aspectRatio(1f).clip(RoundedCornerShape(10.dp)).background(card).clickable { tick(); vm.toggle(item) }) {
                Thumb(item, Modifier.fillMaxSize(), ContentScale.Crop)
                if (item.kind == Kind.VIDEO && item.extra.isNotEmpty()) {
                    Text(
                        item.extra, color = Color.White, fontSize = 11.sp,
                        modifier = Modifier.align(Alignment.BottomEnd).padding(5.dp).clip(RoundedCornerShape(6.dp))
                            .background(Color.Black.copy(alpha = 0.55f)).padding(horizontal = 5.dp, vertical = 1.dp),
                    )
                }
                if (sel) Box(Modifier.fillMaxSize().background(Ink.copy(alpha = 0.35f)))
                CheckDot(sel, onImage = true, modifier = Modifier.align(Alignment.TopEnd).padding(6.dp))
            }
        }
    }
}

@Composable
private fun ItemList(vm: ShareViewModel, list: List<MediaItem>, onBrowse: (() -> Unit)?) {
    val tick = rememberTick()
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        if (onBrowse != null) item {
            OutlinedButton(
                onClick = onBrowse, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp),
            ) {
                Icon(Icons.Filled.Search, null)
                Spacer(Modifier.width(8.dp))
                Text(tr("Browse phone storage", "فون کی اسٹوریج دیکھیں"))
            }
        }
        item { GridHeader(vm, list, tr("${list.size} items", "${list.size} آئٹمز")) }
        if (list.isEmpty()) item {
            EmptyNote(if (onBrowse != null) tr("Use Browse phone storage to pick any file.", "کوئی بھی فائل چننے کے لیے «فون کی اسٹوریج دیکھیں» دبائیں۔") else tr("Nothing here yet", "یہاں ابھی کچھ نہیں"))
        }
        items(list, key = { it.key }) { item ->
            val sel = vm.isSelected(item)
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                    .background(if (sel) Saffron.copy(alpha = 0.18f) else card)
                    .clickable { tick(); vm.toggle(item) }.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (item.name.endsWith(".apk", ignoreCase = true) && item.path != null)
                    Thumb(item, Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)), ContentScale.Fit)
                else FileBadge(item.name)
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                    Text(
                        listOf(fmt(item.size), item.extra).filter { it.isNotEmpty() }.joinToString("   "),
                        style = MaterialTheme.typography.bodySmall, color = muted,
                    )
                }
                CheckDot(sel, onImage = false)
            }
        }
    }
}

@Composable
private fun SelectionBar(vm: ShareViewModel, enabled: Boolean, onSend: () -> Unit) {
    val total = vm.picked.sumOf { it.size }
    Row(
        Modifier.fillMaxWidth().padding(12.dp).clip(RoundedCornerShape(26.dp)).background(Ink)
            .padding(start = 20.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(tr("${vm.picked.size} selected", "${vm.picked.size} منتخب"), color = Color.White, fontWeight = FontWeight.Bold)
            Text(fmt(total), color = Color.White.copy(alpha = 0.75f), style = MaterialTheme.typography.bodySmall)
        }
        TextButton(onClick = vm::clearSelection) { Text(tr("Clear", "صاف کریں"), color = Color.White.copy(alpha = 0.8f)) }
        Button(
            onClick = onSend,
            enabled = enabled,
            colors = ButtonDefaults.buttonColors(containerColor = Saffron, contentColor = OnSaffron),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.height(50.dp),
        ) {
            Icon(Icons.AutoMirrored.Filled.Send, null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(tr("Send", "بھیجیں"), fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}

@Composable
private fun CheckDot(selected: Boolean, onImage: Boolean, modifier: Modifier = Modifier) {
    Box(
        modifier.size(24.dp).clip(CircleShape)
            .background(if (selected) Saffron else if (onImage) Color.Black.copy(alpha = 0.25f) else Color.Transparent)
            .border(2.dp, if (selected) Saffron else if (onImage) Color.White else muted, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        if (selected) Icon(Icons.Filled.Check, null, tint = Ink, modifier = Modifier.size(16.dp))
    }
}

@Composable
private fun Thumb(item: MediaItem, modifier: Modifier, scale: ContentScale) {
    val ctx = LocalContext.current
    val bmp: ImageBitmap? by produceState(Thumbs.cached(item.key), item.key) {
        if (value == null) value = Thumbs.load(ctx, item)
    }
    val b = bmp
    if (b != null) Image(b, null, modifier, contentScale = scale)
    else Box(modifier.background(card))
}


@Composable
private fun rememberTick(): () -> Unit {
    val haptic = LocalHapticFeedback.current
    return remember(haptic) { { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) } }
}

// ---------------- Received files ----------------

@Composable
private fun ReceivedScreen(vm: ShareViewModel) {
    BackHandler { vm.goHome() }
    val ctx = LocalContext.current
    var grid by rememberSaveable { mutableStateOf(true) }
    var filter by rememberSaveable { mutableIntStateOf(0) }
    val all = vm.received
    fun isApk(m: MediaItem) = m.name.endsWith(".apk", ignoreCase = true)
    val groups = listOf(
        tr("All", "سب") to all,
        tr("Photos", "تصاویر") to all.filter { it.kind == Kind.PHOTO },
        tr("Videos", "ویڈیوز") to all.filter { it.kind == Kind.VIDEO },
        tr("Apps", "ایپس") to all.filter { isApk(it) },
        tr("Other", "دیگر") to all.filter { it.kind == Kind.FILE && !isApk(it) },
    )
    val list = groups[filter].second

    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        // Top bar: back, title + count, grid/list switch
        Row(
            Modifier.fillMaxWidth().height(64.dp).padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = vm::goHome) { Icon(Icons.AutoMirrored.Filled.ArrowBack, tr("Back", "واپس")) }
            Column(Modifier.weight(1f)) {
                Text(tr("Received files", "موصول شدہ فائلیں"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(
                    tr("${all.size} files, ${fmt(all.sumOf { it.size })}", "${all.size} فائلیں، ${fmt(all.sumOf { it.size })}"),
                    style = MaterialTheme.typography.bodySmall, color = muted,
                )
            }
            IconButton(onClick = { grid = !grid }) {
                Icon(
                    if (grid) Icons.AutoMirrored.Filled.ViewList else Icons.Filled.GridView,
                    if (grid) tr("List view", "فہرست") else tr("Grid view", "گرڈ"),
                )
            }
        }
        // Filter chips
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
        ) {
            items(groups.size) { i ->
                val sel = filter == i
                val (label, items) = groups[i]
                Text(
                    "$label  ${items.size}",
                    fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium,
                    color = if (sel) Color.White else MaterialTheme.colorScheme.onSurface,
                    style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier.clip(RoundedCornerShape(50))
                        .background(if (sel) Ink else card)
                        .clickable { filter = i }
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                )
            }
        }

        if (list.isEmpty()) {
            Column(
                Modifier.fillMaxSize().padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Box(Modifier.size(84.dp).clip(CircleShape).background(card), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.Folder, null, tint = muted, modifier = Modifier.size(40.dp))
                }
                Spacer(Modifier.height(16.dp))
                Text(tr("No files yet", "ابھی کوئی فائل نہیں"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(tr("Files you receive will show up here.", "موصول ہونے والی فائلیں یہاں نظر آئیں گی۔"), color = muted, textAlign = TextAlign.Center)
            }
        } else if (grid) {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(108.dp),
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                items(list.size, key = { list[it].key }) { idx ->
                    val item = list[idx]
                    ReceivedTile(item, isApk(item)) { openFile(ctx, item.uri) }
                }
            }
        } else {
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(list, key = { it.key }) { item ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(card)
                            .clickable { openFile(ctx, item.uri) }.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        if (item.kind == Kind.PHOTO || item.kind == Kind.VIDEO || isApk(item))
                            Thumb(item, Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)), if (isApk(item)) ContentScale.Fit else ContentScale.Crop)
                        else FileBadge(item.name)
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                            Text(fmt(item.size), style = MaterialTheme.typography.bodySmall, color = muted)
                        }
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = muted)
                    }
                }
            }
        }
    }
}

/** One square in the grid: real preview for photos, videos and apps; a neat label for other files. */
@Composable
private fun ReceivedTile(item: MediaItem, apk: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.aspectRatio(1f).clip(RoundedCornerShape(14.dp)).background(card).clickable(onClick = onClick)
    ) {
        when {
            item.kind == Kind.PHOTO || item.kind == Kind.VIDEO ->
                Thumb(item, Modifier.fillMaxSize(), ContentScale.Crop)
            apk -> Box(Modifier.fillMaxSize().padding(bottom = 22.dp), contentAlignment = Alignment.Center) {
                Thumb(item, Modifier.size(56.dp).clip(RoundedCornerShape(14.dp)), ContentScale.Fit)
            }
            else -> Box(Modifier.fillMaxSize().padding(bottom = 22.dp), contentAlignment = Alignment.Center) { FileBadge(item.name) }
        }
        if (item.kind == Kind.VIDEO) {
            Box(
                Modifier.align(Alignment.Center).size(38.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.45f)),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Filled.PlayArrow, null, tint = Color.White, modifier = Modifier.size(24.dp)) }
        }
        if (item.kind != Kind.PHOTO) {
            Text(
                item.name,
                maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp,
                color = if (item.kind == Kind.VIDEO) Color.White else MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                    .background(
                        if (item.kind == Kind.VIDEO) Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.6f)))
                        else Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent))
                    )
                    .padding(horizontal = 6.dp, vertical = 5.dp),
            )
        }
    }
}

/** Files tab: every APK, PDF, Office, ZIP and design file, with quick categories. */
@Composable
private fun FilesTab(vm: ShareViewModel, list: List<MediaItem>, onBrowse: () -> Unit) {
    var sub by rememberSaveable { mutableIntStateOf(0) }
    fun ext(m: MediaItem) = m.name.substringAfterLast('.', "").lowercase()
    val urdu = Lang.urdu
    val groups = remember(list, urdu) { listOf(
        tr("All", "سب") to list,
        "APK" to list.filter { ext(it) in APK_EXTS },
        tr("Documents", "دستاویزات") to list.filter { ext(it) in DOC_EXTS },
        "ZIP" to list.filter { ext(it) in ARCHIVE_EXTS },
        tr("Design", "ڈیزائن") to list.filter { ext(it) in DESIGN_EXTS },
    ) }
    Column(Modifier.fillMaxSize()) {
        if (android.os.Build.VERSION.SDK_INT >= 30 && !vm.ownFolder) {
            Box(Modifier.padding(start = 12.dp, end = 12.dp, top = 8.dp)) {
                FolderAccessCard(
                    tr("See all your files", "اپنی تمام فائلیں دیکھیں"),
                    tr("Allow access to show every APK, PDF, ZIP and other file on this phone.",
                        "اس فون کی ہر APK، PDF، ZIP اور دوسری فائل دکھانے کے لیے اجازت دیں۔"),
                )
            }
        }
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(groups.size) { i ->
                val selected = sub == i
                Text(
                    "${groups[i].first}  ${groups[i].second.size}",
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                    color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface,
                    style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(if (selected) Ink else card)
                        .clickable { sub = i }.padding(horizontal = 14.dp, vertical = 8.dp),
                )
            }
        }
        Box(Modifier.weight(1f)) { ItemList(vm, groups[sub].second, onBrowse) }
    }
}

private fun urName(p: String) = when (p) {
    "Bluetooth" -> "بلوٹوتھ"
    "Wi-Fi" -> "وائی فائی"
    else -> "لوکیشن"
}
