package com.k2.share.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import com.k2.share.R
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.Phone
import com.k2.share.AppInvite
import com.k2.share.InviteServer
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.withFrameNanos
import androidx.compose.animation.core.Animatable
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import com.k2.share.Kind
import com.k2.share.MEDIA_PERMS
import com.k2.share.MediaItem
import com.k2.share.Thumbs
import com.k2.share.hasMediaAccess
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.k2.share.Device
import com.k2.share.SAVE_FOLDER
import com.k2.share.Screen
import com.k2.share.ShareViewModel
import com.k2.share.TState
import com.k2.share.Transfer
import com.k2.share.fmt

private val muted: Color @Composable get() = MaterialTheme.colorScheme.onSurfaceVariant
private val card: Color @Composable get() = MaterialTheme.colorScheme.surfaceVariant

@Composable
fun AppRoot(vm: ShareViewModel, granted: Boolean, onRequest: () -> Unit) {
    val view = LocalView.current
    val busy = vm.screen == Screen.CONNECTED
    DisposableEffect(busy) {
        view.keepScreenOn = busy // screen stays on during a transfer
        onDispose { view.keepScreenOn = false }
    }
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        if (!granted) PermissionScreen(onRequest)
        else AnimatedContent(
            targetState = vm.screen,
            transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(160)) },
            label = "nav",
        ) { s ->
            when (s) {
                Screen.HOME -> HomeScreen(vm)
                Screen.CONNECTED -> ConnectedScreen(vm)
                Screen.INVITE -> InviteScreen(vm)
                Screen.RECEIVED -> ReceivedScreen(vm)
            }
        }
    }
    vm.request?.let { r ->
        AlertDialog(
            onDismissRequest = {},
            icon = { Avatar(r.name, 64.dp) },
            title = { Text(r.name, textAlign = TextAlign.Center) },
            text = {
                Text(
                    "wants to connect with you to share files.", textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(), fontSize = 16.sp,
                )
            },
            confirmButton = {
                Button(onClick = vm::accept, modifier = Modifier.height(48.dp), shape = RoundedCornerShape(16.dp)) {
                    Text("Accept", fontSize = 16.sp)
                }
            },
            dismissButton = { TextButton(onClick = vm::decline) { Text("Decline") } },
        )
    }
    vm.connecting?.let { d ->
        AlertDialog(
            onDismissRequest = {},
            icon = { Avatar(d.name, 64.dp) },
            title = { Text("Connecting to ${d.name}", textAlign = TextAlign.Center) },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                    Spacer(Modifier.height(14.dp))
                    Text("Waiting for ${d.name} to tap Accept…", textAlign = TextAlign.Center, color = muted)
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = vm::cancelConnect) { Text("Cancel") } },
        )
    }
}

// ---------------- Permissions ----------------

@Composable
private fun PermissionScreen(onRequest: () -> Unit) {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(Modifier.size(96.dp).clip(CircleShape).background(Ink), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.LocationOn, null, tint = Saffron, modifier = Modifier.size(44.dp))
        }
        Spacer(Modifier.height(24.dp))
        Text("Allow nearby access", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Asan Share needs this to find phones near you and connect to them directly. Files never go through the internet.",
            textAlign = TextAlign.Center, color = muted,
        )
        Spacer(Modifier.height(28.dp))
        Button(onClick = onRequest, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(16.dp)) {
            Text("Allow", fontSize = 16.sp)
        }
        TextButton(onClick = {
            ctx.startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }) { Text("Open app settings") }
    }
}

// ---------------- Home: always visible + always searching (like Zapya) ----------------

@Composable
private fun HomeScreen(vm: ShareViewModel) {
    var renaming by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        vm.loadReceived()
        while (true) { vm.keepAlive(); delay(1200) }
    }
    val found = vm.devices.size
    Column(
        Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Logo(38.dp)
            Spacer(Modifier.width(10.dp))
            Text("Asan Share", fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        MyPhoneCard(vm.myName, visible = vm.problems.isEmpty() && !vm.failed) { renaming = true }
        Spacer(Modifier.height(16.dp))
        if (vm.reconnectName != null) {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Saffron.copy(alpha = 0.18f))
                    .padding(start = 16.dp, end = 6.dp, top = 12.dp, bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.5.dp, color = Saffron)
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text("Reconnecting to ${vm.reconnectName}…", fontWeight = FontWeight.Bold)
                    Text(
                        if (vm.resumeCount > 0) "${vm.resumeCount} unfinished files will continue automatically"
                        else "Keep Asan Share open on both phones",
                        style = MaterialTheme.typography.bodySmall, color = muted,
                    )
                }
                TextButton(onClick = vm::cancelReconnect) { Text("Cancel") }
            }
            Spacer(Modifier.height(14.dp))
        }

        if (vm.picked.isNotEmpty() && vm.reconnectName == null) {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Ink).padding(start = 16.dp, end = 6.dp, top = 12.dp, bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.Send, null, tint = Saffron)
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text("${vm.picked.size} files ready", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("Tap a phone below to send them", color = Color.White.copy(alpha = 0.75f), style = MaterialTheme.typography.bodySmall)
                }
                TextButton(onClick = vm::clearSelection) { Text("Clear", color = Saffron) }
            }
            Spacer(Modifier.height(14.dp))
        }

        val blocked = vm.problems.isNotEmpty() || vm.failed
        if (!blocked) {
            Text(
                if (found == 0) "Looking for phones…" else "Tap a phone to connect",
                fontSize = 24.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                if (found == 0) "Open Asan Share on the other phone.\nIt will show up here by itself."
                else if (found == 1) "1 phone nearby" else "$found phones nearby",
                color = muted, textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(4.dp))
            Radar(vm)
        } else {
            FixItCard(vm)
        }
        if (vm.status.isNotEmpty() && !vm.failed) {
            Text(
                vm.status, color = MaterialTheme.colorScheme.primary, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            )
        }

        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ActionCard(
                Icons.Filled.Download, "Received files",
                if (vm.received.isEmpty()) "Nothing yet" else "${vm.received.size} files",
                Saffron, OnSaffron, Modifier.weight(1f).fillMaxHeight(), vm::openReceived,
            )
            ActionCard(
                Icons.Filled.PersonAdd, "Friend has no app?",
                "Send Asan Share to them",
                Ink, Color.White, Modifier.weight(1f).fillMaxHeight(), vm::openInvite,
            )
        }
        Spacer(Modifier.height(10.dp))
        Spacer(Modifier.height(18.dp))
        DeveloperCredit()
    }
    if (renaming) {
        var text by remember { mutableStateOf(vm.myName) }
        AlertDialog(
            onDismissRequest = { renaming = false },
            title = { Text("Your phone's name") },
            text = {
                Column {
                    Text("Other phones will see this name.", color = muted)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = text, onValueChange = { text = it.take(30) }, singleLine = true)
                }
            },
            confirmButton = { Button(onClick = { vm.rename(text); renaming = false }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { renaming = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun ActionCard(
    icon: ImageVector, title: String, subtitle: String,
    accent: Color, onAccent: Color, modifier: Modifier, onClick: () -> Unit,
) {
    Column(
        modifier.clip(RoundedCornerShape(24.dp)).background(card).clickable(onClick = onClick).padding(16.dp)
    ) {
        Box(Modifier.size(46.dp).clip(RoundedCornerShape(15.dp)).background(accent), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = onAccent)
        }
        Spacer(Modifier.height(12.dp))
        Text(title, fontWeight = FontWeight.Bold)
        Text(subtitle, style = MaterialTheme.typography.bodySmall, color = muted)
    }
}

@Composable
private fun MyPhoneCard(name: String, visible: Boolean, onEdit: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(card)
            .border(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f), RoundedCornerShape(22.dp))
            .clickable(onClick = onEdit).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box {
            Avatar(name, 46.dp)
            Box(
                Modifier.align(Alignment.BottomEnd).size(14.dp).clip(CircleShape).background(card).padding(2.dp)
                    .clip(CircleShape).background(if (visible) Good else MaterialTheme.colorScheme.error)
            )
        }
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Text(
                if (visible) "Visible to nearby phones" else "Not visible right now",
                style = MaterialTheme.typography.labelMedium,
                color = if (visible) Good else MaterialTheme.colorScheme.error,
            )
            Text(name, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Box(
            Modifier.size(38.dp).clip(CircleShape).background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f)),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Filled.Edit, "Change name", tint = muted, modifier = Modifier.size(18.dp)) }
    }
}

@Composable
private fun DeveloperCredit() {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Developed by", style = MaterialTheme.typography.labelSmall, color = muted)
        Text("JAVED IQBAL", fontWeight = FontWeight.Black, letterSpacing = 1.5.sp, style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(8.dp))
        Row(
            Modifier.clip(RoundedCornerShape(50)).background(Color(0xFF25D366).copy(alpha = 0.14f)).clickable {
                runCatching {
                    ctx.startActivity(
                        Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/923032901193")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            }.padding(start = 6.dp, end = 14.dp, top = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            WhatsAppIcon(26.dp)
            Spacer(Modifier.width(8.dp))
            Text("0303 2901193", fontWeight = FontWeight.Bold, color = Color(0xFF1FAF55))
        }
    }
}

/** WhatsApp-style mark: green chat bubble with a white phone. */
@Composable
private fun WhatsAppIcon(size: Dp) {
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = this.size.width
            val green = Color(0xFF25D366)
            drawCircle(green, radius = w * 0.44f, center = Offset(w * 0.52f, w * 0.46f))
            val tail = Path().apply {
                moveTo(w * 0.18f, w * 0.62f); lineTo(w * 0.08f, w * 0.95f); lineTo(w * 0.40f, w * 0.84f); close()
            }
            drawPath(tail, green)
            drawCircle(Color.White, radius = w * 0.34f, center = Offset(w * 0.52f, w * 0.46f), style = Stroke(width = w * 0.07f))
        }
        Icon(Icons.Filled.Phone, null, tint = Color.White, modifier = Modifier.size(size * 0.40f).offset(x = size * 0.02f, y = (-0.02f * size.value).dp))
    }
}

@Composable
private fun DeviceRow(d: Device, enabled: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().alpha(if (enabled) 1f else 0.5f).clip(RoundedCornerShape(20.dp)).background(card)
            .clickable(enabled = enabled, onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Avatar(d.name, 48.dp)
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Text(d.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                "Tap to connect",
                style = MaterialTheme.typography.bodySmall, color = muted,
            )
        }
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = muted)
    }
}

@Composable
private fun Logo(size: Dp) {
    Image(painterResource(R.drawable.app_logo), "Asan Share", Modifier.size(size))
}

@Composable
private fun InviteScreen(vm: ShareViewModel) {
    val ctx = LocalContext.current
    var wifiMode by remember { mutableStateOf(false) }
    BackHandler { if (wifiMode) wifiMode = false else vm.goHome() }
    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        TopBar(if (wifiMode) "Download over Wi-Fi" else "Send the app to a friend") { if (wifiMode) wifiMode = false else vm.goHome() }
        if (wifiMode) {
            WifiInvite()
        } else {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text("Your friend doesn't need internet. Pick one way:", color = muted)
                InviteOption(Icons.Filled.Bluetooth, "Send by Bluetooth", "Works on every phone. Takes about a minute.", Ink, Color.White) {
                    AppInvite.sendByBluetooth(ctx)
                }
                InviteOption(Icons.Filled.Wifi, "Download over Wi-Fi", "Fastest. Your friend scans 2 codes with the camera.", Saffron, OnSaffron) {
                    wifiMode = true
                }
                InviteOption(Icons.Filled.Share, "Quick Share, WhatsApp and more", "Use any sharing app on your phone.", card, MaterialTheme.colorScheme.onSurface) {
                    AppInvite.shareAnyWay(ctx)
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    "When it arrives, your friend taps the file, then Install. The phone may ask to allow installing from this source. That's normal.",
                    style = MaterialTheme.typography.bodySmall, color = muted,
                )
            }
        }
    }
}

@Composable
private fun InviteOption(icon: ImageVector, title: String, desc: String, accent: Color, onAccent: Color, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(card).clickable(onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(54.dp).clip(RoundedCornerShape(17.dp)).background(accent), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = onAccent, modifier = Modifier.size(28.dp))
        }
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text(desc, style = MaterialTheme.typography.bodySmall, color = muted)
        }
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = muted)
    }
}

@Composable
private fun WifiInvite() {
    val ctx = LocalContext.current
    val server = remember { InviteServer(ctx.applicationContext) }
    var ssid by remember { mutableStateOf<String?>(null) }
    var pass by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var ip by remember { mutableStateOf<String?>(null) }
    DisposableEffect(Unit) {
        server.startWeb()
        server.startHotspot({ s, p -> ssid = s; pass = p }, { error = it })
        onDispose { server.stop() }
    }
    LaunchedEffect(ssid, error) {
        repeat(30) {
            ip = AppInvite.localIp()
            if (ip != null && (ssid != null || error != null)) return@LaunchedEffect
            delay(500)
        }
    }
    val url = ip?.let { "http://$it:${server.port}" }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        when {
            error != null -> {
                Text(error!!, color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center)
                if (url != null) StepCard(1, "Same Wi-Fi? Open this", "If both phones are on the same Wi-Fi, scan this with your friend's camera.", url, url)
            }
            ssid == null || url == null -> {
                Spacer(Modifier.height(40.dp))
                CircularProgressIndicator()
                Text("Starting Wi-Fi…", color = muted)
            }
            else -> {
                StepCard(
                    1, "Join this Wi-Fi",
                    "On your friend's phone, open the Camera and point it at this code. Tap the Wi-Fi message to join.",
                    AppInvite.wifiQrText(ssid!!, pass ?: ""),
                    "Wi-Fi: $ssid\nPassword: $pass",
                )
                StepCard(
                    2, "Download the app",
                    "Now point the camera at this code and open the link. Tap Download the app.",
                    url, url,
                )
            }
        }
    }
}

@Composable
private fun StepCard(n: Int, title: String, desc: String, qrText: String, caption: String) {
    val img = remember(qrText) { AppInvite.qr(qrText) }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(card).padding(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(34.dp).clip(CircleShape).background(Ink), contentAlignment = Alignment.Center) {
                Text("$n", color = Saffron, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.width(12.dp))
            Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        Spacer(Modifier.height(8.dp))
        Text(desc, color = muted, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(14.dp))
        if (img != null) {
            Image(
                img, "QR code",
                Modifier.size(230.dp).clip(RoundedCornerShape(16.dp)).background(Color.White).padding(10.dp),
            )
        }
        Spacer(Modifier.height(10.dp))
        Text(caption, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
    }
}

// ---------------- Transfer progress ----------------

@Composable
private fun TransfersPanel(vm: ShareViewModel) {
    val ctx = LocalContext.current
    val list = vm.transfers
    val total = maxOf(vm.expectedBytes, list.sumOf { it.size })
    val done = list.sumOf { it.done }
    val count = maxOf(vm.expectedCount, list.size)
    val doneCount = list.count { it.state == TState.DONE }
    val finished = list.isNotEmpty() && list.size >= count && list.all { it.state == TState.DONE || it.state == TState.FAILED }
    val speed = list.filter { it.state == TState.RUNNING }.sumOf { it.speed }
    val progress by animateFloatAsState(
        if (total > 0) (done.toFloat() / total).coerceIn(0f, 1f) else 0f, label = "progress",
    )
    if (list.isEmpty()) {
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Pulse(MaterialTheme.colorScheme.primary, 170.dp) {
                Box(Modifier.size(64.dp).clip(CircleShape).background(Ink), contentAlignment = Alignment.Center) {
                    Icon(Icons.AutoMirrored.Filled.Send, null, tint = Saffron, modifier = Modifier.size(28.dp))
                }
            }
            Spacer(Modifier.height(14.dp))
            Text("You're connected", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(
                "Pick photos, videos, apps or files from the tabs above and tap Send. Files from ${vm.peerName ?: "the other phone"} will show up here too.",
                color = muted, textAlign = TextAlign.Center,
            )
        }
        return
    }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(card).padding(20.dp)
            ) {
                Text(
                    if (finished) "All done" else "${(progress * 100).toInt()}%",
                    fontSize = 40.sp, fontWeight = FontWeight.Black,
                )
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth().height(8.dp),
                    color = if (finished) Good else MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.15f),
                    strokeCap = StrokeCap.Round,
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    buildString {
                        append("$doneCount of $count files   ${fmt(done)} of ${fmt(total)}")
                        if (speed > 0 && !finished) append("   ${fmt(speed.toLong())}/s")
                    },
                    color = muted, style = MaterialTheme.typography.bodySmall,
                )
            }
        }
        items(list.asReversed(), key = { it.id }) { t -> TransferRow(t) { t.saved?.let { openFile(ctx, it) } } }
    }
}

@Composable
private fun TransferRow(t: Transfer, onOpen: () -> Unit) {
    val p = if (t.size > 0) (t.done.toFloat() / t.size).coerceIn(0f, 1f) else 0f
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(card)
            .clickable(enabled = t.saved != null, onClick = onOpen).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        FileBadge(t.name)
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(t.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
            if (t.state == TState.RUNNING || t.state == TState.WAITING) {
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { p }, modifier = Modifier.fillMaxWidth(), strokeCap = StrokeCap.Round,
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(
                when (t.state) {
                    TState.WAITING -> "Waiting…"
                    TState.RUNNING -> (if (t.incoming) "Receiving " else "Sending ") + "${fmt(t.done)} of ${fmt(t.size)}"
                    TState.SAVING -> "Saving…"
                    TState.DONE -> if (t.incoming) "Received ${fmt(t.size)}, tap to open" else "Sent ${fmt(t.size)}"
                    TState.FAILED -> "Didn't arrive. Send it again."
                },
                style = MaterialTheme.typography.bodySmall, color = muted,
            )
        }
        when (t.state) {
            TState.DONE -> Icon(Icons.Filled.CheckCircle, "Done", tint = Good)
            TState.FAILED -> Icon(Icons.Filled.Warning, "Failed", tint = MaterialTheme.colorScheme.error)
            else -> {}
        }
    }
}

@Composable
private fun FixItCard(vm: ShareViewModel) {
    val ctx = LocalContext.current
    fun open(action: String) {
        runCatching { ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(card).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(Icons.Filled.Warning, null, tint = Saffron, modifier = Modifier.size(36.dp))
        Spacer(Modifier.height(10.dp))
        if (vm.problems.isNotEmpty()) {
            Text("Turn on ${vm.problems.joinToString(" and ")}", fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Spacer(Modifier.height(4.dp))
            Text("Asan Share starts by itself once it's on.", color = muted, textAlign = TextAlign.Center)
            Spacer(Modifier.height(14.dp))
            for (p in vm.problems) {
                OutlinedButton(
                    onClick = {
                        open(
                            when (p) {
                                "Bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                                "Wi-Fi" -> Settings.ACTION_WIFI_SETTINGS
                                else -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
                            }
                        )
                    },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).height(50.dp),
                    shape = RoundedCornerShape(16.dp),
                ) { Text("Open $p settings") }
            }
        } else {
            Text(vm.status, textAlign = TextAlign.Center)
            Spacer(Modifier.height(14.dp))
            Button(
                onClick = vm::retry, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp),
            ) { Text("Try again", fontSize = 16.sp) }
            TextButton(onClick = {
                runCatching {
                    ctx.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            }) { Text("Open app permissions") }
        }
    }
}

// ---------------- Small pieces ----------------

@Composable
private fun TopBar(title: String, onBack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SectionTitle(title: String, trailing: String?) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (trailing != null) Text(trailing, style = MaterialTheme.typography.bodySmall, color = muted)
    }
}

private val avatarColors = listOf(0xFF1F2A6B, 0xFF0E8C7F, 0xFFC2410C, 0xFF9D174D, 0xFF4338CA, 0xFF15803D).map { Color(it) }

@Composable
private fun Avatar(name: String, size: Dp) {
    val c = avatarColors[(name.hashCode() and 0x7fffffff) % avatarColors.size]
    val light = Color(
        red = (c.red + (1f - c.red) * 0.35f), green = (c.green + (1f - c.green) * 0.35f), blue = (c.blue + (1f - c.blue) * 0.35f),
    )
    Box(
        Modifier.size(size).clip(CircleShape).background(Brush.linearGradient(listOf(light, c))),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            name.trim().take(1).uppercase().ifEmpty { "?" },
            color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.42f).sp,
        )
    }
}

@Composable
private fun FileBadge(name: String) {
    val ext = name.substringAfterLast('.', "").lowercase()
    val (label, color) = when (ext) {
        "jpg", "jpeg", "png", "gif", "webp", "heic" -> "IMG" to Color(0xFFDB2777)
        "mp4", "mkv", "mov", "avi", "3gp", "webm" -> "VID" to Color(0xFFEA580C)
        "mp3", "m4a", "wav", "aac", "ogg", "opus" -> "AUD" to Color(0xFF7C3AED)
        "apk" -> "APK" to Color(0xFF16A34A)
        "pdf" -> "PDF" to Color(0xFFDC2626)
        "zip", "rar", "7z" -> "ZIP" to Color(0xFF92400E)
        "dst", "emb", "pes", "jef", "exp", "dsb" -> "EMB" to Color(0xFF0E8C7F)
        else -> ext.take(4).uppercase().ifEmpty { "FILE" } to Color(0xFF4F5BD5)
    }
    Box(
        Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(color.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = color, fontWeight = FontWeight.Bold, fontSize = 11.sp) }
}

/**
 * A 0..1 value that loops forever. Driven by the screen's frame clock, so it keeps moving
 * even on phones where "animations" are switched off in settings or by battery saver.
 */
@Composable
private fun rememberLoopPhase(periodMs: Int): State<Float> {
    val phase = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(periodMs) {
        val start = withFrameNanos { it }
        while (true) {
            withFrameNanos { t -> phase.floatValue = (((t - start) / 1_000_000L) % periodMs) / periodMs.toFloat() }
        }
    }
    return phase
}

@Composable
private fun Pulse(color: Color, size: Dp, content: @Composable () -> Unit) {
    val phase = rememberLoopPhase(2400)
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = this.size.minDimension / 2f
            val p = phase.value
            for (i in 0 until 3) {
                val f = (p + i / 3f) % 1f
                drawCircle(color.copy(alpha = (1f - f) * 0.28f), radius = r * (0.3f + 0.7f * f))
            }
        }
        content()
    }
}

@Composable
private fun Radar(vm: ShareViewModel) {
    val phase = rememberLoopPhase(2600)
    val primary = MaterialTheme.colorScheme.primary
    val ring = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.2f)
    val surface = MaterialTheme.colorScheme.background
    BoxWithConstraints(
        Modifier.widthIn(max = 360.dp).fillMaxWidth().aspectRatio(1f),
        contentAlignment = Alignment.Center,
    ) {
        val half = maxWidth / 2
        Canvas(Modifier.fillMaxSize()) {
            val r = this.size.minDimension / 2f
            val p = phase.value
            for (i in 1..3) drawCircle(ring, radius = r * i / 3f, style = Stroke(width = 1.dp.toPx()))
            drawCircle(primary.copy(alpha = (1f - p) * 0.18f), radius = r * p)
            rotate(p * 360f) {
                drawArc(
                    brush = Brush.sweepGradient(
                        0f to Color.Transparent,
                        0.18f to primary.copy(alpha = 0.32f),
                        0.181f to Color.Transparent,
                        center = center,
                    ),
                    startAngle = 0f, sweepAngle = 65f, useCenter = true,
                    topLeft = Offset(center.x - r, center.y - r),
                    size = androidx.compose.ui.geometry.Size(r * 2, r * 2),
                )
            }
        }
        Box(Modifier.size(70.dp).clip(CircleShape).background(surface).padding(4.dp)) { Avatar(vm.myName, 62.dp) }
        val list = vm.devices
        list.forEachIndexed { i, d ->
            val angle = Math.toRadians(-90.0 + 40.0 + i * 360.0 / list.size)
            val dist = half * 0.68f
            DeviceBubble(
                d,
                Modifier.offset(x = dist * cos(angle).toFloat(), y = dist * sin(angle).toFloat()),
            ) { vm.connect(d) }
        }
    }
}

@Composable
private fun DeviceBubble(d: Device, modifier: Modifier, onClick: () -> Unit) {
    val pop = remember { Animatable(0.6f) }
    LaunchedEffect(d.id) { pop.animateTo(1f, tween(260)) }
    Column(
        modifier.scale(pop.value).width(96.dp).clip(RoundedCornerShape(18.dp)).clickable(onClick = onClick).padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(62.dp).clip(CircleShape).background(Saffron).padding(3.dp)) { Avatar(d.name, 56.dp) }
        Spacer(Modifier.height(4.dp))
        Text(d.name, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
    }
}

private fun openFile(ctx: Context, uri: Uri) {
    val type = ctx.contentResolver.getType(uri) ?: "*/*"
    val view = Intent(Intent.ACTION_VIEW).setDataAndType(uri, type)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    runCatching {
        ctx.startActivity(Intent.createChooser(view, "Open with").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}


// ---------------- Pick files (Zapya-style tabs) ----------------

@Composable
private fun ConnectedScreen(vm: ShareViewModel) {
    val ctx = LocalContext.current
    var askDisconnect by remember { mutableStateOf(false) }
    BackHandler { if (vm.connected) askDisconnect = true else vm.goHome() }
    var hasMedia by remember { mutableStateOf(hasMediaAccess(ctx)) }
    val mediaPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        hasMedia = hasMediaAccess(ctx)
        vm.loadLibrary(hasMedia)
    }
    val browse = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.addFiles(it) }
    LaunchedEffect(Unit) {
        vm.loadLibrary(hasMedia)
        if (!hasMedia) mediaPerm.launch(MEDIA_PERMS)
    }
    var tab by rememberSaveable { mutableIntStateOf(if (vm.transfers.isNotEmpty()) 0 else 2) }
    // jump to Transfers when the other phone starts sending (unless you're busy picking)
    LaunchedEffect(vm.expectedCount) { if (vm.expectedCount > 0 && vm.picked.isEmpty()) tab = 0 }
    val active = vm.transfers.count { it.state == TState.RUNNING || it.state == TState.WAITING || it.state == TState.SAVING }
    val tabs = listOf(
        (if (active > 0) "Transfers $active" else "Transfers") to emptyList<MediaItem>(),
        "Apps" to vm.apps, "Photos" to vm.photos, "Videos" to vm.videos, "Music" to vm.music, "Files" to vm.docs,
    )

    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        PeerHeader(vm) { if (vm.connected) askDisconnect = true else vm.goHome() }
        ScrollableTabRow(
            selectedTabIndex = tab,
            edgePadding = 12.dp,
            containerColor = Color.Transparent,
            divider = {},
        ) {
            tabs.forEachIndexed { i, (label, list) ->
                Tab(
                    selected = tab == i,
                    onClick = { tab = i },
                    text = {
                        Text(
                            if (i == 0 || list.isEmpty()) label else "$label ${list.size}",
                            fontWeight = if (tab == i) FontWeight.Bold else FontWeight.Normal,
                        )
                    },
                )
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            val list = tabs[tab].second
            when {
                tab == 0 -> TransfersPanel(vm)
                tab in 2..4 && !hasMedia -> MediaAccessCard { mediaPerm.launch(MEDIA_PERMS) }
                vm.loading && list.isEmpty() -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                tab == 1 -> AppsGrid(vm, list)
                tab == 2 || tab == 3 -> MediaGrid(vm, list)
                tab == 4 -> ItemList(vm, list, null)
                else -> ItemList(vm, list) { browse.launch(arrayOf("*/*")) }
            }
        }
        if (vm.picked.isNotEmpty()) {
            SelectionBar(vm, enabled = vm.connected) { vm.sendSelected(); tab = 0 }
        }
    }
    if (askDisconnect) {
        AlertDialog(
            onDismissRequest = { askDisconnect = false },
            title = { Text("Disconnect?") },
            text = { Text("You'll stop sharing with ${vm.peerName ?: "this phone"}. Files being sent will stop.") },
            confirmButton = { Button(onClick = { askDisconnect = false; vm.goHome() }) { Text("Disconnect") } },
            dismissButton = { TextButton(onClick = { askDisconnect = false }) { Text("Stay") } },
        )
    }
}

@Composable
private fun PeerHeader(vm: ShareViewModel, onClose: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(12.dp).clip(RoundedCornerShape(24.dp)).background(Ink).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(50.dp).clip(CircleShape).background(if (vm.connected) Saffron else Color.Gray).padding(3.dp)) {
            Avatar(vm.peerName ?: "?", 44.dp)
        }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(
                vm.peerName ?: "Nearby phone", color = Color.White, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Text(
                if (!vm.connected) "Disconnected"
                else when (vm.link) {
                    3 -> "Connected, fast Wi-Fi"
                    2 -> "Connected, Wi-Fi"
                    else -> "Connected, speeding up…"
                },
                color = if (vm.connected) Color.White.copy(alpha = 0.75f) else Saffron,
                style = MaterialTheme.typography.bodySmall,
            )
        }
        TextButton(onClick = onClose) {
            Text(if (vm.connected) "Disconnect" else "Close", color = Saffron, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun MediaAccessCard(onAllow: () -> Unit) {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text("Allow access to your photos, videos and music", fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
            style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(6.dp))
        Text("Asan Share only reads them to show here. Nothing is uploaded.", color = muted, textAlign = TextAlign.Center)
        Spacer(Modifier.height(18.dp))
        Button(onClick = onAllow, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) { Text("Allow") }
        TextButton(onClick = {
            runCatching {
                ctx.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }) { Text("Open app settings") }
    }
}

@Composable
private fun GridHeader(vm: ShareViewModel, list: List<MediaItem>, label: String) {
    val all = list.isNotEmpty() && list.all { vm.isSelected(it) }
    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = muted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
        if (list.isNotEmpty()) TextButton(onClick = { vm.selectAll(list, !all) }) { Text(if (all) "Unselect all" else "Select all") }
    }
}

@Composable
private fun EmptyNote(text: String) {
    Text(text, color = muted, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(32.dp))
}

@Composable
private fun AppsGrid(vm: ShareViewModel, list: List<MediaItem>) {
    val tick = rememberTick()
    LazyVerticalGrid(
        columns = GridCells.Adaptive(86.dp),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) { GridHeader(vm, list, "${list.size} apps") }
        if (list.isEmpty()) item(span = { GridItemSpan(maxLineSpan) }) { EmptyNote("No apps found") }
        items(list.size, key = { list[it].key }) { idx ->
            val item = list[idx]
            val sel = vm.isSelected(item)
            Column(
                Modifier.clip(RoundedCornerShape(16.dp))
                    .background(if (sel) Saffron.copy(alpha = 0.2f) else Color.Transparent)
                    .clickable { tick(); vm.toggle(item) }
                    .padding(vertical = 10.dp, horizontal = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box {
                    Thumb(item, Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)), ContentScale.Fit)
                    if (sel) CheckDot(true, onImage = true, modifier = Modifier.align(Alignment.TopEnd).offset(x = 6.dp, y = (-6).dp))
                }
                Spacer(Modifier.height(6.dp))
                Text(item.name.removeSuffix(".apk"), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                Text(fmt(item.size), fontSize = 10.sp, color = muted)
            }
        }
    }
}

@Composable
private fun MediaGrid(vm: ShareViewModel, list: List<MediaItem>) {
    val tick = rememberTick()
    LazyVerticalGrid(
        columns = GridCells.Adaptive(104.dp),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) { GridHeader(vm, list, "${list.size} items") }
        if (list.isEmpty()) item(span = { GridItemSpan(maxLineSpan) }) { EmptyNote("Nothing here yet") }
        items(list.size, key = { list[it].key }) { idx ->
            val item = list[idx]
            val sel = vm.isSelected(item)
            Box(Modifier.aspectRatio(1f).clip(RoundedCornerShape(10.dp)).background(card).clickable { tick(); vm.toggle(item) }) {
                Thumb(item, Modifier.fillMaxSize(), ContentScale.Crop)
                if (item.kind == Kind.VIDEO && item.extra.isNotEmpty()) {
                    Text(
                        item.extra, color = Color.White, fontSize = 11.sp,
                        modifier = Modifier.align(Alignment.BottomEnd).padding(5.dp).clip(RoundedCornerShape(6.dp))
                            .background(Color.Black.copy(alpha = 0.55f)).padding(horizontal = 5.dp, vertical = 1.dp),
                    )
                }
                if (sel) Box(Modifier.fillMaxSize().background(Ink.copy(alpha = 0.35f)))
                CheckDot(sel, onImage = true, modifier = Modifier.align(Alignment.TopEnd).padding(6.dp))
            }
        }
    }
}

@Composable
private fun ItemList(vm: ShareViewModel, list: List<MediaItem>, onBrowse: (() -> Unit)?) {
    val tick = rememberTick()
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        if (onBrowse != null) item {
            OutlinedButton(
                onClick = onBrowse, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp),
            ) {
                Icon(Icons.Filled.Search, null)
                Spacer(Modifier.width(8.dp))
                Text("Browse phone storage")
            }
        }
        item { GridHeader(vm, list, "${list.size} items") }
        if (list.isEmpty()) item {
            EmptyNote(if (onBrowse != null) "Use Browse phone storage to pick any file." else "Nothing here yet")
        }
        items(list, key = { it.key }) { item ->
            val sel = vm.isSelected(item)
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                    .background(if (sel) Saffron.copy(alpha = 0.18f) else card)
                    .clickable { tick(); vm.toggle(item) }.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                FileBadge(item.name)
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                    Text(
                        listOf(fmt(item.size), item.extra).filter { it.isNotEmpty() }.joinToString("   "),
                        style = MaterialTheme.typography.bodySmall, color = muted,
                    )
                }
                CheckDot(sel, onImage = false)
            }
        }
    }
}

@Composable
private fun SelectionBar(vm: ShareViewModel, enabled: Boolean, onSend: () -> Unit) {
    val total = vm.picked.sumOf { it.size }
    Row(
        Modifier.fillMaxWidth().padding(12.dp).clip(RoundedCornerShape(26.dp)).background(Ink)
            .padding(start = 20.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text("${vm.picked.size} selected", color = Color.White, fontWeight = FontWeight.Bold)
            Text(fmt(total), color = Color.White.copy(alpha = 0.75f), style = MaterialTheme.typography.bodySmall)
        }
        TextButton(onClick = vm::clearSelection) { Text("Clear", color = Color.White.copy(alpha = 0.8f)) }
        Button(
            onClick = onSend,
            enabled = enabled,
            colors = ButtonDefaults.buttonColors(containerColor = Saffron, contentColor = OnSaffron),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.height(50.dp),
        ) {
            Icon(Icons.AutoMirrored.Filled.Send, null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("Send", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}

@Composable
private fun CheckDot(selected: Boolean, onImage: Boolean, modifier: Modifier = Modifier) {
    Box(
        modifier.size(24.dp).clip(CircleShape)
            .background(if (selected) Saffron else if (onImage) Color.Black.copy(alpha = 0.25f) else Color.Transparent)
            .border(2.dp, if (selected) Saffron else if (onImage) Color.White else muted, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        if (selected) Icon(Icons.Filled.Check, null, tint = Ink, modifier = Modifier.size(16.dp))
    }
}

@Composable
private fun Thumb(item: MediaItem, modifier: Modifier, scale: ContentScale) {
    val ctx = LocalContext.current
    val bmp: ImageBitmap? by produceState(Thumbs.cached(item.key), item.key) {
        if (value == null) value = Thumbs.load(ctx, item)
    }
    val b = bmp
    if (b != null) Image(b, null, modifier, contentScale = scale)
    else Box(modifier.background(card))
}


@Composable
private fun rememberTick(): () -> Unit {
    val haptic = LocalHapticFeedback.current
    return remember(haptic) { { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) } }
}

// ---------------- Received files ----------------

@Composable
private fun ReceivedScreen(vm: ShareViewModel) {
    BackHandler { vm.goHome() }
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        TopBar("Received files", vm::goHome)
        if (vm.received.isEmpty()) {
            Column(
                Modifier.fillMaxSize().padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Pulse(Saffron, 180.dp) {
                    Box(Modifier.size(72.dp).clip(CircleShape).background(Saffron), contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.KeyboardArrowDown, null, tint = Ink, modifier = Modifier.size(40.dp))
                    }
                }
                Spacer(Modifier.height(16.dp))
                Text("No files yet", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Files you receive will show up here.", color = muted, textAlign = TextAlign.Center)
            }
        } else {
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                item {
                    Text(
                        "Saved in Downloads/$SAVE_FOLDER", style = MaterialTheme.typography.bodySmall, color = muted,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp),
                    )
                }
                items(vm.received, key = { it.key }) { item ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(card)
                            .clickable { openFile(ctx, item.uri) }.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        if (item.kind == Kind.PHOTO || item.kind == Kind.VIDEO)
                            Thumb(item, Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)), ContentScale.Crop)
                        else FileBadge(item.name)
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                            Text(fmt(item.size), style = MaterialTheme.typography.bodySmall, color = muted)
                        }
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = muted)
                    }
                }
            }
        }
    }
}
