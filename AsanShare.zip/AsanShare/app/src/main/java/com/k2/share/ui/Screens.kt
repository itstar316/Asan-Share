package com.k2.share.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Home
import androidx.compose.foundation.horizontalScroll
import androidx.compose.ui.draw.shadow
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.LocalContentColor
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.drawBehind
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.foundation.combinedClickable
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material.icons.automirrored.filled.ViewList
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.LinkOff
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.k2.share.Lang
import com.k2.share.tr
import androidx.compose.ui.res.painterResource
import com.k2.share.R
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.Phone
import com.k2.share.AppInvite
import com.k2.share.InviteServer
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.withFrameNanos
import androidx.compose.animation.core.Animatable
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import com.k2.share.Kind
import com.k2.share.APK_EXTS
import com.k2.share.ARCHIVE_EXTS
import com.k2.share.DESIGN_EXTS
import com.k2.share.DOC_EXTS
import com.k2.share.MEDIA_PERMS
import com.k2.share.MediaItem
import com.k2.share.Thumbs
import com.k2.share.hasMediaAccess
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.k2.share.Device
import com.k2.share.SAVE_FOLDER
import com.k2.share.Screen
import com.k2.share.ShareViewModel
import com.k2.share.TState
import com.k2.share.Transfer
import com.k2.share.fmt

private val muted: Color @Composable get() = MaterialTheme.colorScheme.onSurfaceVariant
private val card: Color @Composable get() = MaterialTheme.colorScheme.surfaceVariant

@Composable
fun AppRoot(vm: ShareViewModel, granted: Boolean, onRequest: () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides if (Lang.urdu) LayoutDirection.Rtl else LayoutDirection.Ltr) {
        AppRootContent(vm, granted, onRequest)
    }
}

@Composable
private fun AppRootContent(vm: ShareViewModel, granted: Boolean, onRequest: () -> Unit) {
    val view = LocalView.current
    val busy = vm.screen == Screen.CONNECTED || vm.screen == Screen.GROUP_HOST || vm.screen == Screen.GROUP_JOIN
    DisposableEffect(busy) {
        view.keepScreenOn = busy // screen stays on during a transfer
        onDispose { view.keepScreenOn = false }
    }
    val bg = MaterialTheme.colorScheme.background
    val glow = MaterialTheme.colorScheme.primary.copy(alpha = 0.06f)
    Surface(
        Modifier.fillMaxSize().background(bg).drawBehind {
            drawRect(Brush.radialGradient(listOf(glow, Color.Transparent), center = Offset(size.width * 0.15f, 0f), radius = size.width * 1.1f))
        },
        color = Color.Transparent,
        contentColor = MaterialTheme.colorScheme.onBackground,
    ) {
      // On tablets and in landscape, keep everything a comfortable width in the middle
      Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
       Box(Modifier.widthIn(max = 720.dp).fillMaxSize()) {
        if (!granted) PermissionScreen(onRequest)
        else AnimatedContent(
            targetState = vm.screen,
            transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(160)) },
            label = "nav",
        ) { s ->
            when (s) {
                Screen.HOME -> HomeScreen(vm)
                Screen.CONNECTED -> ConnectedScreen(vm)
                Screen.INVITE -> InviteScreen(vm)
                Screen.GROUP_HOST -> GroupHostScreen(vm)
                Screen.GROUP_JOIN -> GroupJoinScreen(vm)
                Screen.SCAN_QR -> QrScanScreen(vm)
                Screen.RECEIVED -> ReceivedScreen(vm)
            }
        }
       }
      }
    }
    vm.request?.let { r ->
        AppDialog(
            onDismiss = {}, dismissible = false,
            icon = { Avatar(r.name, 72.dp) },
            title = r.name,
            message = tr("wants to connect with you to share files", "آپ سے جُڑ کر فائلیں شیئر کرنا چاہتا ہے"),
            primary = tr("Accept", "قبول کریں") to vm::accept,
            secondary = tr("Decline", "انکار") to vm::decline,
        )
    }
    vm.connecting?.let { d ->
        AppDialog(
            onDismiss = {}, dismissible = false,
            icon = { Avatar(d.name, 72.dp) },
            title = tr("Connecting to ${d.name}", "${d.name} سے جُڑ رہے ہیں"),
            message = tr("Waiting for ${d.name} to tap Accept", "${d.name} کے قبول کرنے کا انتظار"),
            busy = true,
            secondary = tr("Cancel", "منسوخ") to vm::cancelConnect,
        )
    }
}

// ---------------- Permissions ----------------

@Composable
private fun PermissionScreen(onRequest: () -> Unit) {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(Modifier.size(96.dp).clip(CircleShape).background(Ink), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.LocationOn, null, tint = Saffron, modifier = Modifier.size(44.dp))
        }
        Spacer(Modifier.height(24.dp))
        Text(tr("Allow nearby access", "قریبی فونز تک رسائی دیں"), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            tr("Asan Share needs this to find phones near you and connect to them directly. Files never go through the internet.", "آسان شیئر کو قریبی فون ڈھونڈنے اور اُن سے براہِ راست جُڑنے کے لیے یہ اجازت چاہیے۔ فائلیں انٹرنیٹ سے نہیں جاتیں۔"),
            textAlign = TextAlign.Center, color = muted,
        )
        Spacer(Modifier.height(28.dp))
        Button(onClick = onRequest, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp), shape = RoundedCornerShape(16.dp)) {
            Text(tr("Allow", "اجازت دیں"), fontSize = 16.sp)
        }
        TextButton(onClick = {
            ctx.startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }) { Text(tr("Open app settings", "ایپ کی سیٹنگز کھولیں")) }
    }
}

// ---------------- Home: always visible + always searching (like Zapya) ----------------

@Composable
private fun HomeScreen(vm: ShareViewModel) {
    var renaming by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        vm.loadReceived()
        while (true) { vm.keepAlive(); delay(1200) }
    }
    var homeTab by rememberSaveable { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (homeTab) {
                0 -> ShareTab(vm) { renaming = true }
                1 -> ReceivedScreen(vm, embedded = true) { homeTab = 0 }
                else -> MoreTab(vm) { renaming = true }
            }
        }
        BottomNav(homeTab, received = vm.received.size) { homeTab = it }
    }
    if (renaming) {
        var text by remember { mutableStateOf(vm.myName) }
        AppDialog(
            onDismiss = { renaming = false },
            icon = { Avatar(text.ifBlank { "?" }, 64.dp) },
            title = tr("Your phone's name", "آپ کے فون کا نام"),
            message = tr("Other phones will see this name.", "دوسرے فونز پر یہی نام نظر آئے گا۔"),
            content = {
                OutlinedTextField(
                    value = text, onValueChange = { text = it.take(30) }, singleLine = true,
                    shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth(),
                )
            },
            primary = tr("Save", "محفوظ کریں") to { vm.rename(text); renaming = false },
            secondary = tr("Cancel", "منسوخ") to { renaming = false },
        )
    }
}

/** Home, "Share" tab: who you are, nearby phones, other ways to connect. */
@Composable
private fun ShareTab(vm: ShareViewModel, onRename: () -> Unit) {
    val found = vm.devices.size
    val visible = vm.problems.isEmpty() && !vm.failed
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        // ---- Header ----
        Row(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(tr("Asan Share", "آسان شیئر"), style = MaterialTheme.typography.headlineSmall)
                Row(
                    Modifier.clip(RoundedCornerShape(50)).clickable(onClick = onRename).padding(vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(if (visible) Good else MaterialTheme.colorScheme.error))
                    Spacer(Modifier.width(7.dp))
                    Text(
                        if (visible) tr("Visible as ${vm.myName}", "${vm.myName} کے نام سے نظر آ رہا ہے") else tr("Not visible right now", "ابھی نظر نہیں آ رہا"),
                        style = MaterialTheme.typography.bodySmall, color = muted, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false),
                    )
                    Spacer(Modifier.width(5.dp))
                    Icon(Icons.Filled.Edit, tr("Rename", "نام بدلیں"), tint = muted, modifier = Modifier.size(13.dp))
                }
            }
            Logo(42.dp)
        }

        // ---- Status banners (only when needed) ----
        if (vm.reconnectName != null) {
            Banner(Saffron.copy(alpha = 0.16f)) {
                Spinner(20.dp, Saffron, 2.5.dp)
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text(tr("Reconnecting to ${vm.reconnectName}…", "${vm.reconnectName} سے دوبارہ جُڑ رہے ہیں…"), style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        if (vm.resumeCount > 0) tr("${vm.resumeCount} unfinished files will continue", "${vm.resumeCount} نامکمل فائلیں جاری ہوں گی")
                        else tr("Keep Asan Share open on both phones", "دونوں فونز پر آسان شیئر کھلا رکھیں"),
                        style = MaterialTheme.typography.bodySmall, color = muted, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                }
                TextButton(onClick = vm::cancelReconnect) { Text(tr("Cancel", "منسوخ"), color = muted) }
            }
        }
        if (vm.picked.isNotEmpty() && vm.reconnectName == null) {
            Banner(card) {
                Box(Modifier.size(36.dp).clip(RoundedCornerShape(12.dp)).background(Saffron), contentAlignment = Alignment.Center) {
                    Icon(Icons.AutoMirrored.Filled.Send, null, tint = OnSaffron, modifier = Modifier.size(18.dp))
                }
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text(tr("${vm.picked.size} files ready", "${vm.picked.size} فائلیں تیار ہیں"), style = MaterialTheme.typography.titleSmall)
                    Text(tr("Tap a phone below to send them", "بھیجنے کے لیے نیچے کسی فون پر ٹیپ کریں"), color = muted, style = MaterialTheme.typography.bodySmall)
                }
                TextButton(onClick = vm::clearSelection) { Text(tr("Clear", "صاف کریں"), color = muted) }
            }
        }

        // ---- Nearby phones (takes the free space) ----
        val blocked = vm.problems.isNotEmpty() || vm.failed
        Column(
            Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(28.dp)).background(card).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            if (!blocked) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (found == 0) tr("Looking for phones", "فون تلاش ہو رہے ہیں") else tr("Tap a phone to connect", "جُڑنے کے لیے فون پر ٹیپ کریں"),
                            style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            if (found == 0) tr("Open Asan Share on the other phone", "دوسرے فون پر آسان شیئر کھولیں")
                            else if (found == 1) tr("1 phone nearby", "قریب 1 فون") else tr("$found phones nearby", "قریب $found فونز"),
                            color = muted, style = MaterialTheme.typography.bodySmall, maxLines = 1,
                        )
                    }
                    if (found > 0) CountBadge(found)
                }
                BoxWithConstraints(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    val side = minOf(maxWidth, maxHeight, 340.dp)
                    Box(Modifier.size(side)) { Radar(vm) }
                }
                if (vm.status.isNotEmpty()) {
                    Text(
                        vm.status, color = MaterialTheme.colorScheme.primary, textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            } else {
                Box(Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState()), contentAlignment = Alignment.Center) { FixItCard(vm) }
            }
        }

        // ---- Other ways to connect ----
        Spacer(Modifier.height(16.dp))
        Text(
            tr("Phone not showing? Connect another way", "فون نظر نہیں آ رہا؟ دوسرا طریقہ"),
            style = MaterialTheme.typography.labelLarge, color = muted,
            modifier = Modifier.fillMaxWidth().padding(start = 4.dp, bottom = 10.dp), maxLines = 1, overflow = TextOverflow.Ellipsis,
        )
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ActionTile(Icons.Filled.Wifi, tr("Create group", "گروپ بنائیں"), tr("Others join you", "دوسرے آپ سے جُڑیں"), Saffron, Modifier.weight(1f).fillMaxHeight()) { vm.createGroup() }
            ActionTile(Icons.Filled.Search, tr("Join group", "گروپ جوائن کریں"), tr("List or QR code", "فہرست یا QR کوڈ"), Color(0xFF7C83FF), Modifier.weight(1f).fillMaxHeight(), vm::openJoin)
        }
        Spacer(Modifier.height(12.dp))
    }
}

/** Home, "More" tab: name, language, save folder, share app, help. */
@Composable
private fun MoreTab(vm: ShareViewModel, onRename: () -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)) {
        Text(tr("More", "مزید"), style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(top = 10.dp, bottom = 16.dp))
        // you
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(card).clickable(onClick = onRename).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Avatar(vm.myName, 52.dp)
            Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                Text(vm.myName, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(tr("Name other phones see", "دوسرے فونز پر نظر آنے والا نام"), style = MaterialTheme.typography.bodySmall, color = muted)
            }
            SmallPill(tr("Edit", "بدلیں"), onRename)
        }
        SettingsGroup(tr("Settings", "سیٹنگز")) {
            SettingsRow(Icons.Filled.Language, tr("Language", "زبان"), if (Lang.urdu) "اردو" else "English", tr("Change", "بدلیں")) { vm.setUrdu(!Lang.urdu) }
            SettingsDivider()
            SettingsRow(
                Icons.Filled.Folder, tr("Where files are saved", "فائلیں کہاں محفوظ ہوتی ہیں"),
                if (vm.ownFolder) tr("Phone storage › Asan Share", "فون اسٹوریج › Asan Share") else tr("Downloads › Asan Share", "ڈاؤن لوڈز › Asan Share"),
                tr("Open", "کھولیں"),
            ) { openSaveFolder(ctx, vm.saveFolderRelative()) }
        }
        if (!vm.ownFolder && android.os.Build.VERSION.SDK_INT >= 30) {
            Spacer(Modifier.height(10.dp))
            FolderAccessCard()
        }
        SettingsGroup(tr("Share", "شیئر")) {
            SettingsRow(Icons.Filled.PersonAdd, tr("Send Asan Share to a friend", "دوست کو آسان شیئر بھیجیں"), tr("Works without internet", "انٹرنیٹ کے بغیر"), null, vm::openInvite)
        }
        SettingsGroup(tr("Help", "مدد")) {
            SettingsRow(Icons.Filled.Chat, tr("Contact the developer", "ڈویلپر سے رابطہ"), "WhatsApp 0303 2901193", null) { openWhatsApp(ctx) }
            SettingsDivider()
            SettingsRow(Icons.Filled.Info, tr("Version", "ورژن"), "v" + vm.appVersion, null) {}
        }
        Text(
            tr("Made with care by JAVED IQBAL", "تیار کردہ: جاوید اقبال"),
            style = MaterialTheme.typography.labelMedium, color = muted, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp),
        )
    }
}

// ======================= DESIGN KIT =======================

/** Floating bottom navigation: the selected item becomes a gold pill with its label. */
@Composable
private fun BottomNav(selected: Int, received: Int, onSelect: (Int) -> Unit) {
    val items = listOf(
        Icons.Filled.Home to tr("Home", "ہوم"),
        Icons.Filled.Download to tr("Received", "موصول"),
        Icons.Filled.Menu to tr("More", "مزید"),
    )
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp)
            .shadow(16.dp, RoundedCornerShape(28.dp), clip = false)
            .clip(RoundedCornerShape(28.dp)).background(MaterialTheme.colorScheme.surface).padding(6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        items.forEachIndexed { i, (icon, label) ->
            val sel = i == selected
            Row(
                Modifier.weight(if (sel) 1.6f else 1f).heightIn(min = 52.dp).clip(RoundedCornerShape(22.dp))
                    .background(if (sel) Saffron else Color.Transparent).clickable { onSelect(i) }.padding(horizontal = 10.dp),
                horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically,
            ) {
                Box {
                    Icon(icon, label, tint = if (sel) OnSaffron else muted, modifier = Modifier.size(22.dp))
                    if (i == 1 && received > 0 && !sel) {
                        Box(Modifier.align(Alignment.TopEnd).offset(x = 4.dp, y = (-2).dp).size(8.dp).clip(CircleShape).background(Saffron))
                    }
                }
                if (sel) {
                    Spacer(Modifier.width(8.dp))
                    Text(label, color = OnSaffron, style = MaterialTheme.typography.labelLarge, maxLines = 1)
                }
            }
        }
    }
}

/** Square-ish tile: tinted icon on top, title and a short hint. */
@Composable
private fun ActionTile(icon: ImageVector, title: String, sub: String, tint: Color, modifier: Modifier, onClick: () -> Unit) {
    Row(
        modifier.clip(RoundedCornerShape(22.dp)).background(card).clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(tint.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp))
        }
        Column(Modifier.weight(1f).padding(start = 12.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, maxLines = 2)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = muted, maxLines = 2)
        }
    }
}

@Composable
private fun CountBadge(n: Int) {
    Box(Modifier.size(32.dp).clip(CircleShape).background(Saffron), contentAlignment = Alignment.Center) {
        Text("$n", color = OnSaffron, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
private fun SmallPill(text: String, onClick: () -> Unit) {
    Text(
        text, style = MaterialTheme.typography.labelLarge,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f))
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp),
    )
}

@Composable
private fun SettingsGroup(title: String, content: @Composable () -> Unit) {
    Spacer(Modifier.height(20.dp))
    Text(title, style = MaterialTheme.typography.labelLarge, color = muted, modifier = Modifier.padding(start = 6.dp, bottom = 8.dp))
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(card)) { content() }
}

@Composable
private fun SettingsRow(icon: ImageVector, title: String, value: String, action: String?, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(19.dp))
        }
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(value, style = MaterialTheme.typography.bodySmall, color = muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (action != null) Text(action, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
private fun SettingsDivider() {
    Box(Modifier.fillMaxWidth().padding(start = 68.dp).height(1.dp).background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)))
}

/** Main gold button used for the most important action on a screen. */
@Composable
private fun PrimaryCta(text: String, icon: ImageVector?, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick, enabled = enabled, modifier = modifier.heightIn(min = 54.dp),
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Saffron, contentColor = OnSaffron, disabledContainerColor = Saffron.copy(alpha = 0.35f), disabledContentColor = OnSaffron.copy(alpha = 0.6f)),
        contentPadding = PaddingValues(horizontal = 22.dp, vertical = 12.dp),
    ) {
        if (icon != null) { Icon(icon, null, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)) }
        Text(text, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
    }
}

@Composable
private fun MeChip(name: String, visible: Boolean, onEdit: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(50)).background(card).clickable(onClick = onEdit)
            .padding(start = 6.dp, end = 14.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box {
            Avatar(name, 36.dp)
            Box(
                Modifier.align(Alignment.BottomEnd).size(12.dp).clip(CircleShape).background(card).padding(2.dp)
                    .clip(CircleShape).background(if (visible) Good else MaterialTheme.colorScheme.error)
            )
        }
        Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
            Text(name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                if (visible) tr("Visible to nearby phones", "قریبی فونز کو نظر آ رہا ہے") else tr("Not visible right now", "ابھی نظر نہیں آ رہا"),
                style = MaterialTheme.typography.labelSmall, color = if (visible) Good else MaterialTheme.colorScheme.error,
            )
        }
        Icon(Icons.Filled.Edit, tr("Change name", "نام بدلیں"), tint = muted, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun Banner(bg: Color, content: @Composable androidx.compose.foundation.layout.RowScope.() -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(bottom = 12.dp).clip(RoundedCornerShape(22.dp)).background(bg)
            .padding(start = 16.dp, end = 6.dp, top = 12.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content,
    )
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text, style = MaterialTheme.typography.labelLarge, color = muted, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.fillMaxWidth().padding(start = 4.dp, bottom = 8.dp),
    )
}

@Composable
private fun WayButton(icon: ImageVector, title: String, bg: Color, fg: Color, modifier: Modifier, onClick: () -> Unit) {
    Row(
        modifier.heightIn(min = 56.dp).clip(RoundedCornerShape(20.dp)).background(bg).clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center,
    ) {
        Icon(icon, null, tint = fg, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(6.dp))
        Text(
            title, color = fg, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall,
            maxLines = 2, textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun MiniTile(icon: ImageVector, accent: Color, onAccent: Color, title: String, sub: String, modifier: Modifier, onClick: () -> Unit) {
    Row(
        modifier.clip(RoundedCornerShape(22.dp)).background(card)
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(accent), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = onAccent, modifier = Modifier.size(20.dp))
        }
        Column(Modifier.weight(1f).padding(start = 10.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun ListRow(icon: ImageVector, accent: Color, onAccent: Color, title: String, sub: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(40.dp).clip(RoundedCornerShape(13.dp)).background(accent), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = onAccent, modifier = Modifier.size(22.dp))
        }
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = muted)
        }
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = muted)
    }
}

@Composable
private fun ActionCard(
    icon: ImageVector, title: String, subtitle: String,
    accent: Color, onAccent: Color, modifier: Modifier, onClick: () -> Unit,
) {
    Column(
        modifier.clip(RoundedCornerShape(24.dp)).background(card).clickable(onClick = onClick).padding(16.dp)
    ) {
        Box(Modifier.size(46.dp).clip(RoundedCornerShape(15.dp)).background(accent), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = onAccent)
        }
        Spacer(Modifier.height(12.dp))
        Text(title, fontWeight = FontWeight.Bold)
        Text(subtitle, style = MaterialTheme.typography.bodySmall, color = muted)
    }
}

@Composable
private fun MyPhoneCard(name: String, visible: Boolean, onEdit: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(card)
            .border(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f), RoundedCornerShape(22.dp))
            .clickable(onClick = onEdit).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box {
            Avatar(name, 46.dp)
            Box(
                Modifier.align(Alignment.BottomEnd).size(14.dp).clip(CircleShape).background(card).padding(2.dp)
                    .clip(CircleShape).background(if (visible) Good else MaterialTheme.colorScheme.error)
            )
        }
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Text(
                if (visible) tr("Visible to nearby phones", "قریبی فونز کو نظر آ رہا ہے") else tr("Not visible right now", "ابھی نظر نہیں آ رہا"),
                style = MaterialTheme.typography.labelMedium,
                color = if (visible) Good else MaterialTheme.colorScheme.error,
            )
            Text(name, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Box(
            Modifier.size(38.dp).clip(CircleShape).background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f)),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Filled.Edit, tr("Change name", "نام بدلیں"), tint = muted, modifier = Modifier.size(18.dp)) }
    }
}

@Composable
private fun DeveloperCredit() {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(tr("Developed by", "تیار کردہ"), style = MaterialTheme.typography.labelSmall, color = muted)
        Text("JAVED IQBAL", fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(8.dp))
        Row(
            Modifier.clip(RoundedCornerShape(50)).background(Color(0xFF25D366).copy(alpha = 0.14f)).clickable { openWhatsApp(ctx) }.padding(start = 6.dp, end = 14.dp, top = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            WhatsAppIcon(26.dp)
            Spacer(Modifier.width(8.dp))
            Text("0303 2901193", fontWeight = FontWeight.Bold, color = Color(0xFF1FAF55))
        }
    }
}

/** WhatsApp-style mark: green chat bubble with a white phone. */
@Composable
private fun WhatsAppIcon(size: Dp) {
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = this.size.width
            val green = Color(0xFF25D366)
            drawCircle(green, radius = w * 0.44f, center = Offset(w * 0.52f, w * 0.46f))
            val tail = Path().apply {
                moveTo(w * 0.18f, w * 0.62f); lineTo(w * 0.08f, w * 0.95f); lineTo(w * 0.40f, w * 0.84f); close()
            }
            drawPath(tail, green)
            drawCircle(Color.White, radius = w * 0.34f, center = Offset(w * 0.52f, w * 0.46f), style = Stroke(width = w * 0.07f))
        }
        Icon(Icons.Filled.Phone, null, tint = Color.White, modifier = Modifier.size(size * 0.40f).offset(x = size * 0.02f, y = (-0.02f * size.value).dp))
    }
}

@Composable
private fun DeviceRow(d: Device, enabled: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().alpha(if (enabled) 1f else 0.5f).clip(RoundedCornerShape(20.dp)).background(card)
            .clickable(enabled = enabled, onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Avatar(d.name, 48.dp)
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Text(d.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                tr("Tap to connect", "جُڑنے کے لیے ٹیپ کریں"),
                style = MaterialTheme.typography.bodySmall, color = muted,
            )
        }
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = muted)
    }
}

@Composable
private fun Logo(size: Dp) {
    Image(painterResource(R.drawable.app_logo), "Asan Share", Modifier.size(size))
}

@Composable
private fun InviteScreen(vm: ShareViewModel) {
    val ctx = LocalContext.current
    var wifiMode by remember { mutableStateOf(false) }
    BackHandler { if (wifiMode) wifiMode = false else vm.goHome() }
    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        TopBar(if (wifiMode) tr("Download over Wi-Fi", "وائی فائی سے ڈاؤن لوڈ") else tr("Send the app to a friend", "دوست کو ایپ بھیجیں")) { if (wifiMode) wifiMode = false else vm.goHome() }
        if (wifiMode) {
            WifiInvite()
        } else {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text(tr("Your friend doesn't need internet. Pick one way:", "دوست کو انٹرنیٹ کی ضرورت نہیں۔ کوئی ایک طریقہ چنیں:"), color = muted)
                InviteOption(Icons.Filled.Bluetooth, tr("Send by Bluetooth", "بلوٹوتھ سے بھیجیں"), tr("Works on every phone. Takes about a minute.", "ہر فون پر چلتا ہے۔ تقریباً ایک منٹ لگتا ہے۔"), Ink, Color.White) {
                    AppInvite.sendByBluetooth(ctx)
                }
                InviteOption(Icons.Filled.Wifi, tr("Download over Wi-Fi", "وائی فائی سے ڈاؤن لوڈ"), tr("Fastest. Your friend scans 2 codes with the camera.", "سب سے تیز۔ دوست کیمرے سے 2 کوڈ اسکین کرے۔"), Saffron, OnSaffron) {
                    wifiMode = true
                }
                InviteOption(Icons.Filled.Share, tr("Quick Share, WhatsApp and more", "کوئیک شیئر، واٹس ایپ وغیرہ"), tr("Use any sharing app on your phone.", "فون کی کوئی بھی شیئرنگ ایپ استعمال کریں۔"), card, MaterialTheme.colorScheme.onSurface) {
                    AppInvite.shareAnyWay(ctx)
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    tr("When it arrives, your friend taps the file, then Install. The phone may ask to allow installing from this source. That's normal.", "فائل ملنے پر دوست اسے کھول کر انسٹال دبائے۔ فون اس ذریعے سے انسٹال کی اجازت مانگ سکتا ہے، یہ عام بات ہے۔"),
                    style = MaterialTheme.typography.bodySmall, color = muted,
                )
            }
        }
    }
}

@Composable
private fun InviteOption(icon: ImageVector, title: String, desc: String, accent: Color, onAccent: Color, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(card).clickable(onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(54.dp).clip(RoundedCornerShape(17.dp)).background(accent), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = onAccent, modifier = Modifier.size(28.dp))
        }
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text(desc, style = MaterialTheme.typography.bodySmall, color = muted)
        }
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = muted)
    }
}

@Composable
private fun WifiInvite() {
    val ctx = LocalContext.current
    val server = remember { InviteServer(ctx.applicationContext) }
    var ssid by remember { mutableStateOf<String?>(null) }
    var pass by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var timedOut by remember { mutableStateOf(false) }
    var ip by remember { mutableStateOf<String?>(null) }
    DisposableEffect(Unit) {
        server.startWeb()
        server.startHotspot({ s, p -> ssid = s; pass = p }, { error = it })
        onDispose { server.stop() }
    }
    // keep the download link up to date (it changes when a hotspot turns on)
    LaunchedEffect(Unit) { while (true) { ip = AppInvite.localIp(); delay(1000) } }
    // some phones never answer: don't keep the user waiting forever
    LaunchedEffect(Unit) { delay(12_000); if (ssid == null && error == null) timedOut = true }
    val url = ip?.let { "http://$it:${server.port}" }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        when {
            ssid != null -> {
                StepCard(
                    1, tr("Join this Wi-Fi", "یہ وائی فائی جوائن کریں"),
                    tr("On your friend's phone, open the Camera and point it at this code. Tap the Wi-Fi message to join.",
                        "دوست کے فون پر کیمرہ کھول کر اس کوڈ کی طرف کریں، پھر وائی فائی والے پیغام پر ٹیپ کریں۔"),
                    AppInvite.wifiQrText(ssid!!, pass ?: ""),
                    tr("Wi-Fi: $ssid\nPassword: $pass", "وائی فائی: $ssid\nپاس ورڈ: $pass"),
                )
                if (url != null) {
                    StepCard(
                        2, tr("Download the app", "ایپ ڈاؤن لوڈ کریں"),
                        tr("Now point the camera at this code and open the link. Tap Download the app.",
                            "اب کیمرہ اس کوڈ کی طرف کریں اور لنک کھولیں، پھر Download the app دبائیں۔"),
                        url, url,
                    )
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Spinner(22.dp); Spacer(Modifier.width(10.dp))
                        Text(tr("Getting the download link ready…", "ڈاؤن لوڈ لنک تیار ہو رہا ہے…"), color = muted)
                    }
                }
            }
            error != null || timedOut -> HotspotFallback(url, error)
            else -> {
                Spacer(Modifier.height(48.dp))
                Spinner(48.dp)
                Text(tr("Starting Wi-Fi…", "وائی فائی شروع ہو رہا ہے…"), color = muted)
                Text(
                    tr("This takes a few seconds.", "اس میں چند سیکنڈ لگتے ہیں۔"),
                    style = MaterialTheme.typography.bodySmall, color = muted,
                )
            }
        }
    }
}

/** When the phone won't create its own Wi-Fi: use the normal Mobile Hotspot (or the same Wi-Fi) instead. */
@Composable
private fun HotspotFallback(url: String?, error: String?) {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(card).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(tr("Let's use your hotspot instead", "اس کے بجائے ہاٹ اسپاٹ استعمال کریں"), fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(
            tr("This phone didn't allow Asan Share to make its own Wi-Fi. It's easy another way:",
                "اس فون نے آسان شیئر کو اپنا وائی فائی بنانے نہیں دیا۔ دوسرا آسان طریقہ:"),
            color = muted,
        )
        Text(tr("1.  Turn on your Mobile Hotspot", "1.  اپنا موبائل ہاٹ اسپاٹ آن کریں"), fontWeight = FontWeight.SemiBold)
        Button(
            onClick = {
                runCatching { ctx.startActivity(Intent("android.settings.TETHER_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                    .onFailure { runCatching { ctx.startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
            },
            modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp), shape = RoundedCornerShape(16.dp),
        ) { Text(tr("Open hotspot settings", "ہاٹ اسپاٹ کی سیٹنگز کھولیں")) }
        Text(tr("2.  Your friend joins your hotspot from their Wi-Fi list", "2.  دوست اپنی وائی فائی لسٹ سے آپ کا ہاٹ اسپاٹ جوائن کرے"), fontWeight = FontWeight.SemiBold)
        Text(tr("3.  Your friend scans this code with the camera", "3.  دوست کیمرے سے یہ کوڈ اسکین کرے"), fontWeight = FontWeight.SemiBold)
        Text(
            tr("Tip: if both phones are already on the same Wi-Fi, skip steps 1 and 2.",
                "مشورہ: اگر دونوں فون پہلے سے ایک ہی وائی فائی پر ہیں تو 1 اور 2 چھوڑ دیں۔"),
            style = MaterialTheme.typography.bodySmall, color = muted,
        )
        Text(
            tr("No hotspot on this device (many tablets)? Connect both to the same Wi-Fi, or use Bluetooth or Quick Share.",
                "اس ڈیوائس میں ہاٹ اسپاٹ نہیں (جیسے اکثر ٹیبلٹس)؟ دونوں کو ایک ہی وائی فائی سے جوڑیں، یا بلوٹوتھ / کوئیک شیئر استعمال کریں۔"),
            style = MaterialTheme.typography.bodySmall, color = muted,
        )
        if (error != null) Text(error, style = MaterialTheme.typography.bodySmall, color = muted)
    }
    if (url != null) {
        StepCard(3, tr("Download the app", "ایپ ڈاؤن لوڈ کریں"),
            tr("Scan with the camera and open the link.", "کیمرے سے اسکین کر کے لنک کھولیں۔"), url, url)
    } else {
        Text(
            tr("The download code will appear here once your hotspot or Wi-Fi is on.",
                "ہاٹ اسپاٹ یا وائی فائی آن ہوتے ہی ڈاؤن لوڈ کوڈ یہاں نظر آئے گا۔"),
            color = muted, textAlign = TextAlign.Center,
        )
    }
}

/** Loading spinner that keeps turning even when phone animations are switched off. */
@Composable
private fun Spinner(size: Dp = 36.dp, color: Color = MaterialTheme.colorScheme.primary, stroke: Dp = 3.5.dp) {
    val phase = rememberLoopPhase(1000)
    Canvas(Modifier.size(size)) {
        val sw = stroke.toPx()
        val tl = Offset(sw / 2, sw / 2)
        val sz = androidx.compose.ui.geometry.Size(this.size.width - sw, this.size.height - sw)
        drawArc(color.copy(alpha = 0.18f), 0f, 360f, false, topLeft = tl, size = sz, style = Stroke(sw))
        drawArc(
            color, phase.value * 360f - 90f, 110f, false, topLeft = tl, size = sz,
            style = Stroke(sw, cap = StrokeCap.Round),
        )
    }
}

@Composable
private fun StepCard(n: Int, title: String, desc: String, qrText: String, caption: String) {
    val img = remember(qrText) { AppInvite.qr(qrText) }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(card).padding(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(34.dp).clip(CircleShape).background(Ink), contentAlignment = Alignment.Center) {
                Text("$n", color = Saffron, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(12.dp))
            Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        Spacer(Modifier.height(8.dp))
        Text(desc, color = muted, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(14.dp))
        if (img != null) {
            Image(
                img, "QR code",
                Modifier.size(230.dp).clip(RoundedCornerShape(16.dp)).background(Color.White).padding(10.dp),
            )
        }
        Spacer(Modifier.height(10.dp))
        Text(caption, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
    }
}

// ---------------- Transfer progress ----------------

@Composable
private fun TransfersPanel(vm: ShareViewModel) {
    val ctx = LocalContext.current
    val st = Stats(vm)
    val all = vm.transfers
    if (all.isEmpty()) {
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Box(Modifier.size(72.dp).clip(CircleShape).background(card), contentAlignment = Alignment.Center) {
                Icon(Icons.AutoMirrored.Filled.Send, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(30.dp))
            }
            Spacer(Modifier.height(14.dp))
            Text(tr("Nothing sent yet", "ابھی کچھ نہیں بھیجا گیا"), style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Text(
                tr("Choose files and tap Send. Files from ${vm.peerName ?: "the other phone"} appear here too.",
                    "فائلیں چن کر «بھیجیں» دبائیں۔ ${vm.peerName ?: "دوسرے فون"} کی فائلیں بھی یہیں نظر آئیں گی۔"),
                color = muted, textAlign = TextAlign.Center,
            )
        }
        return
    }
    val progress by animateFloatAsState(if (st.finished) 1f else st.fraction, label = "progress")
    val nowRows = all.filter { vm.runUids.containsKey(it.uid) }.asReversed()
    val earlier = all.filter { !vm.runUids.containsKey(it.uid) }.asReversed()
    // long-press a file to select several, then remove them together
    val selected = remember { mutableStateMapOf<Long, Boolean>() }
    val selecting = selected.isNotEmpty()
    BackHandler(enabled = selecting) { selected.clear() }
    val rowFor: @Composable (Transfer) -> Unit = { t ->
        val toggle = { if (selected.containsKey(t.uid)) selected.remove(t.uid) else selected[t.uid] = true; Unit }
        SwipeRow(enabled = !t.active && !selecting, onRemove = { vm.removeTransfers(setOf(t.uid)) }) {
            TransferRow(
                t, selected = selected.containsKey(t.uid), selecting = selecting,
                onClick = { if (selecting) toggle() else t.saved?.let { openFile(ctx, it) } },
                onLongClick = toggle,
                onCancel = { vm.cancelTransfer(t) },
            )
        }
    }
    Column(Modifier.fillMaxSize()) {
    if (selecting) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp).clip(RoundedCornerShape(18.dp))
                .background(Ink).padding(start = 8.dp, end = 8.dp, top = 4.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { selected.clear() }) { Icon(Icons.Filled.Close, tr("Cancel", "منسوخ"), tint = Color.White) }
            Text(tr("${selected.size} selected", "${selected.size} منتخب"), color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = { all.forEach { selected[it.uid] = true } }) { Text(tr("All", "سب"), color = Saffron) }
            Button(
                onClick = { vm.removeTransfers(selected.keys.toSet()); selected.clear() },
                colors = ButtonDefaults.buttonColors(containerColor = Saffron, contentColor = OnSaffron), shape = RoundedCornerShape(14.dp),
            ) { Text(tr("Remove", "ہٹائیں"), fontWeight = FontWeight.Bold) }
        }
    }
    LazyColumn(
        Modifier.fillMaxWidth().weight(1f),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        // ---- One summary for the transfer happening now ----
        if ((nowRows.isNotEmpty() || st.count > 0) && !selecting) item {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
                    .background(card)
                    .padding(20.dp),
            ) {
                Text(st.title(), style = MaterialTheme.typography.titleMedium, color = muted)
                Spacer(Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        if (st.allCancelled) tr("Cancelled", "منسوخ") else if (st.finished) tr("Done", "مکمل") else "${(progress * 100).toInt()}%",
                        style = MaterialTheme.typography.displaySmall, modifier = Modifier.weight(1f),
                    )
                    if (st.busy && st.speed > 0) {
                        Text("${fmt(st.speed.toLong())}/s", fontWeight = FontWeight.Bold, fontSize = 18.sp,
                            color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(bottom = 8.dp))
                    }
                }
                if (!st.allCancelled) {
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth().height(8.dp),
                    color = if (st.finished) Good else if (!st.busy && st.resumable > 0) Saffron else MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.15f),
                    strokeCap = StrokeCap.Round,
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    buildString {
                        append(tr("${fmt(st.done)} of ${fmt(st.total)}", "${fmt(st.total)} میں سے ${fmt(st.done)}"))
                        if (st.busy) append("   " + etaText(st.etaSec))
                    },
                    color = muted, style = MaterialTheme.typography.bodySmall,
                )
                }
                if (st.busy || (st.resumable > 0 && vm.connected)) {
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (!st.busy && st.resumable > 0 && vm.connected) {
                            Button(
                                onClick = vm::resumeUnfinished, modifier = Modifier.weight(1f).heightIn(min = 46.dp), shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Saffron, contentColor = OnSaffron),
                            ) { Text(tr("Resume ${st.resumable}", "${st.resumable} جاری رکھیں"), fontWeight = FontWeight.Bold) }
                        }
                        if (st.busy) {
                            OutlinedButton(
                                onClick = vm::cancelAll, modifier = Modifier.weight(1f).heightIn(min = 46.dp), shape = RoundedCornerShape(14.dp),
                            ) { Text(tr("Cancel all", "سب منسوخ کریں"), color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.SemiBold) }
                        }
                    }
                }
            }
        }
        items(nowRows, key = { it.uid }) { t -> rowFor(t) }
        // ---- Earlier files, kept for reference ----
        if (earlier.isNotEmpty()) {
            item {
                Row(Modifier.fillMaxWidth().padding(top = 10.dp, start = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(tr("Earlier", "پہلے"), style = MaterialTheme.typography.labelLarge, color = muted, modifier = Modifier.weight(1f))
                    if (!st.busy && !selecting) TextButton(onClick = vm::clearHistory) { Text(tr("Clear all", "سب صاف کریں"), color = muted) }
                }
            }
            items(earlier, key = { it.uid }) { t -> rowFor(t) }
        }
        if (!selecting && all.any { !it.active }) item {
            Text(
                tr("Tip: swipe a file to remove it, or press and hold to select several.", "مشورہ: فائل کو سوائپ کر کے ہٹائیں، یا کئی منتخب کرنے کے لیے دبا کر رکھیں۔"),
                style = MaterialTheme.typography.bodySmall, color = muted, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            )
        }
    }
    }
}

/** Swipe left or right to remove (finished/cancelled files only). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SwipeRow(enabled: Boolean, onRemove: () -> Unit, content: @Composable () -> Unit) {
    if (!enabled) { content(); return }
    val state = rememberSwipeToDismissBoxState(confirmValueChange = { v ->
        if (v != SwipeToDismissBoxValue.Settled) { onRemove(); true } else false
    })
    SwipeToDismissBox(
        state = state,
        backgroundContent = {
            val swiping = state.dismissDirection != SwipeToDismissBoxValue.Settled
            Row(
                Modifier.fillMaxSize().padding(1.dp).clip(RoundedCornerShape(20.dp))
                    .background(if (swiping) MaterialTheme.colorScheme.error.copy(alpha = 0.85f) else Color.Transparent)
                    .padding(horizontal = 20.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (swiping) {
                    Icon(Icons.Filled.Delete, null, tint = Color.White)
                    Spacer(Modifier.weight(1f))
                    Icon(Icons.Filled.Delete, null, tint = Color.White)
                }
            }
        },
    ) { content() }
}

/** One file. Only the summary has a progress bar; a file shows a small ring while it's moving. */
@Composable
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
private fun TransferRow(t: Transfer, selected: Boolean, selecting: Boolean, onClick: () -> Unit, onLongClick: () -> Unit, onCancel: () -> Unit) {
    val p = if (t.size > 0) (t.done.toFloat() / t.size).coerceIn(0f, 1f) else 0f
    val faded = (t.state == TState.CANCELLED || t.state == TState.FAILED) && !selected
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
            .background(if (selected) Saffron.copy(alpha = 0.22f) else card)
            .then(if (selected) Modifier.border(1.5.dp, Saffron, RoundedCornerShape(20.dp)) else Modifier)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick).padding(12.dp)
            .alpha(if (faded) 0.6f else 1f),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (selecting) {
            CheckDot(selected, onImage = false)
            Spacer(Modifier.width(10.dp))
        }
        FileBadge(t.name)
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(t.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(2.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    if (t.incoming) Icons.Filled.Download else Icons.AutoMirrored.Filled.Send, null,
                    tint = muted, modifier = Modifier.size(13.dp),
                )
                Spacer(Modifier.width(4.dp))
                Text(
                    when (t.state) {
                        TState.WAITING -> if (t.started || t.incoming) tr("Starting…", "شروع ہو رہی ہے…") else tr("In line · ${fmt(t.size)}", "قطار میں · ${fmt(t.size)}")
                        TState.RUNNING -> "${fmt(t.done)} / ${fmt(t.size)}"
                        TState.SAVING -> tr("Saving…", "محفوظ ہو رہی ہے…")
                        TState.DONE -> if (t.incoming) tr("${fmt(t.size)} · Tap to open", "${fmt(t.size)} · کھولنے کے لیے ٹیپ کریں") else tr("${fmt(t.size)} · Sent", "${fmt(t.size)} · بھیج دی")
                        TState.FAILED -> if (t.incoming) tr("Didn't arrive", "نہیں پہنچی") else tr("Didn't finish", "مکمل نہیں ہوئی")
                        TState.PAUSED -> tr("Paused", "رکی ہوئی")
                        TState.CANCELLED -> tr("Cancelled", "منسوخ")
                    },
                    style = MaterialTheme.typography.bodySmall, color = muted, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
        }
        if (!selecting) when (t.state) {
            TState.RUNNING, TState.WAITING, TState.SAVING -> {
                // progress ring with a stop button inside
                Box(Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onCancel), contentAlignment = Alignment.Center) {
                    ProgressRing(p, MaterialTheme.colorScheme.primary, 36.dp) {
                        Icon(Icons.Filled.Close, tr("Cancel", "منسوخ"), tint = muted, modifier = Modifier.size(16.dp))
                    }
                }
            }
            TState.DONE -> Icon(Icons.Filled.CheckCircle, tr("Done", "مکمل"), tint = Good)
            TState.FAILED -> Icon(Icons.Filled.Warning, tr("Failed", "ناکام"), tint = MaterialTheme.colorScheme.error)
            TState.PAUSED -> Icon(Icons.Filled.Pause, tr("Paused", "رکی ہوئی"), tint = Saffron)
            TState.CANCELLED -> Icon(Icons.Filled.Close, tr("Cancelled", "منسوخ"), tint = muted)
        }
    }
}

@Composable
private fun FixItCard(vm: ShareViewModel) {
    val ctx = LocalContext.current
    fun open(action: String) {
        runCatching { ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(card).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(Icons.Filled.Warning, null, tint = Saffron, modifier = Modifier.size(36.dp))
        Spacer(Modifier.height(10.dp))
        if (vm.problems.isNotEmpty()) {
            Text(
                if (Lang.urdu) vm.problems.joinToString(" اور ") { urName(it) } + " آن کریں"
                else "Turn on ${vm.problems.joinToString(" and ")}", fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Spacer(Modifier.height(4.dp))
            Text(tr("Asan Share starts by itself once it's on.", "آن ہوتے ہی آسان شیئر خود شروع ہو جائے گا۔"), color = muted, textAlign = TextAlign.Center)
            Spacer(Modifier.height(14.dp))
            for (p in vm.problems) {
                OutlinedButton(
                    onClick = {
                        open(
                            when (p) {
                                "Bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                                "Wi-Fi" -> Settings.ACTION_WIFI_SETTINGS
                                else -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
                            }
                        )
                    },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).heightIn(min = 50.dp),
                    shape = RoundedCornerShape(16.dp),
                ) { Text(if (Lang.urdu) "${urName(p)} کی سیٹنگز کھولیں" else "Open $p settings") }
            }
        } else {
            Text(vm.status, textAlign = TextAlign.Center)
            Spacer(Modifier.height(14.dp))
            Button(
                onClick = vm::retry, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp), shape = RoundedCornerShape(16.dp),
            ) { Text(tr("Try again", "دوبارہ کوشش کریں"), fontSize = 16.sp) }
            TextButton(onClick = {
                runCatching {
                    ctx.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            }) { Text(tr("Open app permissions", "ایپ کی اجازتیں کھولیں")) }
        }
    }
}

// ---------------- Small pieces ----------------

@Composable
private fun TopBar(title: String, onBack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, tr("Back", "واپس")) }
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SectionTitle(title: String, trailing: String?) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (trailing != null) Text(trailing, style = MaterialTheme.typography.bodySmall, color = muted)
    }
}

private val avatarColors = listOf(0xFF1F2A6B, 0xFF0E8C7F, 0xFFC2410C, 0xFF9D174D, 0xFF4338CA, 0xFF15803D).map { Color(it) }

@Composable
private fun Avatar(name: String, size: Dp) {
    val c = avatarColors[(name.hashCode() and 0x7fffffff) % avatarColors.size]
    val light = Color(
        red = (c.red + (1f - c.red) * 0.35f), green = (c.green + (1f - c.green) * 0.35f), blue = (c.blue + (1f - c.blue) * 0.35f),
    )
    Box(
        Modifier.size(size).clip(CircleShape).background(Brush.linearGradient(listOf(light, c))),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            name.trim().take(1).uppercase().ifEmpty { "?" },
            color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.42f).sp,
        )
    }
}

@Composable
private fun FileBadge(name: String) {
    val ext = name.substringAfterLast('.', "").lowercase()
    val (label, color) = when (ext) {
        "jpg", "jpeg", "png", "gif", "webp", "heic" -> "IMG" to Color(0xFFDB2777)
        "mp4", "mkv", "mov", "avi", "3gp", "webm" -> "VID" to Color(0xFFEA580C)
        "mp3", "m4a", "wav", "aac", "ogg", "opus" -> "AUD" to Color(0xFF7C3AED)
        "apk" -> "APK" to Color(0xFF16A34A)
        "pdf" -> "PDF" to Color(0xFFDC2626)
        "zip", "rar", "7z" -> "ZIP" to Color(0xFF92400E)
        "dst", "emb", "pes", "jef", "exp", "dsb" -> "EMB" to Color(0xFF0E8C7F)
        else -> ext.take(4).uppercase().ifEmpty { "FILE" } to Color(0xFF4F5BD5)
    }
    Box(
        Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(color.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = color, fontWeight = FontWeight.Bold, fontSize = 11.sp) }
}

/**
 * A 0..1 value that loops forever. Driven by the screen's frame clock, so it keeps moving
 * even on phones where "animations" are switched off in settings or by battery saver.
 */
@Composable
private fun rememberLoopPhase(periodMs: Int): State<Float> {
    val phase = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(periodMs) {
        val start = withFrameNanos { it }
        while (true) {
            withFrameNanos { t -> phase.floatValue = (((t - start) / 1_000_000L) % periodMs) / periodMs.toFloat() }
        }
    }
    return phase
}

@Composable
private fun Pulse(color: Color, size: Dp, content: @Composable () -> Unit) {
    val phase = rememberLoopPhase(2400)
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = this.size.minDimension / 2f
            val p = phase.value
            for (i in 0 until 3) {
                val f = (p + i / 3f) % 1f
                drawCircle(color.copy(alpha = (1f - f) * 0.28f), radius = r * (0.3f + 0.7f * f))
            }
        }
        content()
    }
}

@Composable
private fun Radar(vm: ShareViewModel) {
    val phase = rememberLoopPhase(2600)
    val primary = MaterialTheme.colorScheme.primary
    val ring = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.2f)
    val surface = MaterialTheme.colorScheme.background
    BoxWithConstraints(
        Modifier.widthIn(max = 360.dp).fillMaxWidth().aspectRatio(1f),
        contentAlignment = Alignment.Center,
    ) {
        val half = maxWidth / 2
        Canvas(Modifier.fillMaxSize()) {
            val r = this.size.minDimension / 2f
            val p = phase.value
            for (i in 1..3) drawCircle(ring, radius = r * i / 3f, style = Stroke(width = 1.dp.toPx()))
            drawCircle(primary.copy(alpha = (1f - p) * 0.18f), radius = r * p)
            rotate(p * 360f) {
                drawArc(
                    brush = Brush.sweepGradient(
                        0f to Color.Transparent,
                        0.18f to primary.copy(alpha = 0.32f),
                        0.181f to Color.Transparent,
                        center = center,
                    ),
                    startAngle = 0f, sweepAngle = 65f, useCenter = true,
                    topLeft = Offset(center.x - r, center.y - r),
                    size = androidx.compose.ui.geometry.Size(r * 2, r * 2),
                )
            }
        }
        Box(Modifier.size(70.dp).clip(CircleShape).background(surface).padding(4.dp)) { Avatar(vm.myName, 62.dp) }
        val list = vm.devices
        list.forEachIndexed { i, d ->
            val angle = Math.toRadians(-90.0 + 40.0 + i * 360.0 / list.size)
            val dist = half * 0.68f
            DeviceBubble(
                d,
                Modifier.offset(x = dist * cos(angle).toFloat(), y = dist * sin(angle).toFloat()),
            ) { vm.connect(d) }
        }
    }
}

@Composable
private fun DeviceBubble(d: Device, modifier: Modifier, onClick: () -> Unit) {
    val pop = remember { Animatable(0.6f) }
    LaunchedEffect(d.id) { pop.animateTo(1f, tween(260)) }
    Column(
        modifier.scale(pop.value).width(96.dp).clip(RoundedCornerShape(18.dp)).clickable(onClick = onClick).padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(62.dp).clip(CircleShape).background(Saffron).padding(3.dp)) { Avatar(d.name, 56.dp) }
        Spacer(Modifier.height(4.dp))
        Text(d.name, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
    }
}

private fun openFile(ctx: Context, uri: Uri) {
    val type = ctx.contentResolver.getType(uri) ?: "*/*"
    val view = Intent(Intent.ACTION_VIEW).setDataAndType(uri, type)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    runCatching {
        ctx.startActivity(Intent.createChooser(view, tr("Open with", "اس سے کھولیں")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}


// ---------------- Pick files (Zapya-style tabs) ----------------

@Composable
private fun ConnectedScreen(vm: ShareViewModel) {
    val ctx = LocalContext.current
    var askDisconnect by remember { mutableStateOf(false) }
    // Two clear views: "Choose files to send" (main) and "Transfers" (progress list)
    var showTransfers by rememberSaveable { mutableStateOf(vm.transfers.isNotEmpty() && vm.picked.isEmpty()) }
    BackHandler {
        when {
            showTransfers -> showTransfers = false
            vm.connected -> askDisconnect = true
            else -> vm.goHome()
        }
    }
    var hasMedia by remember { mutableStateOf(hasMediaAccess(ctx)) }
    val mediaPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        hasMedia = hasMediaAccess(ctx)
        vm.loadLibrary(hasMedia)
    }
    val browse = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.addFiles(it) }
    LaunchedEffect(Unit) {
        vm.loadLibrary(hasMedia)
        if (!hasMedia) mediaPerm.launch(MEDIA_PERMS)
    }
    // The other phone started sending: show the progress (unless you're in the middle of picking)
    LaunchedEffect(vm.expectedCount) { if (vm.expectedCount > 0 && vm.picked.isEmpty()) showTransfers = true }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val tabs = listOf(
        tr("Photos", "تصاویر") to vm.photos, tr("Videos", "ویڈیوز") to vm.videos, tr("Apps", "ایپس") to vm.apps,
        tr("Music", "گانے") to vm.music, tr("Files", "فائلیں") to vm.docs,
    )

    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        PeerHeader(vm) { if (vm.connected) askDisconnect = true else vm.goHome() }
        EngineBanner(vm)
        RouterTip(vm)

        if (showTransfers) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = { showTransfers = false }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, tr("Back", "واپس")) }
                Text(tr("Transfers", "منتقلی"), style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                TextButton(onClick = { showTransfers = false }) {
                    Icon(Icons.Filled.Add, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(tr("Send more", "اور بھیجیں"), fontWeight = FontWeight.SemiBold)
                }
            }
            Box(Modifier.weight(1f).fillMaxWidth()) { TransfersPanel(vm) }
        } else {
            if (vm.transfers.isNotEmpty()) TransferStrip(vm) { showTransfers = true }
            Text(
                tr("Send to ${vm.peerName ?: "the other phone"}", "${vm.peerName ?: "دوسرے فون"} کو بھیجیں"),
                style = MaterialTheme.typography.headlineSmall, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 8.dp),
            )
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                tabs.forEachIndexed { i, (label, list) ->
                    val sel = tab == i
                    Row(
                        Modifier.clip(RoundedCornerShape(50)).background(if (sel) Saffron else card)
                            .clickable { tab = i }.padding(horizontal = 16.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(label, style = MaterialTheme.typography.labelLarge, color = if (sel) OnSaffron else MaterialTheme.colorScheme.onSurface)
                        if (list.isNotEmpty()) {
                            Spacer(Modifier.width(6.dp))
                            Text(
                                if (list.size > 9999) "9999+" else "${list.size}",
                                style = MaterialTheme.typography.labelMedium,
                                color = if (sel) OnSaffron.copy(alpha = 0.7f) else muted,
                            )
                        }
                    }
                }
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                val list = tabs[tab].second
                when {
                    tab in listOf(0, 1, 3) && !hasMedia -> MediaAccessCard { mediaPerm.launch(MEDIA_PERMS) }
                    vm.loading && list.isEmpty() -> Box(Modifier.align(Alignment.Center)) { Spinner() }
                    tab == 0 || tab == 1 -> MediaGrid(vm, list)
                    tab == 2 -> AppsGrid(vm, list)
                    tab == 3 -> ItemList(vm, list, null)
                    else -> FilesTab(vm, list) { browse.launch(arrayOf("*/*")) }
                }
            }
            if (vm.picked.isNotEmpty()) {
                SelectionBar(vm, enabled = vm.connected) { vm.sendSelected(); showTransfers = true }
            }
        }
    }
    TurboSetupDialog(vm)
    if (askDisconnect) {
        AppDialog(
            onDismiss = { askDisconnect = false },
            icon = { DialogIcon(Icons.Filled.LinkOff, MaterialTheme.colorScheme.error) },
            title = tr("Disconnect from ${vm.peerName ?: "this phone"}?", "${vm.peerName ?: "اس فون"} سے رابطہ ختم کریں؟"),
            message = tr("Files that are still moving will stop.", "جو فائلیں ابھی جا رہی ہیں وہ رک جائیں گی۔"),
            primary = tr("Disconnect", "رابطہ ختم کریں") to { askDisconnect = false; vm.goHome() },
            primaryDanger = true,
            secondary = tr("Stay connected", "جُڑے رہیں") to { askDisconnect = false },
        )
    }
}

/** Numbers about the whole transfer, shared by the strip and the full Transfers view. */
private class Stats(vm: ShareViewModel) {
    /** Rows of the transfer happening now (earlier files are not counted). */
    val list = vm.transfers.filter { vm.runUids.containsKey(it.uid) }
    private val counted = list.filter { it.state != TState.CANCELLED }
    val total = maxOf(vm.runExpectedBytes - list.filter { it.state == TState.CANCELLED }.sumOf { it.size }, counted.sumOf { it.size })
    val done = counted.sumOf { it.done }
    val count = maxOf(vm.runExpectedCount - (list.size - counted.size), counted.size)
    val doneCount = counted.count { it.state == TState.DONE }
    val busy = list.any { it.active }
    val sending = list.any { !it.incoming && it.active }
    val finished = list.isNotEmpty() && !busy && counted.isNotEmpty() && counted.size >= count
    /** Everything in this transfer was cancelled. */
    val allCancelled = list.isNotEmpty() && counted.isEmpty() && !busy
    val resumable = vm.resumable
    val speed = vm.liveSpeed
    val fraction = if (total > 0) (done.toFloat() / total).coerceIn(0f, 1f) else 0f
    /** Seconds left, or null when not known yet. */
    val etaSec: Long? = if (busy && speed > 1024) ((total - done).coerceAtLeast(0) / speed).toLong() else null

    fun title(): String = when {
        allCancelled -> tr("Transfer cancelled", "منتقلی منسوخ")
        finished -> if (doneCount == 1) tr("1 file done", "1 فائل مکمل") else tr("$doneCount files done", "$doneCount فائلیں مکمل")
        !busy && resumable > 0 -> tr("Paused", "رکا ہوا")
        sending -> tr("Sending ${minOf(doneCount + 1, count)} of $count", "$count میں سے ${minOf(doneCount + 1, count)} جا رہی ہے")
        busy -> tr("Receiving ${minOf(doneCount + 1, count)} of $count", "$count میں سے ${minOf(doneCount + 1, count)} آ رہی ہے")
        else -> tr("Transfer", "منتقلی")
    }
}

private fun etaText(sec: Long?): String {
    if (sec == null) return tr("Working out time left…", "باقی وقت کا اندازہ…")
    return when {
        sec < 5 -> tr("Almost done", "بس ہو گیا")
        sec < 60 -> tr("About $sec sec left", "تقریباً $sec سیکنڈ باقی")
        sec < 3600 -> { val m = (sec + 59) / 60; tr("About $m min left", "تقریباً $m منٹ باقی") }
        else -> { val h = sec / 3600; val m = (sec % 3600) / 60; tr("About ${h}h ${m}m left", "تقریباً $h گھنٹے $m منٹ باقی") }
    }
}

/** Small always-visible progress bar above the file tabs. Tap to see every file. */
@Composable
private fun TransferStrip(vm: ShareViewModel, onOpen: () -> Unit) {
    val st = Stats(vm)
    if (st.list.isEmpty()) return
    val title = st.title()
    val sub = when {
        st.busy -> listOfNotNull(if (st.speed > 0) "${fmt(st.speed.toLong())}/s" else null, etaText(st.etaSec)).joinToString("   ")
        else -> tr("Tap to see files", "فائلیں دیکھنے کے لیے ٹیپ کریں")
    }
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp).clip(RoundedCornerShape(20.dp))
            .background(card).clickable(onClick = onOpen).padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ProgressRing(if (st.finished) 1f else st.fraction, if (st.finished) Good else MaterialTheme.colorScheme.primary, 42.dp) {
            if (st.finished) Icon(Icons.Filled.Check, null, tint = Good, modifier = Modifier.size(20.dp))
            else Text("${(st.fraction * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = muted)
    }
}

@Composable
private fun ProgressRing(progress: Float, color: Color, size: Dp, content: @Composable () -> Unit) {
    val track = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.18f)
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = 4.dp.toPx()
            val tl = Offset(sw / 2, sw / 2)
            val sz = androidx.compose.ui.geometry.Size(this.size.width - sw, this.size.height - sw)
            drawArc(track, 0f, 360f, false, topLeft = tl, size = sz, style = Stroke(sw))
            drawArc(color, -90f, 360f * progress, false, topLeft = tl, size = sz, style = Stroke(sw, cap = StrokeCap.Round))
        }
        content()
    }
}

/** While the fast link is being set up: a clear popup so people wait (and know to tap Connect). */
@Composable
private fun TurboSetupDialog(vm: ShareViewModel) {
    var hidden by remember { mutableStateOf(false) }
    val show = vm.connected && vm.switching && !hidden
    LaunchedEffect(vm.switching) { if (!vm.switching) hidden = false }
    if (!show) return
    AppDialog(
        onDismiss = {}, dismissible = false,
        icon = { DialogIcon(Icons.Filled.Bolt, Saffron) },
        title = tr("Setting up Turbo speed", "ٹربو رفتار تیار ہو رہی ہے"),
        message = tr("This takes a few seconds. Keep both phones close.", "اس میں چند سیکنڈ لگتے ہیں۔ دونوں فون قریب رکھیں۔"),
        busy = true,
        content = {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.10f))
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.Info, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(
                    vm.joinTarget?.let {
                        tr("If Android shows a Wi-Fi list, tap “$it”. If it asks, tap Connect.",
                            "اگر اینڈرائیڈ وائی فائی کی فہرست دکھائے تو «$it» پر ٹیپ کریں۔ اگر پوچھے تو «کنیکٹ» دبائیں۔")
                    } ?: tr("If Android asks to connect to a device, tap Connect.", "اگر اینڈرائیڈ کسی ڈیوائس سے جُڑنے کا پوچھے تو «کنیکٹ» دبائیں۔"),
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        },
        secondary = tr("Continue in background", "پسِ منظر میں جاری رکھیں") to { hidden = true },
    )
}

/** Step-by-step timeline of the connection (tap the status under the phone name). */
@Composable
private fun ConnectionDetails(vm: ShareViewModel, onClose: () -> Unit) {
    val ctx = LocalContext.current
    AppDialog(
        onDismiss = onClose,
        title = tr("Connection details", "رابطے کی تفصیل"),
        message = "Asan Share v" + vm.appVersion,
        content = {
            LazyColumn(
                Modifier.fillMaxWidth().heightIn(max = 340.dp).clip(RoundedCornerShape(14.dp)).background(card).padding(10.dp),
            ) {
                items(vm.log.toList().asReversed()) { line ->
                    Text(line, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 3.dp))
                }
            }
        },
        primary = tr("Copy", "کاپی") to {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("Asan Share log", vm.log.joinToString("\n")))
        },
        secondary = tr("Close", "بند کریں") to onClose,
    )
}

/** "Also on home Wi-Fi" tip: the #1 reason a tablet/phone is slow in Turbo. */
@Composable
private fun RouterTip(vm: ShareViewModel) {
    if (!vm.routerTip || vm.link != 4) return
    val ctx = LocalContext.current
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp).clip(RoundedCornerShape(18.dp))
            .background(Saffron.copy(alpha = 0.16f)).padding(start = 14.dp, end = 8.dp, top = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Wifi, null, tint = Saffron, modifier = Modifier.size(22.dp))
        Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
            Text(tr("For full speed", "پوری رفتار کے لیے"), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
            Text(
                tr("This device is also on your home Wi-Fi, which slows Turbo a lot. Disconnect from it (keep Wi-Fi ON).",
                    "یہ ڈیوائس گھر کے وائی فائی سے بھی جُڑی ہے، اس سے ٹربو بہت سست ہو جاتا ہے۔ اس سے ڈسکنیکٹ کریں (وائی فائی آن رکھیں)۔"),
                style = MaterialTheme.typography.bodySmall, color = muted,
            )
        }
        Button(
            onClick = {
                val i = if (android.os.Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_WIFI) else Intent(Settings.ACTION_WIFI_SETTINGS)
                runCatching { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            },
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Saffron, contentColor = OnSaffron),
        ) { Text(tr("Wi-Fi", "وائی فائی"), fontWeight = FontWeight.Bold) }
    }
}

/** Tells the user plainly when the slower engine is in use, why, and how to fix it. */
@Composable
private fun EngineBanner(vm: ShareViewModel) {
    val note = vm.engineNote
    if (!vm.connected || vm.switching || vm.link == 4 || (note == null && !vm.peerOutdated)) return
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp).clip(RoundedCornerShape(18.dp))
            .background(Saffron.copy(alpha = 0.16f)).padding(start = 14.dp, end = 8.dp, top = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Bolt, null, tint = Saffron, modifier = Modifier.size(22.dp))
        Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
            Text(tr("Standard speed", "عام رفتار"), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
            Text(
                note ?: tr("The other phone has an older Asan Share. Update it for full speed.",
                    "دوسرے فون پر پرانا آسان شیئر ہے۔ پوری رفتار کے لیے اسے اپڈیٹ کریں۔"),
                style = MaterialTheme.typography.bodySmall, color = muted,
            )
        }
        if (vm.peerOutdated) {
            Button(
                onClick = vm::sendAppUpdate, shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Saffron, contentColor = OnSaffron),
            ) { Text(tr("Send update", "اپڈیٹ بھیجیں"), fontWeight = FontWeight.Bold) }
        } else if (note != null && note.startsWith(tr("Turbo couldn't", "ان فونز پر ٹربو"))) {
            Button(
                onClick = vm::retryTurbo, shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Saffron, contentColor = OnSaffron),
            ) { Text(tr("Try Turbo", "ٹربو آزمائیں"), fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun PeerHeader(vm: ShareViewModel, onClose: () -> Unit) {
    var details by remember { mutableStateOf(false) }
    if (details) ConnectionDetails(vm) { details = false }
    val on = vm.connected
    Row(
        Modifier.fillMaxWidth().padding(start = 4.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onClose) { Icon(Icons.Filled.Close, if (on) tr("Disconnect", "رابطہ ختم") else tr("Close", "بند کریں")) }
        Box {
            Avatar(vm.peerName ?: "?", 40.dp)
            Box(
                Modifier.align(Alignment.BottomEnd).size(13.dp).clip(CircleShape)
                    .background(MaterialTheme.colorScheme.background).padding(2.dp).clip(CircleShape)
                    .background(if (on) Good else MaterialTheme.colorScheme.error)
            )
        }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(
                vm.peerName ?: tr("Nearby phone", "قریبی فون"),
                style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(3.dp))
            val (label, tint, icon) = when {
                !on -> Triple(tr("Disconnected", "رابطہ ختم"), MaterialTheme.colorScheme.error, Icons.Filled.LinkOff)
                vm.switching -> Triple(tr("Setting up Turbo…", "ٹربو تیار ہو رہا ہے…"), Saffron, Icons.Filled.Bolt)
                vm.link == 4 -> Triple(tr("Turbo speed", "ٹربو رفتار"), Good, Icons.Filled.Bolt)
                vm.link >= 2 -> Triple(tr("Wi-Fi", "وائی فائی"), MaterialTheme.colorScheme.primary, Icons.Filled.Wifi)
                else -> Triple(tr("Standard speed", "عام رفتار"), muted, Icons.Filled.Bluetooth)
            }
            Row(
                Modifier.clip(RoundedCornerShape(50)).background(tint.copy(alpha = 0.14f)).clickable { details = true }
                    .padding(horizontal = 9.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(icon, null, tint = tint, modifier = Modifier.size(13.dp))
                Spacer(Modifier.width(4.dp))
                Text(label, color = tint, style = MaterialTheme.typography.labelMedium, maxLines = 1)
            }
        }
        IconButton(onClick = { details = true }) { Icon(Icons.Filled.Info, tr("Connection details", "رابطے کی تفصیل"), tint = muted) }
    }
}

@Composable
private fun FolderAccessCard(
    title: String = tr("Give files their own folder", "فائلوں کا اپنا فولڈر"),
    desc: String = tr("Save received files in “Asan Share” on your phone, not inside Downloads.",
        "موصول فائلیں ڈاؤن لوڈز کے بجائے فون میں «Asan Share» فولڈر میں محفوظ ہوں۔"),
) {
    val ctx = LocalContext.current
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f))
            .padding(start = 14.dp, end = 8.dp, top = 12.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Folder, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(
                desc,
                style = MaterialTheme.typography.bodySmall, color = muted,
            )
        }
        Button(onClick = {
            val pkg = Uri.parse("package:" + ctx.packageName)
            runCatching {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }.onFailure {
                runCatching { ctx.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            }
        }, shape = RoundedCornerShape(16.dp)) { Text(tr("Allow", "اجازت دیں")) }
    }
}

/** Opens WhatsApp chat directly (WhatsApp or WhatsApp Business), web as last resort. */
private fun openWhatsApp(ctx: Context) {
    val uri = Uri.parse("https://wa.me/923032901193")
    for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
        val ok = runCatching {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }.isSuccess
        if (ok) return
    }
    runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}

@Composable
private fun MediaAccessCard(onAllow: () -> Unit) {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(tr("Allow access to your photos, videos and music", "اپنی تصاویر، ویڈیوز اور گانوں تک رسائی دیں"), fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
            style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(6.dp))
        Text(tr("Asan Share only reads them to show here. Nothing is uploaded.", "آسان شیئر انہیں صرف یہاں دکھانے کے لیے پڑھتا ہے۔ کچھ اپ لوڈ نہیں ہوتا۔"), color = muted, textAlign = TextAlign.Center)
        Spacer(Modifier.height(18.dp))
        Button(onClick = onAllow, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp), shape = RoundedCornerShape(16.dp)) { Text(tr("Allow", "اجازت دیں")) }
        TextButton(onClick = {
            runCatching {
                ctx.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }) { Text(tr("Open app settings", "ایپ کی سیٹنگز کھولیں")) }
    }
}

@Composable
private fun GridHeader(vm: ShareViewModel, list: List<MediaItem>, label: String) {
    val all = list.isNotEmpty() && list.all { vm.isSelected(it) }
    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = muted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
        if (list.isNotEmpty()) TextButton(onClick = { vm.selectAll(list, !all) }) { Text(if (all) tr("Unselect all", "سب ہٹائیں") else tr("Select all", "سب چنیں")) }
    }
}

@Composable
private fun EmptyNote(text: String) {
    Text(text, color = muted, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(32.dp))
}

@Composable
private fun AppsGrid(vm: ShareViewModel, list: List<MediaItem>) {
    val tick = rememberTick()
    LazyVerticalGrid(
        columns = GridCells.Adaptive(86.dp),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) { GridHeader(vm, list, tr("${list.size} apps", "${list.size} ایپس")) }
        if (list.isEmpty()) item(span = { GridItemSpan(maxLineSpan) }) { EmptyNote(tr("No apps found", "کوئی ایپ نہیں ملی")) }
        items(list.size, key = { list[it].key }) { idx ->
            val item = list[idx]
            val sel = vm.isSelected(item)
            Column(
                Modifier.clip(RoundedCornerShape(16.dp))
                    .background(if (sel) Saffron.copy(alpha = 0.2f) else Color.Transparent)
                    .clickable { tick(); vm.toggle(item) }
                    .padding(vertical = 10.dp, horizontal = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box {
                    Thumb(item, Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)), ContentScale.Fit)
                    if (sel) CheckDot(true, onImage = true, modifier = Modifier.align(Alignment.TopEnd).offset(x = 6.dp, y = (-6).dp))
                }
                Spacer(Modifier.height(6.dp))
                Text(item.name.removeSuffix(".apk"), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                Text(fmt(item.size), fontSize = 10.sp, color = muted)
            }
        }
    }
}

@Composable
private fun MediaGrid(vm: ShareViewModel, list: List<MediaItem>) {
    val tick = rememberTick()
    LazyVerticalGrid(
        columns = GridCells.Adaptive(104.dp),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) { GridHeader(vm, list, tr("${list.size} items", "${list.size} آئٹمز")) }
        if (list.isEmpty()) item(span = { GridItemSpan(maxLineSpan) }) { EmptyNote(tr("Nothing here yet", "یہاں ابھی کچھ نہیں")) }
        items(list.size, key = { list[it].key }) { idx ->
            val item = list[idx]
            val sel = vm.isSelected(item)
            Box(Modifier.aspectRatio(1f).clip(RoundedCornerShape(10.dp)).background(card).clickable { tick(); vm.toggle(item) }) {
                Thumb(item, Modifier.fillMaxSize(), ContentScale.Crop)
                if (item.kind == Kind.VIDEO && item.extra.isNotEmpty()) {
                    Text(
                        item.extra, color = Color.White, fontSize = 11.sp,
                        modifier = Modifier.align(Alignment.BottomEnd).padding(5.dp).clip(RoundedCornerShape(6.dp))
                            .background(Color.Black.copy(alpha = 0.55f)).padding(horizontal = 5.dp, vertical = 1.dp),
                    )
                }
                if (sel) Box(Modifier.fillMaxSize().background(Ink.copy(alpha = 0.35f)))
                CheckDot(sel, onImage = true, modifier = Modifier.align(Alignment.TopEnd).padding(6.dp))
            }
        }
    }
}

@Composable
private fun ItemList(vm: ShareViewModel, list: List<MediaItem>, onBrowse: (() -> Unit)?) {
    val tick = rememberTick()
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        if (onBrowse != null) item {
            OutlinedButton(
                onClick = onBrowse, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp), shape = RoundedCornerShape(16.dp),
            ) {
                Icon(Icons.Filled.Search, null)
                Spacer(Modifier.width(8.dp))
                Text(tr("Browse phone storage", "فون کی اسٹوریج دیکھیں"))
            }
        }
        item { GridHeader(vm, list, tr("${list.size} items", "${list.size} آئٹمز")) }
        if (list.isEmpty()) item {
            EmptyNote(if (onBrowse != null) tr("Use Browse phone storage to pick any file.", "کوئی بھی فائل چننے کے لیے «فون کی اسٹوریج دیکھیں» دبائیں۔") else tr("Nothing here yet", "یہاں ابھی کچھ نہیں"))
        }
        items(list, key = { it.key }) { item ->
            val sel = vm.isSelected(item)
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                    .background(if (sel) Saffron.copy(alpha = 0.18f) else card)
                    .clickable { tick(); vm.toggle(item) }.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (item.name.endsWith(".apk", ignoreCase = true) && item.path != null)
                    Thumb(item, Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)), ContentScale.Fit)
                else FileBadge(item.name)
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                    Text(
                        listOf(fmt(item.size), item.extra).filter { it.isNotEmpty() }.joinToString("   "),
                        style = MaterialTheme.typography.bodySmall, color = muted,
                    )
                }
                CheckDot(sel, onImage = false)
            }
        }
    }
}

@Composable
private fun SelectionBar(vm: ShareViewModel, enabled: Boolean, onSend: () -> Unit) {
    val total = vm.picked.sumOf { it.size }
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp)
            .shadow(18.dp, RoundedCornerShape(26.dp), clip = false)
            .clip(RoundedCornerShape(26.dp)).background(MaterialTheme.colorScheme.surface)
            .padding(start = 18.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(tr("${vm.picked.size} selected", "${vm.picked.size} منتخب"), style = MaterialTheme.typography.titleSmall)
            Text(fmt(total), color = muted, style = MaterialTheme.typography.bodySmall)
        }
        TextButton(onClick = vm::clearSelection) { Text(tr("Clear", "صاف کریں"), color = muted) }
        PrimaryCta(tr("Send", "بھیجیں"), Icons.AutoMirrored.Filled.Send, enabled = enabled, onClick = onSend)
    }
}

@Composable
private fun CheckDot(selected: Boolean, onImage: Boolean, modifier: Modifier = Modifier) {
    Box(
        modifier.size(24.dp).clip(CircleShape)
            .background(if (selected) Saffron else if (onImage) Color.Black.copy(alpha = 0.25f) else Color.Transparent)
            .border(2.dp, if (selected) Saffron else if (onImage) Color.White else muted, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        if (selected) Icon(Icons.Filled.Check, null, tint = Ink, modifier = Modifier.size(16.dp))
    }
}

@Composable
private fun Thumb(item: MediaItem, modifier: Modifier, scale: ContentScale) {
    val ctx = LocalContext.current
    val bmp: ImageBitmap? by produceState(Thumbs.cached(item.key), item.key) {
        if (value == null) value = Thumbs.load(ctx, item)
    }
    val b = bmp
    if (b != null) Image(b, null, modifier, contentScale = scale)
    else Box(modifier.background(card))
}


@Composable
private fun rememberTick(): () -> Unit {
    val haptic = LocalHapticFeedback.current
    return remember(haptic) { { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) } }
}

// ---------------- Received files ----------------

@Composable
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
private fun ReceivedScreen(vm: ShareViewModel, embedded: Boolean = false, onBack: () -> Unit = vm::goHome) {
    BackHandler { onBack() }
    val ctx = LocalContext.current
    var grid by rememberSaveable { mutableStateOf(true) }
    var filter by rememberSaveable { mutableIntStateOf(0) }
    val all = vm.received
    fun isApk(m: MediaItem) = m.name.endsWith(".apk", ignoreCase = true)
    val groups = listOf(
        tr("All", "سب") to all,
        tr("Photos", "تصاویر") to all.filter { it.kind == Kind.PHOTO },
        tr("Videos", "ویڈیوز") to all.filter { it.kind == Kind.VIDEO },
        tr("Apps", "ایپس") to all.filter { isApk(it) },
        tr("Other", "دیگر") to all.filter { it.kind == Kind.FILE && !isApk(it) },
    )
    val list = groups[filter].second
    // press and hold to select; then delete from the phone
    val selected = remember { mutableStateMapOf<String, Boolean>() }
    val selecting = selected.isNotEmpty()
    var askDelete by remember { mutableStateOf(false) }
    val androidAsk = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { vm.loadReceived() }
    BackHandler(enabled = selecting) { selected.clear() }
    fun toggle(m: MediaItem) { if (selected.containsKey(m.key)) selected.remove(m.key) else selected[m.key] = true }

    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        if (selecting) {
            Row(
                Modifier.fillMaxWidth().height(64.dp).padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = { selected.clear() }) { Icon(Icons.Filled.Close, tr("Cancel", "منسوخ")) }
                Text(tr("${selected.size} selected", "${selected.size} منتخب"), style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                TextButton(onClick = { list.forEach { selected[it.key] = true } }) { Text(tr("All", "سب")) }
                IconButton(onClick = { askDelete = true }) { Icon(Icons.Filled.Delete, tr("Delete", "ڈیلیٹ"), tint = MaterialTheme.colorScheme.error) }
            }
        } else
        // Top bar: back, title + count, grid/list switch
        Row(
            Modifier.fillMaxWidth().height(64.dp).padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (!embedded) IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, tr("Back", "واپس")) }
            else Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(tr("Received files", "موصول شدہ فائلیں"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(
                    tr("${all.size} files, ${fmt(all.sumOf { it.size })}", "${all.size} فائلیں، ${fmt(all.sumOf { it.size })}"),
                    style = MaterialTheme.typography.bodySmall, color = muted,
                )
            }
            IconButton(onClick = { openSaveFolder(ctx, vm.saveFolderRelative()) }) {
                Icon(Icons.Filled.FolderOpen, tr("Open folder", "فولڈر کھولیں"))
            }
            IconButton(onClick = { grid = !grid }) {
                Icon(
                    if (grid) Icons.AutoMirrored.Filled.ViewList else Icons.Filled.GridView,
                    if (grid) tr("List view", "فہرست") else tr("Grid view", "گرڈ"),
                )
            }
        }
        // Filter chips
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
        ) {
            items(groups.size) { i ->
                val sel = filter == i
                val (label, items) = groups[i]
                Text(
                    "$label  ${items.size}",
                    fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium,
                    color = if (sel) Color.White else MaterialTheme.colorScheme.onSurface,
                    style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier.clip(RoundedCornerShape(50))
                        .background(if (sel) Ink else card)
                        .clickable { filter = i }
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                )
            }
        }

        if (list.isEmpty()) {
            Column(
                Modifier.fillMaxSize().padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Box(Modifier.size(84.dp).clip(CircleShape).background(card), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.Folder, null, tint = muted, modifier = Modifier.size(40.dp))
                }
                Spacer(Modifier.height(16.dp))
                Text(tr("No files yet", "ابھی کوئی فائل نہیں"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(tr("Files you receive will show up here.", "موصول ہونے والی فائلیں یہاں نظر آئیں گی۔"), color = muted, textAlign = TextAlign.Center)
            }
        } else if (grid) {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(108.dp),
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                items(list.size, key = { list[it].key }) { idx ->
                    val item = list[idx]
                    ReceivedTile(
                        item, isApk(item), selected = selected.containsKey(item.key), selecting = selecting,
                        onLongClick = { toggle(item) },
                    ) { if (selecting) toggle(item) else openFile(ctx, item.uri) }
                }
            }
        } else {
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(list, key = { it.key }) { item ->
                    val sel = selected.containsKey(item.key)
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                            .background(if (sel) Saffron.copy(alpha = 0.18f) else card)
                            .combinedClickable(
                                onClick = { if (selecting) toggle(item) else openFile(ctx, item.uri) },
                                onLongClick = { toggle(item) },
                            ).padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        if (selecting) { CheckDot(sel, onImage = false); Spacer(Modifier.width(10.dp)) }
                        if (item.kind == Kind.PHOTO || item.kind == Kind.VIDEO || isApk(item))
                            Thumb(item, Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)), if (isApk(item)) ContentScale.Fit else ContentScale.Crop)
                        else FileBadge(item.name)
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                            Text(fmt(item.size), style = MaterialTheme.typography.bodySmall, color = muted)
                        }
                        if (!selecting) Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = muted)
                    }
                }
            }
        }
    }
    if (askDelete) {
        val chosen = all.filter { selected.containsKey(it.key) }
        AppDialog(
            onDismiss = { askDelete = false },
            icon = { DialogIcon(Icons.Filled.Delete, MaterialTheme.colorScheme.error) },
            title = if (chosen.size == 1) tr("Delete this file?", "یہ فائل ڈیلیٹ کریں؟") else tr("Delete ${chosen.size} files?", "${chosen.size} فائلیں ڈیلیٹ کریں؟"),
            message = tr("They'll be removed from this phone's storage (${fmt(chosen.sumOf { it.size })}). This can't be undone.",
                "یہ اس فون کی اسٹوریج سے ہٹا دی جائیں گی (${fmt(chosen.sumOf { it.size })})۔ واپس نہیں آ سکیں گی۔"),
            primary = tr("Delete", "ڈیلیٹ کریں") to {
                askDelete = false
                vm.deleteReceived(chosen) { sender -> androidAsk.launch(androidx.activity.result.IntentSenderRequest.Builder(sender).build()) }
                selected.clear()
            },
            primaryDanger = true,
            secondary = tr("Cancel", "منسوخ") to { askDelete = false },
        )
    }
}

/** One square in the grid: real preview for photos, videos and apps; a neat label for other files. */
@Composable
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
private fun ReceivedTile(item: MediaItem, apk: Boolean, selected: Boolean, selecting: Boolean, onLongClick: () -> Unit, onClick: () -> Unit) {
    Box(
        Modifier.aspectRatio(1f).clip(RoundedCornerShape(14.dp)).background(card)
            .then(if (selected) Modifier.border(3.dp, Saffron, RoundedCornerShape(14.dp)) else Modifier)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
    ) {
        when {
            item.kind == Kind.PHOTO || item.kind == Kind.VIDEO ->
                Thumb(item, Modifier.fillMaxSize(), ContentScale.Crop)
            apk -> Box(Modifier.fillMaxSize().padding(bottom = 22.dp), contentAlignment = Alignment.Center) {
                Thumb(item, Modifier.size(56.dp).clip(RoundedCornerShape(14.dp)), ContentScale.Fit)
            }
            else -> Box(Modifier.fillMaxSize().padding(bottom = 22.dp), contentAlignment = Alignment.Center) { FileBadge(item.name) }
        }
        if (item.kind == Kind.VIDEO) {
            Box(
                Modifier.align(Alignment.Center).size(38.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.45f)),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Filled.PlayArrow, null, tint = Color.White, modifier = Modifier.size(24.dp)) }
        }
        if (selecting) CheckDot(selected, onImage = true, modifier = Modifier.align(Alignment.TopEnd).padding(6.dp))
        if (item.kind != Kind.PHOTO) {
            Text(
                item.name,
                maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp,
                color = if (item.kind == Kind.VIDEO) Color.White else MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                    .background(
                        if (item.kind == Kind.VIDEO) Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.6f)))
                        else Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent))
                    )
                    .padding(horizontal = 6.dp, vertical = 5.dp),
            )
        }
    }
}

/** Files tab: every APK, PDF, Office, ZIP and design file, with quick categories. */
@Composable
private fun FilesTab(vm: ShareViewModel, list: List<MediaItem>, onBrowse: () -> Unit) {
    var sub by rememberSaveable { mutableIntStateOf(0) }
    fun ext(m: MediaItem) = m.name.substringAfterLast('.', "").lowercase()
    val urdu = Lang.urdu
    val groups = remember(list, urdu) { listOf(
        tr("All", "سب") to list,
        "APK" to list.filter { ext(it) in APK_EXTS },
        tr("Documents", "دستاویزات") to list.filter { ext(it) in DOC_EXTS },
        "ZIP" to list.filter { ext(it) in ARCHIVE_EXTS },
        tr("Design", "ڈیزائن") to list.filter { ext(it) in DESIGN_EXTS },
    ) }
    Column(Modifier.fillMaxSize()) {
        if (android.os.Build.VERSION.SDK_INT >= 30 && !vm.ownFolder) {
            Box(Modifier.padding(start = 12.dp, end = 12.dp, top = 8.dp)) {
                FolderAccessCard(
                    tr("See all your files", "اپنی تمام فائلیں دیکھیں"),
                    tr("Allow access to show every APK, PDF, ZIP and other file on this phone.",
                        "اس فون کی ہر APK، PDF، ZIP اور دوسری فائل دکھانے کے لیے اجازت دیں۔"),
                )
            }
        }
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(groups.size) { i ->
                val selected = sub == i
                Text(
                    "${groups[i].first}  ${groups[i].second.size}",
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                    color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface,
                    style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(if (selected) Ink else card)
                        .clickable { sub = i }.padding(horizontal = 14.dp, vertical = 8.dp),
                )
            }
        }
        Box(Modifier.weight(1f)) { ItemList(vm, groups[sub].second, onBrowse) }
    }
}

private fun urName(p: String) = when (p) {
    "Bluetooth" -> "بلوٹوتھ"
    "Wi-Fi" -> "وائی فائی"
    else -> "لوکیشن"
}


// ======================= ZAPYA-STYLE GROUPS =======================

@Composable
private fun GroupButtons(vm: ShareViewModel) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GroupButton(
                Icons.Filled.Wifi, tr("Create group", "گروپ بنائیں"), tr("Other phone joins you", "دوسرا فون آپ کو جوائن کرے"),
                Saffron, OnSaffron, Modifier.weight(1f).fillMaxHeight(), { vm.createGroup() },
            )
            GroupButton(
                Icons.Filled.Search, tr("Join group", "گروپ جوائن کریں"), tr("Find the other phone's group", "دوسرے فون کا گروپ ڈھونڈیں"),
                Ink, Color.White, Modifier.weight(1f).fillMaxHeight(), vm::openJoin,
            )
        }
        Spacer(Modifier.height(6.dp))
        Text(
            tr("Fastest and most reliable, like Zapya. Works without internet.", "سب سے تیز اور قابلِ بھروسہ، زاپیا کی طرح۔ انٹرنیٹ کے بغیر چلتا ہے۔"),
            style = MaterialTheme.typography.bodySmall, color = muted, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Composable
private fun GroupButton(icon: ImageVector, title: String, sub: String, bg: Color, fg: Color, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.clip(RoundedCornerShape(24.dp)).background(bg).clickable(onClick = onClick).padding(16.dp)) {
        Icon(icon, null, tint = fg, modifier = Modifier.size(28.dp))
        Spacer(Modifier.height(10.dp))
        Text(title, color = fg, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(sub, color = fg.copy(alpha = 0.8f), style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun GroupHostScreen(vm: ShareViewModel) {
    BackHandler { vm.cancelGroup() }
    val info = vm.groupInfo
    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        TopBar(tr("Create group", "گروپ بنائیں"), vm::cancelGroup)
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            val err = vm.groupError
            if (err != null) {
                Spacer(Modifier.height(24.dp))
                Icon(Icons.Filled.Warning, null, tint = Saffron, modifier = Modifier.size(48.dp))
                Spacer(Modifier.height(12.dp))
                Text(err, textAlign = TextAlign.Center)
                Spacer(Modifier.height(20.dp))
                Button(onClick = { vm.createGroup() }, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp), shape = RoundedCornerShape(16.dp)) {
                    Text(tr("Try again", "دوبارہ کوشش کریں"))
                }
                TextButton(onClick = { vm.cancelGroup(); vm.openJoin() }) { Text(tr("Join a group instead", "اس کے بجائے گروپ جوائن کریں")) }
                return@Column
            }
            if (info == null) {
                Spacer(Modifier.height(60.dp))
                Spinner(56.dp)
                Spacer(Modifier.height(16.dp))
                Text(vm.groupStatus, color = muted, textAlign = TextAlign.Center)
                return@Column
            }
            Pulse(Saffron, 150.dp) {
                Box(Modifier.size(70.dp).clip(CircleShape).background(Saffron), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.Wifi, null, tint = Ink, modifier = Modifier.size(36.dp))
                }
            }
            Text(info.ssid.removePrefix(com.k2.share.Turbo.GROUP_PREFIX), fontWeight = FontWeight.Bold, fontSize = 22.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(4.dp))
            Text(vm.groupStatus, color = muted, textAlign = TextAlign.Center)
            vm.groupBandText?.let { band ->
                val fast = band.startsWith("5")
                Spacer(Modifier.height(10.dp))
                Text(
                    if (fast) tr("$band, fast", "$band، تیز") else tr("$band, slower", "$band، کم رفتار"),
                    fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge,
                    color = if (fast) Good else Saffron,
                    modifier = Modifier.clip(RoundedCornerShape(50)).background((if (fast) Good else Saffron).copy(alpha = 0.15f))
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                )
            }
            if (vm.groupOnRouter && vm.groupBandText?.startsWith("5") != true) {
                val ctx = LocalContext.current
                Spacer(Modifier.height(12.dp))
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Saffron.copy(alpha = 0.14f))
                        .padding(start = 14.dp, end = 8.dp, top = 10.dp, bottom = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        tr("This phone is on home Wi-Fi, so the group may be slower. For full speed, disconnect from home Wi-Fi (keep Wi-Fi ON) and create the group again, or create it on the other phone.",
                            "یہ فون گھر کے وائی فائی سے جُڑا ہے، اس لیے گروپ سست ہو سکتا ہے۔ پوری رفتار کے لیے گھر کا وائی فائی ڈسکنیکٹ کریں (وائی فائی آن رکھیں) اور دوبارہ گروپ بنائیں، یا دوسرے فون پر گروپ بنائیں۔"),
                        style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f),
                    )
                    TextButton(onClick = {
                        val i = if (android.os.Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_WIFI) else Intent(Settings.ACTION_WIFI_SETTINGS)
                        runCatching { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                    }) { Text(tr("Wi-Fi", "وائی فائی"), fontWeight = FontWeight.Bold) }
                }
            }
            Spacer(Modifier.height(18.dp))
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(card).padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    if (info.viaHotspot) tr("On the other phone: Join group → Scan QR", "دوسرے فون پر: گروپ جوائن کریں ← QR اسکین")
                    else tr("On the other phone: tap Join group and pick this name. Or scan:", "دوسرے فون پر: «گروپ جوائن کریں» دبا کر یہ نام چنیں۔ یا اسکین کریں:"),
                    fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(12.dp))
                val img = remember(info.qr) { AppInvite.qr(info.qr) }
                if (img != null) Image(img, "QR", Modifier.size(220.dp).clip(RoundedCornerShape(16.dp)).background(Color.White).padding(10.dp))
                Spacer(Modifier.height(10.dp))
                Text(tr("Wi-Fi: ", "وائی فائی: ") + info.ssid, style = MaterialTheme.typography.bodySmall, color = muted)
                Text(tr("Password: ", "پاس ورڈ: ") + info.pass, style = MaterialTheme.typography.bodySmall, color = muted)
            }
            Spacer(Modifier.height(10.dp))
            if (!info.viaHotspot) {
                Text(
                    tr("Other phone can't find this group?", "دوسرے فون کو یہ گروپ نہیں مل رہا؟"),
                    style = MaterialTheme.typography.bodySmall, color = muted, textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(8.dp))
                PrimaryCta(tr("Compatible mode (2.4 GHz)", "مطابقت موڈ (2.4 GHz)"), Icons.Filled.Wifi, Modifier.fillMaxWidth()) {
                    vm.createGroup(compatible = true)
                }
                Spacer(Modifier.height(4.dp))
                TextButton(onClick = { vm.createGroup(hotspotMode = true) }) {
                    Text(tr("Still not working? Use hotspot mode", "پھر بھی نہیں؟ ہاٹ اسپاٹ موڈ"), color = muted)
                }
            }
            TextButton(onClick = vm::cancelGroup) { Text(tr("Cancel", "منسوخ")) }
        }
    }
}

@Composable
private fun GroupJoinScreen(vm: ShareViewModel) {
    BackHandler { vm.cancelGroup() }
    val ctx = LocalContext.current
    val camPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) vm.openQrScanner() }
    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        TopBar(tr("Join group", "گروپ جوائن کریں"), vm::cancelGroup)
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            if (vm.joining) {
                item {
                    Column(Modifier.fillMaxWidth().padding(top = 40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Spinner(56.dp)
                        Spacer(Modifier.height(16.dp))
                        Text(vm.groupStatus, textAlign = TextAlign.Center)
                    }
                }
                return@LazyColumn
            }
            vm.groupError?.let { e ->
                item {
                    Text(e, color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(card).padding(14.dp))
                }
            }
            item {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Pulse(MaterialTheme.colorScheme.primary, 150.dp) {
                        Icon(Icons.Filled.Search, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp))
                    }
                    Text(
                        if (vm.foundGroups.isEmpty()) tr("Looking for groups… On the other phone tap Create group.", "گروپ تلاش ہو رہے ہیں… دوسرے فون پر «گروپ بنائیں» دبائیں۔")
                        else tr("Tap a group to join", "جوائن کرنے کے لیے گروپ پر ٹیپ کریں"),
                        textAlign = TextAlign.Center, color = muted,
                    )
                }
            }
            items(vm.foundGroups, key = { it.first }) { (ssid, level) ->
                val name = ssid.removePrefix(com.k2.share.Turbo.GROUP_PREFIX)
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(card).clickable { vm.joinFound(ssid) }.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Avatar(name, 48.dp)
                    Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                        Text(name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            when { level > -55 -> tr("Very close", "بہت قریب"); level > -70 -> tr("Nearby", "قریب"); else -> tr("A bit far", "تھوڑا دور") },
                            style = MaterialTheme.typography.bodySmall, color = muted,
                        )
                    }
                    Text(tr("Join", "جوائن"), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                }
            }
            item {
                OutlinedButton(
                    onClick = {
                        if (androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.CAMERA) ==
                            android.content.pm.PackageManager.PERMISSION_GRANTED) vm.openQrScanner()
                        else camPerm.launch(android.Manifest.permission.CAMERA)
                    },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp), shape = RoundedCornerShape(16.dp),
                ) {
                    Text(tr("Scan QR code", "QR کوڈ اسکین کریں"), fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Suppress("DEPRECATION")
@Composable
private fun QrScanScreen(vm: ShareViewModel) {
    BackHandler { vm.closeQrScanner() }
    val ctx = LocalContext.current
    val owner = androidx.compose.ui.platform.LocalLifecycleOwner.current
    DisposableEffect(Unit) {
        onDispose { runCatching { androidx.camera.lifecycle.ProcessCameraProvider.getInstance(ctx).get().unbindAll() } }
    }
    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        TopBar(tr("Scan the group QR code", "گروپ کا QR کوڈ اسکین کریں"), vm::closeQrScanner)
        Box(Modifier.fillMaxWidth().weight(1f).padding(16.dp).clip(RoundedCornerShape(24.dp))) {
            androidx.compose.ui.viewinterop.AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { c ->
                    val pv = androidx.camera.view.PreviewView(c)
                    val future = androidx.camera.lifecycle.ProcessCameraProvider.getInstance(c)
                    future.addListener({
                        runCatching {
                            val provider = future.get()
                            val preview = androidx.camera.core.Preview.Builder().build().also { it.setSurfaceProvider(pv.surfaceProvider) }
                            val analysis = androidx.camera.core.ImageAnalysis.Builder()
                                .setBackpressureStrategy(androidx.camera.core.ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                            val reader = com.google.zxing.qrcode.QRCodeReader()
                            var done = false
                            analysis.setAnalyzer(java.util.concurrent.Executors.newSingleThreadExecutor()) { img ->
                                if (!done) {
                                    val plane = img.planes[0]
                                    val buf = plane.buffer
                                    val data = ByteArray(buf.remaining()); buf.get(data)
                                    val src = com.google.zxing.PlanarYUVLuminanceSource(data, plane.rowStride, img.height, 0, 0, img.width, img.height, false)
                                    val text = runCatching { reader.decode(com.google.zxing.BinaryBitmap(com.google.zxing.common.HybridBinarizer(src))).text }.getOrNull()
                                    if (text != null && text.startsWith("ASANSHARE|")) {
                                        done = true
                                        pv.post { provider.unbindAll(); vm.onQrScanned(text) }
                                    }
                                }
                                img.close()
                            }
                            provider.unbindAll()
                            provider.bindToLifecycle(owner, androidx.camera.core.CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                        }
                    }, androidx.core.content.ContextCompat.getMainExecutor(c))
                    pv
                },
            )
        }
        Text(
            tr("Point the camera at the QR code on the other phone.", "کیمرہ دوسرے فون کے QR کوڈ کی طرف کریں۔"),
            color = muted, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(16.dp),
        )
    }
}


// ======================= DIALOGS: one clean, consistent design =======================

/**
 * Every popup in the app: centred card, clear icon, short title + message, full-width main button,
 * quiet second button. No empty space, no tiny buttons in the corner.
 */
@Composable
private fun AppDialog(
    onDismiss: () -> Unit,
    title: String,
    dismissible: Boolean = true,
    icon: (@Composable () -> Unit)? = null,
    message: String? = null,
    busy: Boolean = false,
    content: (@Composable () -> Unit)? = null,
    primary: Pair<String, () -> Unit>? = null,
    primaryDanger: Boolean = false,
    secondary: Pair<String, () -> Unit>? = null,
) {
    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(
            dismissOnBackPress = dismissible, dismissOnClickOutside = dismissible,
            usePlatformDefaultWidth = false, decorFitsSystemWindows = false,
        ),
    ) {
        // place the sheet at the bottom, full width, sliding up
        val window = (LocalView.current.parent as? androidx.compose.ui.window.DialogWindowProvider)?.window
        SideEffect {
            window?.setGravity(android.view.Gravity.BOTTOM)
            window?.setLayout(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT)
            window?.setDimAmount(0.55f)
        }
        var shown by remember { mutableStateOf(false) }
        LaunchedEffect(Unit) { shown = true }
        val lift by animateFloatAsState(if (shown) 0f else 1f, animationSpec = androidx.compose.animation.core.tween(260), label = "sheet")
        val sheetShape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp)
        CompositionLocalProvider(
            LocalLayoutDirection provides if (Lang.urdu) LayoutDirection.Rtl else LayoutDirection.Ltr,
            LocalContentColor provides MaterialTheme.colorScheme.onSurface,
        ) {
            Column(
                Modifier.fillMaxWidth().graphicsLayer { translationY = lift * 400f; alpha = 1f - lift * 0.6f }
                    .clip(sheetShape).background(MaterialTheme.colorScheme.surface)
                    .navigationBarsPadding()
                    .padding(start = 24.dp, end = 24.dp, top = 12.dp, bottom = 16.dp)
                    .widthIn(max = 560.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                // drag handle
                Box(Modifier.width(40.dp).height(4.dp).clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f)))
                Spacer(Modifier.height(20.dp))
                if (icon != null) { icon(); Spacer(Modifier.height(16.dp)) }
                Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                if (message != null) {
                    Spacer(Modifier.height(8.dp))
                    Text(message, color = muted, textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium)
                }
                if (busy) {
                    Spacer(Modifier.height(20.dp))
                    BusyBar()
                }
                if (content != null) {
                    Spacer(Modifier.height(16.dp))
                    content()
                }
                Spacer(Modifier.height(24.dp))
                if (primary != null) {
                    Button(
                        onClick = primary.second,
                        modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp),
                        shape = RoundedCornerShape(50),
                        colors = if (primaryDanger) ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error, contentColor = Color.White)
                        else ButtonDefaults.buttonColors(containerColor = Saffron, contentColor = OnSaffron),
                    ) { Text(primary.first, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall, textAlign = TextAlign.Center) }
                }
                if (secondary != null) {
                    if (primary != null) Spacer(Modifier.height(8.dp))
                    TextButton(
                        onClick = secondary.second,
                        modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
                        shape = RoundedCornerShape(50),
                    ) {
                        Text(secondary.first, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.titleSmall)
                    }
                }
            }
        }
    }
}

/** Round tinted icon used at the top of dialogs. */
@Composable
private fun DialogIcon(icon: ImageVector, tint: Color) {
    Box(
        Modifier.size(72.dp).clip(CircleShape)
            .background(Brush.radialGradient(listOf(tint.copy(alpha = 0.30f), tint.copy(alpha = 0.08f)))),
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.size(48.dp).clip(CircleShape).background(tint.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(28.dp))
        }
    }
}

/** Slim moving bar (keeps moving even with system animations off). */
@Composable
private fun BusyBar() {
    val phase = rememberLoopPhase(1300)
    val color = MaterialTheme.colorScheme.primary
    val track = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.15f)
    Canvas(Modifier.fillMaxWidth(0.6f).height(6.dp).clip(RoundedCornerShape(50))) {
        drawRect(track)
        val w = size.width * 0.35f
        val x = (size.width + w) * phase.value - w
        drawRoundRect(color, topLeft = Offset(x, 0f), size = androidx.compose.ui.geometry.Size(w, size.height),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(size.height / 2, size.height / 2))
    }
}

/** One permission at a time: why we need it, then Android's own "Allow" popup (or Settings if it was blocked). */
@Composable
fun PermissionAsk(title: String, why: String, required: Boolean, blocked: Boolean, onAllow: () -> Unit, onSkip: () -> Unit) {
    val note: (@Composable () -> Unit)? = if (!blocked) null else ({
        Text(
            tr("This permission was turned off. Tap Open settings, then Permissions, and allow it.",
                "یہ اجازت بند کر دی گئی تھی۔ «سیٹنگز کھولیں» دبائیں، پھر اجازتوں میں جا کر اسے آن کریں۔"),
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center,
        )
    })
    AppDialog(
        onDismiss = {}, dismissible = false,
        icon = { DialogIcon(Icons.Filled.Lock, MaterialTheme.colorScheme.primary) },
        title = title,
        message = why,
        content = note,
        primary = (if (blocked) tr("Open settings", "سیٹنگز کھولیں") else tr("Allow", "اجازت دیں")) to onAllow,
        secondary = if (required) null else tr("Not now", "ابھی نہیں") to onSkip,
    )
}


/** Open the folder where received files are saved, in the phone's own file manager. */
private fun openSaveFolder(ctx: Context, relative: String) {
    val docId = "primary:$relative"
    val attempts = listOf(
        // Files by Google / Android's file manager: open exactly this folder
        Intent(Intent.ACTION_VIEW).setDataAndType(
            android.provider.DocumentsContract.buildDocumentUri("com.android.externalstorage.documents", docId),
            android.provider.DocumentsContract.Document.MIME_TYPE_DIR,
        ),
        Intent("android.provider.action.BROWSE").setData(
            android.provider.DocumentsContract.buildDocumentUri("com.android.externalstorage.documents", docId)
        ),
        // many brand file managers (OPPO, TECNO, Xiaomi) understand a folder path
        Intent(Intent.ACTION_VIEW).setDataAndType(
            Uri.parse(android.os.Environment.getExternalStorageDirectory().absolutePath + "/" + relative), "resource/folder"
        ),
        // last resort: the Downloads screen
        Intent(android.app.DownloadManager.ACTION_VIEW_DOWNLOADS),
    )
    for (i in attempts) {
        val ok = runCatching {
            ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)); true
        }.getOrDefault(false)
        if (ok) return
    }
    android.widget.Toast.makeText(ctx, tr("Files are in: $relative", "فائلیں یہاں ہیں: $relative"), android.widget.Toast.LENGTH_LONG).show()
}
