package com.k2.share.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import com.k2.share.Kind
import com.k2.share.MEDIA_PERMS
import com.k2.share.MediaItem
import com.k2.share.Thumbs
import com.k2.share.hasMediaAccess
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.k2.share.Device
import com.k2.share.SAVE_FOLDER
import com.k2.share.Screen
import com.k2.share.ShareViewModel
import com.k2.share.TState
import com.k2.share.Transfer
import com.k2.share.fmt

private val muted: Color @Composable get() = MaterialTheme.colorScheme.onSurfaceVariant
private val card: Color @Composable get() = MaterialTheme.colorScheme.surfaceVariant

@Composable
fun AppRoot(vm: ShareViewModel, granted: Boolean, onRequest: () -> Unit) {
    val view = LocalView.current
    val busy = vm.screen == Screen.SEND || vm.screen == Screen.RECEIVE
    DisposableEffect(busy) {
        view.keepScreenOn = busy // screen stays on during a transfer
        onDispose { view.keepScreenOn = false }
    }
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        if (!granted) PermissionScreen(onRequest)
        else AnimatedContent(
            targetState = vm.screen,
            transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(160)) },
            label = "nav",
        ) { s ->
            when (s) {
                Screen.HOME -> HomeScreen(vm)
                Screen.PICK -> PickScreen(vm)
                Screen.SEND -> SendScreen(vm)
                Screen.RECEIVE -> ReceiveScreen(vm)
            }
        }
    }
    vm.request?.let { r ->
        AlertDialog(
            onDismissRequest = vm::decline,
            icon = { Avatar(r.name, 48.dp) },
            title = { Text(r.name, textAlign = TextAlign.Center) },
            text = { Text("wants to send you files.", textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()) },
            confirmButton = { Button(onClick = vm::accept) { Text("Accept") } },
            dismissButton = { TextButton(onClick = vm::decline) { Text("Decline") } },
        )
    }
}

// ---------------- Permissions ----------------

@Composable
private fun PermissionScreen(onRequest: () -> Unit) {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(Modifier.size(96.dp).clip(CircleShape).background(Ink), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.LocationOn, null, tint = Saffron, modifier = Modifier.size(44.dp))
        }
        Spacer(Modifier.height(24.dp))
        Text("Allow nearby access", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Asan Share needs this to find phones near you and connect to them directly. Files never go through the internet.",
            textAlign = TextAlign.Center, color = muted,
        )
        Spacer(Modifier.height(28.dp))
        Button(onClick = onRequest, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(16.dp)) {
            Text("Allow", fontSize = 16.sp)
        }
        TextButton(onClick = {
            ctx.startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }) { Text("Open app settings") }
    }
}

// ---------------- Home ----------------

@Composable
private fun HomeScreen(vm: ShareViewModel) {
    var renaming by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 20.dp, vertical = 16.dp)) {
        Spacer(Modifier.height(12.dp))
        Text("Asan Share", fontSize = 34.sp, fontWeight = FontWeight.Black, letterSpacing = (-0.5).sp)
        Text("Send files to a phone next to you. No internet, no data.", color = muted)
        Spacer(Modifier.height(28.dp))
        BigTile("Send", "Choose files, then a phone", Icons.AutoMirrored.Filled.Send, Ink, Color.White, Saffron, vm::openSend)
        Spacer(Modifier.height(14.dp))
        BigTile("Receive", "Let a nearby phone find you", Icons.Filled.KeyboardArrowDown, Saffron, OnSaffron, Ink, vm::openReceive)
        Spacer(Modifier.weight(1f))
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(card)
                .clickable { renaming = true }.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Avatar(vm.myName, 44.dp)
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text("Other phones see you as", style = MaterialTheme.typography.bodySmall, color = muted)
                Text(vm.myName, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Icon(Icons.Filled.Edit, "Change name", tint = muted)
        }
        Spacer(Modifier.height(10.dp))
        Text(
            "Received files are saved in Downloads/$SAVE_FOLDER",
            style = MaterialTheme.typography.bodySmall, color = muted,
            modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(14.dp))
        DeveloperCredit()
    }
    if (renaming) {
        var text by remember { mutableStateOf(vm.myName) }
        AlertDialog(
            onDismissRequest = { renaming = false },
            title = { Text("Your phone's name") },
            text = { OutlinedTextField(value = text, onValueChange = { text = it.take(30) }, singleLine = true) },
            confirmButton = { Button(onClick = { vm.rename(text); renaming = false }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { renaming = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun BigTile(
    title: String, subtitle: String, icon: ImageVector,
    bg: Color, fg: Color, accent: Color, onClick: () -> Unit,
) {
    Box(
        Modifier.fillMaxWidth().height(168.dp).clip(RoundedCornerShape(32.dp)).background(bg)
            .clickable(onClick = onClick).padding(24.dp)
    ) {
        Box(
            Modifier.align(Alignment.TopEnd).size(60.dp).clip(CircleShape).background(accent),
            contentAlignment = Alignment.Center,
        ) { Icon(icon, null, tint = bg, modifier = Modifier.size(30.dp)) }
        Column(Modifier.align(Alignment.BottomStart)) {
            Text(title, color = fg, fontSize = 32.sp, fontWeight = FontWeight.Black)
            Text(subtitle, color = fg.copy(alpha = 0.8f))
        }
    }
}

@Composable
private fun DeveloperCredit() {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable {
            runCatching {
                ctx.startActivity(
                    Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/923032901193"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }.padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("Developed by JAVED IQBAL", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
        Text("WhatsApp 0303 2901193", color = Good, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
    }
}

// ---------------- Send ----------------

@Composable
private fun SendScreen(vm: ShareViewModel) {
    BackHandler { vm.backToPick() }
    val more = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) {
        if (it.isNotEmpty()) vm.sendMore(it)
    }
    LaunchedEffect(Unit) { while (true) { vm.keepAlive(); delay(1200) } }

    if (vm.connected || vm.transfers.isNotEmpty()) {
        TransferScreen(vm, sending = true) { more.launch(arrayOf("*/*")) }
        return
    }

    val total = vm.picked.sumOf { it.size }
    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        TopBar("Send", vm::backToPick)
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(card).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(Ink), contentAlignment = Alignment.Center) {
                        Text("${vm.picked.size}", color = Saffron, fontWeight = FontWeight.Black, fontSize = 18.sp)
                    }
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(if (vm.picked.size == 1) vm.picked.first().name else "${vm.picked.size} files",
                            fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(fmt(total), style = MaterialTheme.typography.bodySmall, color = muted)
                    }
                    TextButton(onClick = vm::backToPick) { Text("Change") }
                }
            }
            item {
                Column {
                    Spacer(Modifier.height(14.dp))
                    SectionTitle("Nearby phones", null)
                }
            }
            if (vm.problems.isNotEmpty() || vm.failed) {
                item { FixItCard(vm) }
            } else if (vm.devices.isEmpty()) {
                item {
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Pulse(MaterialTheme.colorScheme.primary, 180.dp) {
                            Icon(Icons.Filled.Search, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp))
                        }
                        Text(
                            "Looking for phones… On the other phone, open Asan Share and tap Receive.",
                            textAlign = TextAlign.Center, color = muted,
                        )
                    }
                }
            } else {
                items(vm.devices, key = { it.id }) { d ->
                    DeviceRow(d, enabled = vm.picked.isNotEmpty()) { vm.connect(d) }
                }
            }
            if (vm.status.isNotEmpty() && !vm.failed) item {
                Text(
                    vm.status, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp), textAlign = TextAlign.Center,
                )
            }
        }
    }
}

@Composable
private fun DeviceRow(d: Device, enabled: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().alpha(if (enabled) 1f else 0.5f).clip(RoundedCornerShape(20.dp)).background(card)
            .clickable(enabled = enabled, onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Avatar(d.name, 48.dp)
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Text(d.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                if (enabled) "Tap to send" else "Choose files first",
                style = MaterialTheme.typography.bodySmall, color = muted,
            )
        }
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = muted)
    }
}

// ---------------- Receive ----------------

@Composable
private fun ReceiveScreen(vm: ShareViewModel) {
    BackHandler { vm.goHome() }
    LaunchedEffect(Unit) { while (true) { vm.keepAlive(); delay(1200) } }

    if (vm.connected || vm.transfers.isNotEmpty()) {
        TransferScreen(vm, sending = false) {}
        return
    }

    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        TopBar("Receive", vm::goHome)
        Column(
            Modifier.weight(1f).fillMaxWidth().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            if (vm.problems.isNotEmpty() || vm.failed) FixItCard(vm) else ReadyToReceive(vm)
        }
    }
}

@Composable
private fun ReadyToReceive(vm: ShareViewModel) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Pulse(Saffron, 260.dp) {
                Box(Modifier.size(96.dp).clip(CircleShape).background(Saffron), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.KeyboardArrowDown, null, tint = Ink, modifier = Modifier.size(56.dp))
                }
            }
            Spacer(Modifier.height(20.dp))
            Text("Ready to receive", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(vm.myName, 26.dp)
                Spacer(Modifier.width(8.dp))
                Text(vm.myName, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(16.dp))
            Text(
                "On the other phone, open Asan Share, tap Send and pick this phone.",
                textAlign = TextAlign.Center, color = muted,
            )
    }
}

// ---------------- Transfer progress ----------------

@Composable
private fun TransferScreen(vm: ShareViewModel, sending: Boolean, onMore: () -> Unit) {
    val ctx = LocalContext.current
    val list = vm.transfers
    val total = maxOf(vm.expectedBytes, list.sumOf { it.size })
    val done = list.sumOf { it.done }
    val count = maxOf(vm.expectedCount, list.size)
    val doneCount = list.count { it.state == TState.DONE }
    val finished = list.isNotEmpty() && list.size >= count && list.all { it.state == TState.DONE || it.state == TState.FAILED }
    val speed = list.filter { it.state == TState.RUNNING }.sumOf { it.speed }
    val progress by animateFloatAsState(
        if (total > 0) (done.toFloat() / total).coerceIn(0f, 1f) else 0f, label = "progress",
    )
    val bg = if (sending) Ink else Saffron
    val fg = if (sending) Color.White else OnSaffron

    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        TopBar(if (sending) "Sending" else "Receiving", vm::goHome)
        Column(
            Modifier.padding(horizontal = 20.dp).fillMaxWidth().clip(RoundedCornerShape(32.dp))
                .background(bg).padding(24.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (sending) "To" else "From", color = fg.copy(alpha = 0.75f), modifier = Modifier.weight(1f))
                if (vm.connected) {
                    Text(
                        when (vm.link) {
                            3 -> "Fast Wi-Fi"
                            2 -> "Wi-Fi"
                            else -> "Bluetooth"
                        },
                        color = fg, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge,
                        modifier = Modifier.clip(RoundedCornerShape(50)).background(fg.copy(alpha = 0.15f))
                            .padding(horizontal = 12.dp, vertical = 5.dp),
                    )
                }
            }
            Text(
                vm.peerName ?: "…", color = fg, style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(18.dp))
            Text(
                when {
                    list.isEmpty() && sending -> "Speeding up…"
                    list.isEmpty() -> "Connected"
                    finished -> "Done"
                    else -> "${(progress * 100).toInt()}%"
                },
                color = fg, fontSize = 48.sp, fontWeight = FontWeight.Black,
            )
            Spacer(Modifier.height(10.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(8.dp),
                color = fg,
                trackColor = fg.copy(alpha = 0.2f),
                strokeCap = StrokeCap.Round,
            )
            Spacer(Modifier.height(10.dp))
            Text(
                buildString {
                    append("$doneCount of $count files   ${fmt(done)} of ${fmt(total)}")
                    if (speed > 0 && !finished) append("   ${fmt(speed.toLong())}/s")
                },
                color = fg.copy(alpha = 0.85f),
            )
        }
        if (vm.status.isNotEmpty()) {
            Text(
                vm.status, color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 10.dp),
            )
        }
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(list, key = { it.id }) { t -> TransferRow(t) { t.saved?.let { openFile(ctx, it) } } }
        }
        Row(Modifier.fillMaxWidth().padding(20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (sending && finished && vm.connected) {
                OutlinedButton(
                    onClick = onMore, modifier = Modifier.weight(1f).height(56.dp), shape = RoundedCornerShape(18.dp),
                ) { Text("Send more", fontSize = 16.sp) }
            }
            Button(
                onClick = vm::goHome, modifier = Modifier.weight(1f).height(56.dp), shape = RoundedCornerShape(18.dp),
            ) { Text(if (finished || list.isEmpty()) "Finish" else "Cancel", fontSize = 16.sp) }
        }
    }
}

@Composable
private fun TransferRow(t: Transfer, onOpen: () -> Unit) {
    val p = if (t.size > 0) (t.done.toFloat() / t.size).coerceIn(0f, 1f) else 0f
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(card)
            .clickable(enabled = t.saved != null, onClick = onOpen).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        FileBadge(t.name)
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(t.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
            if (t.state == TState.RUNNING || t.state == TState.WAITING) {
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { p }, modifier = Modifier.fillMaxWidth(), strokeCap = StrokeCap.Round,
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(
                when (t.state) {
                    TState.WAITING -> "Waiting…"
                    TState.RUNNING -> "${fmt(t.done)} of ${fmt(t.size)}"
                    TState.SAVING -> "Saving…"
                    TState.DONE -> if (t.incoming) "${fmt(t.size)}, tap to open" else "${fmt(t.size)}, sent"
                    TState.FAILED -> "Didn't arrive. Send it again."
                },
                style = MaterialTheme.typography.bodySmall, color = muted,
            )
        }
        when (t.state) {
            TState.DONE -> Icon(Icons.Filled.CheckCircle, "Done", tint = Good)
            TState.FAILED -> Icon(Icons.Filled.Warning, "Failed", tint = MaterialTheme.colorScheme.error)
            else -> {}
        }
    }
}

@Composable
private fun FixItCard(vm: ShareViewModel) {
    val ctx = LocalContext.current
    fun open(action: String) {
        runCatching { ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(card).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(Icons.Filled.Warning, null, tint = Saffron, modifier = Modifier.size(36.dp))
        Spacer(Modifier.height(10.dp))
        if (vm.problems.isNotEmpty()) {
            Text("Turn on ${vm.problems.joinToString(" and ")}", fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Spacer(Modifier.height(4.dp))
            Text("Asan Share starts by itself once it's on.", color = muted, textAlign = TextAlign.Center)
            Spacer(Modifier.height(14.dp))
            for (p in vm.problems) {
                OutlinedButton(
                    onClick = {
                        open(
                            when (p) {
                                "Bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                                "Wi-Fi" -> Settings.ACTION_WIFI_SETTINGS
                                else -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
                            }
                        )
                    },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).height(50.dp),
                    shape = RoundedCornerShape(16.dp),
                ) { Text("Open $p settings") }
            }
        } else {
            Text(vm.status, textAlign = TextAlign.Center)
            Spacer(Modifier.height(14.dp))
            Button(
                onClick = vm::retry, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp),
            ) { Text("Try again", fontSize = 16.sp) }
            TextButton(onClick = {
                runCatching {
                    ctx.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            }) { Text("Open app permissions") }
        }
    }
}

// ---------------- Small pieces ----------------

@Composable
private fun TopBar(title: String, onBack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SectionTitle(title: String, trailing: String?) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (trailing != null) Text(trailing, style = MaterialTheme.typography.bodySmall, color = muted)
    }
}

private val avatarColors = listOf(0xFF1F2A6B, 0xFF0E8C7F, 0xFFC2410C, 0xFF9D174D, 0xFF4338CA, 0xFF15803D).map { Color(it) }

@Composable
private fun Avatar(name: String, size: Dp) {
    val c = avatarColors[(name.hashCode() and 0x7fffffff) % avatarColors.size]
    Box(Modifier.size(size).clip(CircleShape).background(c), contentAlignment = Alignment.Center) {
        Text(
            name.trim().take(1).uppercase().ifEmpty { "?" },
            color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.42f).sp,
        )
    }
}

@Composable
private fun FileBadge(name: String) {
    val ext = name.substringAfterLast('.', "").lowercase()
    val (label, color) = when (ext) {
        "jpg", "jpeg", "png", "gif", "webp", "heic" -> "IMG" to Color(0xFFDB2777)
        "mp4", "mkv", "mov", "avi", "3gp", "webm" -> "VID" to Color(0xFFEA580C)
        "mp3", "m4a", "wav", "aac", "ogg", "opus" -> "AUD" to Color(0xFF7C3AED)
        "apk" -> "APK" to Color(0xFF16A34A)
        "pdf" -> "PDF" to Color(0xFFDC2626)
        "zip", "rar", "7z" -> "ZIP" to Color(0xFF92400E)
        "dst", "emb", "pes", "jef", "exp", "dsb" -> "EMB" to Color(0xFF0E8C7F)
        else -> ext.take(4).uppercase().ifEmpty { "FILE" } to Color(0xFF4F5BD5)
    }
    Box(
        Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(color.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = color, fontWeight = FontWeight.Bold, fontSize = 11.sp) }
}

@Composable
private fun Pulse(color: Color, size: Dp, content: @Composable () -> Unit) {
    val t = rememberInfiniteTransition(label = "pulse")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2400, easing = LinearEasing)), label = "p")
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = this.size.minDimension / 2f
            for (i in 0 until 3) {
                val f = (p + i / 3f) % 1f
                drawCircle(color.copy(alpha = (1f - f) * 0.28f), radius = r * (0.3f + 0.7f * f))
            }
        }
        content()
    }
}

private fun openFile(ctx: Context, uri: Uri) {
    val type = ctx.contentResolver.getType(uri) ?: "*/*"
    val view = Intent(Intent.ACTION_VIEW).setDataAndType(uri, type)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    runCatching {
        ctx.startActivity(Intent.createChooser(view, "Open with").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}


// ---------------- Pick files (Zapya-style tabs) ----------------

@Composable
private fun PickScreen(vm: ShareViewModel) {
    BackHandler { vm.goHome() }
    val ctx = LocalContext.current
    var hasMedia by remember { mutableStateOf(hasMediaAccess(ctx)) }
    val mediaPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        hasMedia = hasMediaAccess(ctx)
        vm.loadLibrary(hasMedia)
    }
    val browse = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.addFiles(it) }
    LaunchedEffect(Unit) {
        vm.loadLibrary(hasMedia)
        if (!hasMedia) mediaPerm.launch(MEDIA_PERMS)
    }
    var tab by rememberSaveable { mutableIntStateOf(1) }
    val tabs = listOf("Apps" to vm.apps, "Photos" to vm.photos, "Videos" to vm.videos, "Music" to vm.music, "Files" to vm.docs)

    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        TopBar("Choose what to send", vm::goHome)
        ScrollableTabRow(
            selectedTabIndex = tab,
            edgePadding = 12.dp,
            containerColor = Color.Transparent,
            divider = {},
        ) {
            tabs.forEachIndexed { i, (label, list) ->
                Tab(
                    selected = tab == i,
                    onClick = { tab = i },
                    text = {
                        Text(
                            if (list.isEmpty()) label else "$label ${list.size}",
                            fontWeight = if (tab == i) FontWeight.Bold else FontWeight.Normal,
                        )
                    },
                )
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            val list = tabs[tab].second
            when {
                tab in 1..3 && !hasMedia -> MediaAccessCard { mediaPerm.launch(MEDIA_PERMS) }
                vm.loading && list.isEmpty() -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                tab == 0 -> AppsGrid(vm, list)
                tab == 1 || tab == 2 -> MediaGrid(vm, list)
                tab == 3 -> ItemList(vm, list, null)
                else -> ItemList(vm, list) { browse.launch(arrayOf("*/*")) }
            }
        }
        if (vm.picked.isNotEmpty()) SelectionBar(vm)
    }
}

@Composable
private fun MediaAccessCard(onAllow: () -> Unit) {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text("Allow access to your photos, videos and music", fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
            style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(6.dp))
        Text("Asan Share only reads them to show here. Nothing is uploaded.", color = muted, textAlign = TextAlign.Center)
        Spacer(Modifier.height(18.dp))
        Button(onClick = onAllow, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) { Text("Allow") }
        TextButton(onClick = {
            runCatching {
                ctx.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }) { Text("Open app settings") }
    }
}

@Composable
private fun GridHeader(vm: ShareViewModel, list: List<MediaItem>, label: String) {
    val all = list.isNotEmpty() && list.all { vm.isSelected(it) }
    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = muted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
        if (list.isNotEmpty()) TextButton(onClick = { vm.selectAll(list, !all) }) { Text(if (all) "Unselect all" else "Select all") }
    }
}

@Composable
private fun EmptyNote(text: String) {
    Text(text, color = muted, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(32.dp))
}

@Composable
private fun AppsGrid(vm: ShareViewModel, list: List<MediaItem>) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(86.dp),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) { GridHeader(vm, list, "${list.size} apps") }
        if (list.isEmpty()) item(span = { GridItemSpan(maxLineSpan) }) { EmptyNote("No apps found") }
        items(list.size, key = { list[it].key }) { idx ->
            val item = list[idx]
            val sel = vm.isSelected(item)
            Column(
                Modifier.clip(RoundedCornerShape(16.dp))
                    .background(if (sel) Saffron.copy(alpha = 0.2f) else Color.Transparent)
                    .clickable { vm.toggle(item) }
                    .padding(vertical = 10.dp, horizontal = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box {
                    Thumb(item, Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)), ContentScale.Fit)
                    if (sel) CheckDot(true, onImage = true, modifier = Modifier.align(Alignment.TopEnd).offset(x = 6.dp, y = (-6).dp))
                }
                Spacer(Modifier.height(6.dp))
                Text(item.name.removeSuffix(".apk"), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                Text(fmt(item.size), fontSize = 10.sp, color = muted)
            }
        }
    }
}

@Composable
private fun MediaGrid(vm: ShareViewModel, list: List<MediaItem>) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(104.dp),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) { GridHeader(vm, list, "${list.size} items") }
        if (list.isEmpty()) item(span = { GridItemSpan(maxLineSpan) }) { EmptyNote("Nothing here yet") }
        items(list.size, key = { list[it].key }) { idx ->
            val item = list[idx]
            val sel = vm.isSelected(item)
            Box(Modifier.aspectRatio(1f).clip(RoundedCornerShape(10.dp)).background(card).clickable { vm.toggle(item) }) {
                Thumb(item, Modifier.fillMaxSize(), ContentScale.Crop)
                if (item.kind == Kind.VIDEO && item.extra.isNotEmpty()) {
                    Text(
                        item.extra, color = Color.White, fontSize = 11.sp,
                        modifier = Modifier.align(Alignment.BottomEnd).padding(5.dp).clip(RoundedCornerShape(6.dp))
                            .background(Color.Black.copy(alpha = 0.55f)).padding(horizontal = 5.dp, vertical = 1.dp),
                    )
                }
                if (sel) Box(Modifier.fillMaxSize().background(Ink.copy(alpha = 0.35f)))
                CheckDot(sel, onImage = true, modifier = Modifier.align(Alignment.TopEnd).padding(6.dp))
            }
        }
    }
}

@Composable
private fun ItemList(vm: ShareViewModel, list: List<MediaItem>, onBrowse: (() -> Unit)?) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        if (onBrowse != null) item {
            OutlinedButton(
                onClick = onBrowse, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp),
            ) {
                Icon(Icons.Filled.Search, null)
                Spacer(Modifier.width(8.dp))
                Text("Browse phone storage")
            }
        }
        item { GridHeader(vm, list, "${list.size} items") }
        if (list.isEmpty()) item {
            EmptyNote(if (onBrowse != null) "Use Browse phone storage to pick any file." else "Nothing here yet")
        }
        items(list, key = { it.key }) { item ->
            val sel = vm.isSelected(item)
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                    .background(if (sel) Saffron.copy(alpha = 0.18f) else card)
                    .clickable { vm.toggle(item) }.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                FileBadge(item.name)
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                    Text(
                        listOf(fmt(item.size), item.extra).filter { it.isNotEmpty() }.joinToString("   "),
                        style = MaterialTheme.typography.bodySmall, color = muted,
                    )
                }
                CheckDot(sel, onImage = false)
            }
        }
    }
}

@Composable
private fun SelectionBar(vm: ShareViewModel) {
    val total = vm.picked.sumOf { it.size }
    Row(
        Modifier.fillMaxWidth().padding(12.dp).clip(RoundedCornerShape(26.dp)).background(Ink)
            .padding(start = 20.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text("${vm.picked.size} selected", color = Color.White, fontWeight = FontWeight.Bold)
            Text(fmt(total), color = Color.White.copy(alpha = 0.75f), style = MaterialTheme.typography.bodySmall)
        }
        TextButton(onClick = vm::clearSelection) { Text("Clear", color = Color.White.copy(alpha = 0.8f)) }
        Button(
            onClick = vm::openDevices,
            colors = ButtonDefaults.buttonColors(containerColor = Saffron, contentColor = OnSaffron),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.height(50.dp),
        ) {
            Icon(Icons.AutoMirrored.Filled.Send, null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("Send", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}

@Composable
private fun CheckDot(selected: Boolean, onImage: Boolean, modifier: Modifier = Modifier) {
    Box(
        modifier.size(24.dp).clip(CircleShape)
            .background(if (selected) Saffron else if (onImage) Color.Black.copy(alpha = 0.25f) else Color.Transparent)
            .border(2.dp, if (selected) Saffron else if (onImage) Color.White else muted, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        if (selected) Icon(Icons.Filled.Check, null, tint = Ink, modifier = Modifier.size(16.dp))
    }
}

@Composable
private fun Thumb(item: MediaItem, modifier: Modifier, scale: ContentScale) {
    val ctx = LocalContext.current
    val bmp: ImageBitmap? by produceState(Thumbs.cached(item.key), item.key) {
        if (value == null) value = Thumbs.load(ctx, item)
    }
    val b = bmp
    if (b != null) Image(b, null, modifier, contentScale = scale)
    else Box(modifier.background(card))
}
