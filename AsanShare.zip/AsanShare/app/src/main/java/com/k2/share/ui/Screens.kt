package com.k2.share.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.k2.share.Device
import com.k2.share.SAVE_FOLDER
import com.k2.share.Screen
import com.k2.share.ShareViewModel
import com.k2.share.TState
import com.k2.share.Transfer
import com.k2.share.fmt

private val muted: Color @Composable get() = MaterialTheme.colorScheme.onSurfaceVariant
private val card: Color @Composable get() = MaterialTheme.colorScheme.surfaceVariant

@Composable
fun AppRoot(vm: ShareViewModel, granted: Boolean, onRequest: () -> Unit) {
    val view = LocalView.current
    val busy = vm.screen != Screen.HOME
    DisposableEffect(busy) {
        view.keepScreenOn = busy // screen stays on during a transfer
        onDispose { view.keepScreenOn = false }
    }
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        if (!granted) PermissionScreen(onRequest)
        else AnimatedContent(
            targetState = vm.screen,
            transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(160)) },
            label = "nav",
        ) { s ->
            when (s) {
                Screen.HOME -> HomeScreen(vm)
                Screen.SEND -> SendScreen(vm)
                Screen.RECEIVE -> ReceiveScreen(vm)
            }
        }
    }
    vm.request?.let { r ->
        AlertDialog(
            onDismissRequest = vm::decline,
            icon = { Avatar(r.name, 48.dp) },
            title = { Text(r.name, textAlign = TextAlign.Center) },
            text = { Text("wants to send you files.", textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()) },
            confirmButton = { Button(onClick = vm::accept) { Text("Accept") } },
            dismissButton = { TextButton(onClick = vm::decline) { Text("Decline") } },
        )
    }
}

// ---------------- Permissions ----------------

@Composable
private fun PermissionScreen(onRequest: () -> Unit) {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(Modifier.size(96.dp).clip(CircleShape).background(Ink), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.LocationOn, null, tint = Saffron, modifier = Modifier.size(44.dp))
        }
        Spacer(Modifier.height(24.dp))
        Text("Allow nearby access", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Asan Share needs this to find phones near you and connect to them directly. Files never go through the internet.",
            textAlign = TextAlign.Center, color = muted,
        )
        Spacer(Modifier.height(28.dp))
        Button(onClick = onRequest, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(16.dp)) {
            Text("Allow", fontSize = 16.sp)
        }
        TextButton(onClick = {
            ctx.startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }) { Text("Open app settings") }
    }
}

// ---------------- Home ----------------

@Composable
private fun HomeScreen(vm: ShareViewModel) {
    var renaming by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 20.dp, vertical = 16.dp)) {
        Spacer(Modifier.height(12.dp))
        Text("Asan Share", fontSize = 34.sp, fontWeight = FontWeight.Black, letterSpacing = (-0.5).sp)
        Text("Send files to a phone next to you. No internet, no data.", color = muted)
        Spacer(Modifier.height(28.dp))
        BigTile("Send", "Choose files, then a phone", Icons.AutoMirrored.Filled.Send, Ink, Color.White, Saffron, vm::openSend)
        Spacer(Modifier.height(14.dp))
        BigTile("Receive", "Let a nearby phone find you", Icons.Filled.KeyboardArrowDown, Saffron, OnSaffron, Ink, vm::openReceive)
        Spacer(Modifier.weight(1f))
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(card)
                .clickable { renaming = true }.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Avatar(vm.myName, 44.dp)
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text("Other phones see you as", style = MaterialTheme.typography.bodySmall, color = muted)
                Text(vm.myName, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Icon(Icons.Filled.Edit, "Change name", tint = muted)
        }
        Spacer(Modifier.height(10.dp))
        Text(
            "Received files are saved in Downloads/$SAVE_FOLDER",
            style = MaterialTheme.typography.bodySmall, color = muted,
            modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(14.dp))
        DeveloperCredit()
    }
    if (renaming) {
        var text by remember { mutableStateOf(vm.myName) }
        AlertDialog(
            onDismissRequest = { renaming = false },
            title = { Text("Your phone's name") },
            text = { OutlinedTextField(value = text, onValueChange = { text = it.take(30) }, singleLine = true) },
            confirmButton = { Button(onClick = { vm.rename(text); renaming = false }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { renaming = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun BigTile(
    title: String, subtitle: String, icon: ImageVector,
    bg: Color, fg: Color, accent: Color, onClick: () -> Unit,
) {
    Box(
        Modifier.fillMaxWidth().height(168.dp).clip(RoundedCornerShape(32.dp)).background(bg)
            .clickable(onClick = onClick).padding(24.dp)
    ) {
        Box(
            Modifier.align(Alignment.TopEnd).size(60.dp).clip(CircleShape).background(accent),
            contentAlignment = Alignment.Center,
        ) { Icon(icon, null, tint = bg, modifier = Modifier.size(30.dp)) }
        Column(Modifier.align(Alignment.BottomStart)) {
            Text(title, color = fg, fontSize = 32.sp, fontWeight = FontWeight.Black)
            Text(subtitle, color = fg.copy(alpha = 0.8f))
        }
    }
}

@Composable
private fun DeveloperCredit() {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable {
            runCatching {
                ctx.startActivity(
                    Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/923032901193"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }.padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("Developed by JAVED IQBAL", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
        Text("WhatsApp 0303 2901193", color = Good, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
    }
}

// ---------------- Send ----------------

@Composable
private fun SendScreen(vm: ShareViewModel) {
    BackHandler { vm.goHome() }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.addFiles(it) }
    val more = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) {
        if (it.isNotEmpty()) vm.sendMore(it)
    }
    LaunchedEffect(Unit) { vm.startDiscovery() }

    if (vm.connected || vm.transfers.isNotEmpty()) {
        TransferScreen(vm, sending = true) { more.launch(arrayOf("*/*")) }
        return
    }

    val total = vm.picked.sumOf { it.size }
    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        TopBar("Send", vm::goHome)
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                SectionTitle("Files", if (vm.picked.isEmpty()) null else "${vm.picked.size} files, ${fmt(total)}")
            }
            items(vm.picked, key = { it.uri.toString() }) { f ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(card)
                        .padding(start = 12.dp, top = 10.dp, bottom = 10.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    FileBadge(f.name)
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                        Text(fmt(f.size), style = MaterialTheme.typography.bodySmall, color = muted)
                    }
                    IconButton(onClick = { vm.removeFile(f) }) { Icon(Icons.Filled.Close, "Remove", tint = muted) }
                }
            }
            item {
                OutlinedButton(
                    onClick = { picker.launch(arrayOf("*/*")) },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(18.dp),
                ) {
                    Icon(Icons.Filled.Add, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (vm.picked.isEmpty()) "Choose files" else "Add more files", fontSize = 16.sp)
                }
            }
            item {
                Column {
                    Spacer(Modifier.height(14.dp))
                    SectionTitle("Nearby phones", null)
                }
            }
            if (vm.devices.isEmpty()) {
                item {
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Pulse(MaterialTheme.colorScheme.primary, 180.dp) {
                            Icon(Icons.Filled.Search, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp))
                        }
                        Text(
                            "Looking for phones… On the other phone, open Asan Share and tap Receive.",
                            textAlign = TextAlign.Center, color = muted,
                        )
                    }
                }
            } else {
                items(vm.devices, key = { it.id }) { d ->
                    DeviceRow(d, enabled = vm.picked.isNotEmpty()) { vm.connect(d) }
                }
            }
            if (vm.status.isNotEmpty()) item {
                Text(
                    vm.status, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp), textAlign = TextAlign.Center,
                )
            }
        }
    }
}

@Composable
private fun DeviceRow(d: Device, enabled: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().alpha(if (enabled) 1f else 0.5f).clip(RoundedCornerShape(20.dp)).background(card)
            .clickable(enabled = enabled, onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Avatar(d.name, 48.dp)
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Text(d.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                if (enabled) "Tap to send" else "Choose files first",
                style = MaterialTheme.typography.bodySmall, color = muted,
            )
        }
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = muted)
    }
}

// ---------------- Receive ----------------

@Composable
private fun ReceiveScreen(vm: ShareViewModel) {
    BackHandler { vm.goHome() }
    LaunchedEffect(Unit) { vm.startAdvertising() }

    if (vm.connected || vm.transfers.isNotEmpty()) {
        TransferScreen(vm, sending = false) {}
        return
    }

    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        TopBar("Receive", vm::goHome)
        Column(
            Modifier.weight(1f).fillMaxWidth().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Pulse(Saffron, 260.dp) {
                Box(Modifier.size(96.dp).clip(CircleShape).background(Saffron), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.KeyboardArrowDown, null, tint = Ink, modifier = Modifier.size(56.dp))
                }
            }
            Spacer(Modifier.height(20.dp))
            Text("Ready to receive", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(vm.myName, 26.dp)
                Spacer(Modifier.width(8.dp))
                Text(vm.myName, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(16.dp))
            Text(
                "On the other phone, open Asan Share, tap Send and pick this phone.",
                textAlign = TextAlign.Center, color = muted,
            )
            if (vm.status.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Text(vm.status, color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center)
            }
        }
    }
}

// ---------------- Transfer progress ----------------

@Composable
private fun TransferScreen(vm: ShareViewModel, sending: Boolean, onMore: () -> Unit) {
    val ctx = LocalContext.current
    val list = vm.transfers
    val total = list.sumOf { it.size }
    val done = list.sumOf { it.done }
    val finished = list.isNotEmpty() && list.all { it.state == TState.DONE || it.state == TState.FAILED }
    val speed = list.filter { it.state == TState.RUNNING }.sumOf { it.speed }
    val progress by animateFloatAsState(
        if (total > 0) (done.toFloat() / total).coerceIn(0f, 1f) else 0f, label = "progress",
    )
    val bg = if (sending) Ink else Saffron
    val fg = if (sending) Color.White else OnSaffron

    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        TopBar(if (sending) "Sending" else "Receiving", vm::goHome)
        Column(
            Modifier.padding(horizontal = 20.dp).fillMaxWidth().clip(RoundedCornerShape(32.dp))
                .background(bg).padding(24.dp)
        ) {
            Text(if (sending) "To" else "From", color = fg.copy(alpha = 0.75f))
            Text(
                vm.peerName ?: "…", color = fg, style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(18.dp))
            Text(
                when {
                    list.isEmpty() -> "Connected"
                    finished -> "Done"
                    else -> "${(progress * 100).toInt()}%"
                },
                color = fg, fontSize = 48.sp, fontWeight = FontWeight.Black,
            )
            Spacer(Modifier.height(10.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(8.dp),
                color = fg,
                trackColor = fg.copy(alpha = 0.2f),
                strokeCap = StrokeCap.Round,
            )
            Spacer(Modifier.height(10.dp))
            Text(
                buildString {
                    append("${fmt(done)} of ${fmt(total)}")
                    if (speed > 0 && !finished) append("   ${fmt(speed.toLong())}/s")
                },
                color = fg.copy(alpha = 0.85f),
            )
        }
        if (vm.status.isNotEmpty()) {
            Text(
                vm.status, color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 10.dp),
            )
        }
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(list, key = { it.id }) { t -> TransferRow(t) { t.saved?.let { openFile(ctx, it) } } }
        }
        Row(Modifier.fillMaxWidth().padding(20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (sending && finished && vm.connected) {
                OutlinedButton(
                    onClick = onMore, modifier = Modifier.weight(1f).height(56.dp), shape = RoundedCornerShape(18.dp),
                ) { Text("Send more", fontSize = 16.sp) }
            }
            Button(
                onClick = vm::goHome, modifier = Modifier.weight(1f).height(56.dp), shape = RoundedCornerShape(18.dp),
            ) { Text(if (finished || list.isEmpty()) "Finish" else "Cancel", fontSize = 16.sp) }
        }
    }
}

@Composable
private fun TransferRow(t: Transfer, onOpen: () -> Unit) {
    val p = if (t.size > 0) (t.done.toFloat() / t.size).coerceIn(0f, 1f) else 0f
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(card)
            .clickable(enabled = t.saved != null, onClick = onOpen).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        FileBadge(t.name)
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(t.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
            if (t.state == TState.RUNNING || t.state == TState.WAITING) {
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { p }, modifier = Modifier.fillMaxWidth(), strokeCap = StrokeCap.Round,
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(
                when (t.state) {
                    TState.WAITING -> "Waiting…"
                    TState.RUNNING -> "${fmt(t.done)} of ${fmt(t.size)}"
                    TState.SAVING -> "Saving…"
                    TState.DONE -> if (t.incoming) "${fmt(t.size)}, tap to open" else "${fmt(t.size)}, sent"
                    TState.FAILED -> "Didn't arrive. Send it again."
                },
                style = MaterialTheme.typography.bodySmall, color = muted,
            )
        }
        when (t.state) {
            TState.DONE -> Icon(Icons.Filled.CheckCircle, "Done", tint = Good)
            TState.FAILED -> Icon(Icons.Filled.Warning, "Failed", tint = MaterialTheme.colorScheme.error)
            else -> {}
        }
    }
}

// ---------------- Small pieces ----------------

@Composable
private fun TopBar(title: String, onBack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SectionTitle(title: String, trailing: String?) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (trailing != null) Text(trailing, style = MaterialTheme.typography.bodySmall, color = muted)
    }
}

private val avatarColors = listOf(0xFF1F2A6B, 0xFF0E8C7F, 0xFFC2410C, 0xFF9D174D, 0xFF4338CA, 0xFF15803D).map { Color(it) }

@Composable
private fun Avatar(name: String, size: Dp) {
    val c = avatarColors[(name.hashCode() and 0x7fffffff) % avatarColors.size]
    Box(Modifier.size(size).clip(CircleShape).background(c), contentAlignment = Alignment.Center) {
        Text(
            name.trim().take(1).uppercase().ifEmpty { "?" },
            color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.42f).sp,
        )
    }
}

@Composable
private fun FileBadge(name: String) {
    val ext = name.substringAfterLast('.', "").lowercase()
    val (label, color) = when (ext) {
        "jpg", "jpeg", "png", "gif", "webp", "heic" -> "IMG" to Color(0xFFDB2777)
        "mp4", "mkv", "mov", "avi", "3gp", "webm" -> "VID" to Color(0xFFEA580C)
        "mp3", "m4a", "wav", "aac", "ogg", "opus" -> "AUD" to Color(0xFF7C3AED)
        "apk" -> "APK" to Color(0xFF16A34A)
        "pdf" -> "PDF" to Color(0xFFDC2626)
        "zip", "rar", "7z" -> "ZIP" to Color(0xFF92400E)
        "dst", "emb", "pes", "jef", "exp", "dsb" -> "EMB" to Color(0xFF0E8C7F)
        else -> ext.take(4).uppercase().ifEmpty { "FILE" } to Color(0xFF4F5BD5)
    }
    Box(
        Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(color.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = color, fontWeight = FontWeight.Bold, fontSize = 11.sp) }
}

@Composable
private fun Pulse(color: Color, size: Dp, content: @Composable () -> Unit) {
    val t = rememberInfiniteTransition(label = "pulse")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2400, easing = LinearEasing)), label = "p")
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = this.size.minDimension / 2f
            for (i in 0 until 3) {
                val f = (p + i / 3f) % 1f
                drawCircle(color.copy(alpha = (1f - f) * 0.28f), radius = r * (0.3f + 0.7f * f))
            }
        }
        content()
    }
}

private fun openFile(ctx: Context, uri: Uri) {
    val type = ctx.contentResolver.getType(uri) ?: "*/*"
    val view = Intent(Intent.ACTION_VIEW).setDataAndType(uri, type)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    runCatching {
        ctx.startActivity(Intent.createChooser(view, "Open with").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
