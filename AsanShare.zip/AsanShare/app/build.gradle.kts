plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.k2.share"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.javed.asanshare"
        minSdk = 26
        targetSdk = 34
        // Codemagic gives every build a higher number, so each new APK installs as an update
        versionCode = (System.getenv("BUILD_NUMBER")?.toIntOrNull() ?: 1) + 100
        versionName = "1.${System.getenv("BUILD_NUMBER") ?: "0"}"
    }

    // Fixed signing key (kept in the project) so new versions install over old ones
    signingConfigs {
        create("asan") {
            storeFile = file("asanshare.jks")
            storePassword = "AsanShare2026"
            keyAlias = "asanshare"
            keyPassword = "AsanShare2026"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // Signed with the debug key so the APK installs directly (sideload)
            signingConfig = signingConfigs.getByName("asan")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.core:core-ktx:1.13.1")
    // Google Play services pulls in an old Fragment library; force a new one
    implementation("androidx.fragment:fragment-ktx:1.8.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    // Google Nearby Connections: Bluetooth finds the phone, then a direct Wi-Fi link carries the files
    implementation("com.google.android.gms:play-services-nearby:19.3.0")
    // QR codes for "give the app to a friend"
    implementation("com.google.zxing:core:3.5.3")
}
